#!/bin/bash

echo "🔍 Kraken AI Diagnostics"
echo "========================"

echo "📂 Checking critical files..."

# Check if files exist
echo -n "✓ index.html: "
[ -f "index.html" ] && echo "✅ OK" || echo "❌ Missing"

echo -n "✓ index-simple.tsx: "
[ -f "index-simple.tsx" ] && echo "✅ OK" || echo "❌ Missing"

echo -n "✓ index.css: "
[ -f "index.css" ] && echo "✅ OK" || echo "❌ Missing"

echo -n "✓ App.tsx: "
[ -f "App.tsx" ] && echo "✅ OK" || echo "❌ Missing"

echo -n "✓ package.json: "
[ -f "package.json" ] && echo "✅ OK" || echo "❌ Missing"

echo ""
echo "🔧 Testing imports..."

# Test critical imports
echo "Testing React import..."
node -e "
try {
  const path = require('path');
  const fs = require('fs');
  
  // Check if react is in node_modules
  const reactPath = path.join(process.cwd(), 'node_modules', 'react');
  if (fs.existsSync(reactPath)) {
    console.log('✅ React package found');
  } else {
    console.log('❌ React package missing');
  }
  
  // Check if react-dom is in node_modules
  const reactDomPath = path.join(process.cwd(), 'node_modules', 'react-dom');
  if (fs.existsSync(reactDomPath)) {
    console.log('✅ React-DOM package found');
  } else {
    console.log('❌ React-DOM package missing');
  }
  
} catch (error) {
  console.log('❌ Error checking packages:', error.message);
}
"

echo ""
echo "📜 Current index.html content:"
echo "================================"
head -15 index.html

echo ""
echo "🌐 Server status: Check http://localhost:5000"
echo "📊 If you see the Kraken AI Working page, React is fixed!"
echo "🔄 If still not working, check browser console (F12) for errors"