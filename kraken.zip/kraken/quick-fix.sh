#!/bin/bash

# 🐋 Kraken AI - Quick Fix Script
# Script sederhana untuk memperbaiki masalah icon dan menjalankan aplikasi

echo "🐋 Kraken AI - Quick Fix Script"
echo "================================"

echo "✅ Checking project structure..."
if [ ! -f "package.json" ]; then
    echo "❌ Error: package.json not found! Please run this from project root."
    exit 1
fi

echo "✅ Icons already fixed in previous step!"
echo "✅ Cleaning cache..."
rm -rf dist/ 2>/dev/null || true
rm -rf .vite/ 2>/dev/null || true

echo "✅ Killing any existing processes on port 5000..."
pkill -f "vite.*5000" 2>/dev/null || true
sleep 1

echo ""
echo "🚀 Starting Kraken AI with DeepSeek theme..."
echo "📱 Server will be available at: http://localhost:5000"
echo ""
echo "🎮 New Features:"
echo "  🐋 DeepSeek-style whale logo"
echo "  📚 Interactive quiz system" 
echo "  🎨 Enhanced text contrast"
echo "  🏆 Gamified learning experience"
echo ""

# Start the development server
npm run dev