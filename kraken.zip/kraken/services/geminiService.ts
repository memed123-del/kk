import { Transaction, Anomaly, ChatMessage, Forecast } from '../types';

// Mock service implementations for demo purposes
export const analyzeTransactionsForAnomalies = async (transactions: Transaction[]): Promise<Anomaly[]> => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  const anomalies: Anomaly[] = [];
  if (transactions.length === 0) return anomalies;
  
  const amounts = transactions.map(t => t.amount);
  const avgAmount = amounts.reduce((sum, amount) => sum + amount, 0) / amounts.length;
  const threshold = avgAmount * 3;
  
  transactions.forEach(transaction => {
    if (transaction.amount > threshold) {
      anomalies.push({
        id: `anomaly-${Date.now()}-${Math.random()}`,
        transactionId: transaction.id,
        type: 'amount',
        severity: 'high',
        description: `Transaksi dengan nominal yang tidak biasa: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(transaction.amount)}`,
        confidence: 85
      });
    }
  });
  
  return anomalies;
};

export const generateExecutiveSummary = async (transactions: Transaction[]): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 1500));
  
  if (transactions.length === 0) {
    return "Belum ada data transaksi untuk dianalisis.";
  }
  
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  const netFlow = totalIncome - totalExpenses;
  
  return `🔍 **Ringkasan Eksekutif Keuangan**

**Statistik Transaksi:** ${transactions.length}
**Aliran Keuangan:**
- Pemasukan: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalIncome)}
- Pengeluaran: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalExpenses)}
- Saldo Bersih: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(netFlow)}

**Status:** ${netFlow > 0 ? '✅ Surplus' : '⚠️ Defisit'}`;
};

export const analyzeReceipt = async (base64Image: string): Promise<any> => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  const mockCategories = ['Makanan & Minuman', 'Transportasi', 'Belanja', 'Utilitas', 'Kesehatan', 'Hiburan'];
  const mockAmounts = [25000, 50000, 75000, 100000, 150000, 200000];
  const randomCategory = mockCategories[Math.floor(Math.random() * mockCategories.length)];
  const randomAmount = mockAmounts[Math.floor(Math.random() * mockAmounts.length)];
  
  return {
    description: `Pembelian ${randomCategory}`,
    category: randomCategory,
    amount: randomAmount,
    date: new Date().toISOString().split('T')[0],
    merchant: 'Toko ABC',
    integrity_score: Math.floor(Math.random() * 20) + 80,
    confidence: Math.floor(Math.random() * 15) + 85,
    extracted_text: `Receipt from merchant showing ${randomCategory} purchase`,
    analysis_notes: 'Receipt appears to be authentic with clear text and proper formatting'
  };
};

export const getChatResponse = async (message: string, history: ChatMessage[], transactions: Transaction[]): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('transaksi') || lowerMessage.includes('transaction')) {
    const totalBalance = transactions.reduce((sum, t) => sum + (t.type === 'income' ? t.amount : -t.amount), 0);
    return `📊 **Informasi Transaksi Anda:**
- Total Transaksi: ${transactions.length}
- Saldo Saat Ini: ${new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(totalBalance)}
- Transaksi Terbaru: ${transactions.length > 0 ? transactions[transactions.length - 1].description : 'Belum ada transaksi'}`;
  }
  
  return `Terima kasih atas pertanyaan Anda! 🤖 Saya adalah Kraken AI, asisten keuangan pintar yang siap membantu Anda menganalisis dan memahami keuangan dengan lebih baik.`;
};

export const getLegalChatResponse = async (message: string, history: ChatMessage[]): Promise<string> => {
  await new Promise(resolve => setTimeout(resolve, 1000));
  const lowerMessage = message.toLowerCase();
  
  if (lowerMessage.includes('korupsi') || lowerMessage.includes('corruption')) {
    return `⚖️ **Informasi Hukum: Anti-Korupsi**
Berdasarkan UU No. 31 Tahun 1999 jo UU No. 20 Tahun 2001 tentang Pemberantasan Tindak Pidana Korupsi, korupsi adalah tindakan melawan hukum dengan maksud memperkaya diri sendiri atau orang lain yang dapat merugikan keuangan negara.`;
  }
  
  return `⚖️ Selamat datang di Legal AI Consultant! Saya siap membantu memberikan informasi hukum umum terkait Anti-Korupsi dan Compliance.`;
};

export const generateFinancialForecast = async (transactions: Transaction[]): Promise<Forecast> => {
  await new Promise(resolve => setTimeout(resolve, 2000));
  
  if (transactions.length < 3) {
    throw new Error("Minimal 3 transaksi diperlukan untuk proyeksi keuangan yang akurat");
  }
  
  const totalIncome = transactions.filter(t => t.type === 'income').reduce((sum, t) => sum + t.amount, 0);
  const totalExpenses = transactions.filter(t => t.type === 'expense').reduce((sum, t) => sum + t.amount, 0);
  
  const avgMonthlyIncome = totalIncome / Math.max(1, transactions.filter(t => t.type === 'income').length);
  const avgMonthlyExpenses = totalExpenses / Math.max(1, transactions.filter(t => t.type === 'expense').length);
  
  const nextMonthIncome = avgMonthlyIncome * 1.05;
  const nextMonthExpenses = avgMonthlyExpenses * 1.03;
  const projectedBalance = nextMonthIncome - nextMonthExpenses;
  
  const recommendations = projectedBalance > 0 
    ? ["Kondisi keuangan proyeksi positif", "Pertimbangkan untuk menabung atau investasi"]
    : ["Proyeksi menunjukkan kemungkinan defisit", "Evaluasi dan kurangi pengeluaran tidak perlu"];
  
  return {
    nextMonthIncome,
    nextMonthExpenses,
    projectedBalance,
    confidence: Math.min(95, Math.max(60, 75 + (transactions.length * 2))),
    recommendations
  };
};

// Anti-Corruption Dashboard Functions
export const analyzeVendorRisk = async (vendorData: any) => {
  try {
    await new Promise(resolve => setTimeout(resolve, 1500));
    const riskScore = Math.floor(Math.random() * 40) + 60; // 60-100
    const riskLevel = riskScore < 70 ? 'high' : riskScore < 85 ? 'medium' : 'low';
    
    return {
      riskLevel,
      score: riskScore,
      analysis: `Analisis risiko vendor menunjukkan tingkat risiko ${riskLevel}.`,
      recommendations: riskLevel === 'high' 
        ? ['Lakukan due diligence mendalam', 'Monitoring ketat selama pelaksanaan']
        : ['Monitoring rutin', 'Evaluasi berkala'],
      riskFactors: []
    };
  } catch (error) {
    return {
      riskLevel: 'unknown',
      score: 0,
      analysis: 'Gagal menganalisis risiko vendor',
      recommendations: ['Review manual diperlukan'],
      riskFactors: []
    };
  }
};

export const generateComplianceReport = async (reportType: string = 'monthly') => {
  try {
    await new Promise(resolve => setTimeout(resolve, 1000));
    return {
      reportId: `RPT-${Date.now()}`,
      type: reportType,
      generatedAt: new Date().toISOString(),
      summary: `Laporan compliance ${reportType} telah berhasil dibuat. Sistem mendeteksi tingkat kepatuhan yang baik.`,
      status: 'completed',
      findings: [
        { category: 'Procurement', status: 'compliant', score: 85, details: 'Proses pengadaan mengikuti prosedur standar' },
        { category: 'Financial Controls', status: 'attention', score: 75, details: 'Beberapa transaksi memerlukan dokumentasi tambahan' }
      ],
      recommendations: ['Tingkatkan dokumentasi untuk kontrol keuangan', 'Lakukan pelatihan compliance rutin']
    };
  } catch (error) {
    return {
      reportId: `RPT-${Date.now()}`,
      type: reportType,
      generatedAt: new Date().toISOString(),
      summary: 'Gagal membuat laporan compliance',
      status: 'error',
      findings: [],
      recommendations: ['Coba buat laporan ulang', 'Periksa koneksi sistem']
    };
  }
};

export const getKrakenServiceStatus = async () => {
  try {
    await new Promise(resolve => setTimeout(resolve, 500));
    return {
      status: 'operational',
      uptime: '99.9%',
      lastCheck: new Date().toISOString(),
      services: { ai: 'operational', database: 'operational', api: 'operational' },
      metrics: { responseTime: '150ms', throughput: '1,250 req/min', errorRate: '0.1%' },
      version: '2.1.0',
      environment: 'production'
    };
  } catch (error) {
    return {
      status: 'error',
      uptime: 'unknown',
      lastCheck: new Date().toISOString(),
      services: { ai: 'error', database: 'error', api: 'error' },
      metrics: { responseTime: 'N/A', throughput: 'N/A', errorRate: 'N/A' },
      version: '2.1.0',
      environment: 'production'
    };
  }
};
