// Types untuk aplikasi Kraken AI
export interface Transaction {
  id: string;
  date: string;
  description: string;
  category: string;
  amount: number;
  type: 'income' | 'expense';
}

export interface Anomaly {
  id: string;
  transactionId: string;
  type: 'pattern' | 'amount' | 'frequency';
  severity: 'low' | 'medium' | 'high';
  description: string;
  confidence: number;
}

export enum AnalysisStatus {
  Idle = 'idle',
  Loading = 'loading',
  Success = 'success',
  Error = 'error'
}

export interface ChartDataItem {
  name: string;
  value: number;
  color: string;
}

export interface ChatMessage {
  id: string;
  content: string;
  isUser: boolean;
  timestamp: Date;
}

export interface Forecast {
  nextMonthIncome: number;
  nextMonthExpenses: number;
  projectedBalance: number;
  confidence: number;
  recommendations: string[];
}

export interface User {
  id: string;
  email: string;
  name: string;
  role: 'user' | 'admin';
  createdAt: Date;
}

export interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  isLoading: boolean;
}

// Types untuk Legal Education Center
export interface LegalArticle {
  id: string;
  chapter: string;
  article: string;
  title: string;
  content: string;
  explanation: string;
  category: 'civil-rights' | 'financial' | 'anti-corruption' | 'governance' | 'ethics' | 'public-service';
  importance: 'critical' | 'high' | 'medium' | 'low';
  relatedCases?: string[];
  penalties?: string;
  examples: string[];
}

export interface QuizQuestion {
  id: string;
  question: string;
  options: string[];
  correctAnswer: number;
  explanation: string;
  category: string;
  difficulty: 'easy' | 'medium' | 'hard';
  points: number;
  relatedArticleId?: string;
}

export interface LearningProgress {
  articlesRead: string[];
  quizzesCompleted: string[];
  totalPoints: number;
  currentLevel: 'beginner' | 'intermediate' | 'advanced' | 'expert';
  badges: string[];
  weeklyProgress: number;
  weeklyGoal: number;
  streak: number;
  lastActivityDate: Date;
}
