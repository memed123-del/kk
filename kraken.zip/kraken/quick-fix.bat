@echo off
echo 🔧 Kraken AI Quick Fix Script (Windows)
echo ======================================

REM Check if we're in the right directory
if not exist "App.tsx" (
    echo ❌ Error: Please run this script from the gg\ directory
    pause
    exit /b 1
)

echo 📂 Cleaning old files...
if exist "node_modules" rmdir /s /q "node_modules"
if exist "package-lock.json" del "package-lock.json"

echo 📝 Creating proper package.json...
(
echo {
echo   "name": "kraken-ai",
echo   "private": true,
echo   "version": "0.0.0",
echo   "type": "module",
echo   "scripts": {
echo     "dev": "vite --host 0.0.0.0 --port 5000",
echo     "build": "tsc ^&^& vite build",
echo     "preview": "vite preview"
echo   },
echo   "dependencies": {
echo     "react": "^18.2.0",
echo     "react-dom": "^18.2.0",
echo     "@google/genai": "^0.15.0",
echo     "recharts": "^2.8.0",
echo     "chart.js": "^4.4.0",
echo     "react-chartjs-2": "^5.2.0",
echo     "date-fns": "^2.30.0",
echo     "lucide-react": "^0.263.1",
echo     "clsx": "^2.1.0"
echo   },
echo   "devDependencies": {
echo     "@types/node": "^18.0.0",
echo     "@types/react": "^18.2.56",
echo     "@types/react-dom": "^18.2.19",
echo     "@vitejs/plugin-react": "^3.1.0",
echo     "typescript": "~4.9.5",
echo     "vite": "^3.2.0"
echo   }
echo }
) > package.json

echo 📦 Installing dependencies...
npm install --legacy-peer-deps

echo ✅ Setup complete!
echo.
echo 🚀 To start the development server, run:
echo    npm run dev
echo.
echo 📍 Your app will be available at: http://localhost:5000
echo.
echo 🎯 Starting development server...
npm run dev

pause