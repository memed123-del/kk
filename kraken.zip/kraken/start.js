const { createServer } = require('vite');

async function startServer() {
  try {
    const server = await createServer({
      server: {
        port: 5000,
        host: '0.0.0.0'
      }
    });
    
    await server.listen();
    console.log('Server running at http://localhost:5000');
  } catch (error) {
    console.error('Error starting server:', error);
  }
}

startServer();
