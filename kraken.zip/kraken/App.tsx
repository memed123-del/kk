import React, { useState, useEffect, useMemo, useCallback, useRef } from 'react';
import { Transaction, Anomaly, AnalysisStatus, ChartDataItem, ChatMessage, Forecast, User, AuthState } from './types';
import { MOCK_TRANSACTIONS } from './constants';
import { analyzeTransactionsForAnomalies, generateExecutiveSummary, analyzeReceipt, getChatResponse, getLegalChatResponse, generateFinancialForecast } from './services/geminiService';
import Header from './components/Header';
import SummaryCard from './components/SummaryCard';
import TransactionTable from './components/TransactionTable';
import AnomalyAlert from './components/AnomalyAlert';
import LoadingSpinner from './components/LoadingSpinner';
import DonutChart from './components/DonutChart';
import BarChart from './components/BarChart';
import ChatInterface from './components/Chat';
import LegalAI from './components/LegalAI';
import AntiCorruptionDashboard from './components/AntiCorruptionDashboard';
import ProfessionalControlCenter from './components/ProfessionalControlCenter';
import LegalEducationCenter from './components/LegalEducationCenter';
import AuthPage from './components/AuthPage';

import { BanknotesIcon, ArrowTrendingUpIcon, ArrowTrendingDownIcon, ExclamationTriangleIcon, PlusIcon, XMarkIcon, SearchIcon, AuditIcon, ChartPieIcon, BookOpenIcon, CameraIcon, ChartBarSquareIcon, ArrowsPointingOutIcon, ArrowsPointingInIcon, ScaleIcon } from './components/Icons';
import DeepSeekStyleLogo from './components/DeepSeekStyleLogo';


const LoadingScreen: React.FC = () => (
    <div className="flex flex-col items-center justify-center min-h-screen bg-gradient-to-br from-blue-50 via-white to-cyan-50">
        <div className="relative">
            <div className="w-32 h-32 bg-white rounded-2xl shadow-xl border border-blue-100 flex items-center justify-center">
                <DeepSeekStyleLogo size={80} className="text-blue-600 animate-pulse kraken-logo" />
            </div>
            <div className="absolute -inset-4 bg-gradient-to-r from-blue-400 to-cyan-400 rounded-3xl opacity-20 blur-lg"></div>
        </div>
        <p className="mt-6 text-lg font-bold text-gray-800 tracking-wider drop-shadow-sm">
            Made by <span className="text-blue-600">Azkiah</span>
        </p>
    </div>
);

// --- Komponen Modal (Tidak Berubah) ---
interface ModalProps {
    isOpen: boolean;
    onClose: () => void;
    title: string;
    children: React.ReactNode;
}

const Modal: React.FC<ModalProps> = ({ isOpen, onClose, title, children }) => {
    if (!isOpen) return null;

    return (
        <div 
            className="fixed inset-0 bg-black bg-opacity-70 z-50 flex justify-center items-center backdrop-blur-sm"
            aria-modal="true"
            role="dialog"
            onClick={onClose}
        >
            <div 
                className="bg-white border border-gray-200 rounded-2xl shadow-xl w-full max-w-md m-4 p-6 relative"
                onClick={(e) => e.stopPropagation()}
            >
                <div className="flex justify-between items-center mb-4">
                    <h3 className="text-xl font-bold text-gray-900">{title}</h3>
                    <button
                        onClick={onClose}
                        className="text-gray-400 hover:text-gray-600"
                        aria-label="Tutup modal"
                    >
                        <XMarkIcon className="w-6 h-6" />
                    </button>
                </div>
                {children}
            </div>
        </div>
    );
};

// --- Komponen Form Tambah Transaksi (Tidak Berubah) ---
interface AddTransactionFormProps {
    onAddTransaction: (transaction: Transaction) => void;
    onClose: () => void;
}

const AddTransactionForm: React.FC<AddTransactionFormProps> = ({ onAddTransaction, onClose }) => {
    const [description, setDescription] = useState('');
    const [category, setCategory] = useState('');
    const [amount, setAmount] = useState<number | ''>('');
    const [type, setType] = useState<'income' | 'expense'>('expense');
    const [date, setDate] = useState(new Date().toISOString().split('T')[0]);
    const [error, setError] = useState('');
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [analysisError, setAnalysisError] = useState('');

    const formatNumberInput = (num: number | ''): string => {
        if (num === '') return '';
        return new Intl.NumberFormat('id-ID').format(num);
    };

    const handleAmountChange = (e: React.ChangeEvent<HTMLInputElement>) => {
        const rawValue = e.target.value;
        const numericValue = rawValue.replace(/\D/g, ''); 
        
        if (numericValue === '') {
            setAmount('');
        } else {
            setAmount(parseInt(numericValue, 10));
        }
    };
    
    const fileToBase64 = (file: File): Promise<string> => {
        return new Promise((resolve, reject) => {
            const reader = new FileReader();
            reader.readAsDataURL(file);
            reader.onload = () => resolve((reader.result as string).split(',')[1]);
            reader.onerror = error => reject(error);
        });
    };

    const handleReceiptUpload = async (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (!file) return;

        setIsAnalyzing(true);
        setAnalysisError('');
        setError('');

        try {
            const base64Image = await fileToBase64(file);
            const result = await analyzeReceipt(base64Image);
            
            setDescription(result.description || '');
            setCategory(result.category || '');
            setAmount(result.amount || '');
            const resultDate = new Date(result.date || '');
            if (!isNaN(resultDate.getTime())) {
                 setDate(result.date || '');
            } else {
                setDate(new Date().toISOString().split('T')[0]);
            }
            setType('expense');

            // Show fraud detection warnings if any
            const fraudResult = result as any;
            if (fraudResult.suspicion_flags && fraudResult.suspicion_flags.length > 0) {
                setAnalysisError(
                    `⚠️ PERINGATAN FRAUD: ${fraudResult.suspicion_flags.join(', ')}. ` +
                    `Skor Integritas: ${fraudResult.integrity_score || 0}/100. ` +
                    `Status Vendor: ${fraudResult.vendor_verification || 'Unknown'}.`
                );
            } else if (fraudResult.integrity_score && fraudResult.integrity_score < 70) {
                setAnalysisError(
                    `⚠️ Struk perlu verifikasi tambahan. Skor integritas rendah: ${fraudResult.integrity_score}/100`
                );
            }

        } catch (err) {
            console.error("Receipt analysis failed:", err);
            setAnalysisError("Gagal menganalisis struk. Mohon coba lagi atau isi manual.");
        } finally {
            setIsAnalyzing(false);
            event.target.value = '';
        }
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        const numAmount = typeof amount === 'number' ? amount : 0;

        if (!description || !category || !amount || !date) {
            setError('Semua kolom harus diisi.');
            return;
        }
        if (isNaN(numAmount) || numAmount <= 0) {
            setError('Jumlah harus berupa angka positif.');
            return;
        }
        setError('');
        
        const newTransaction: Transaction = {
            id: `txn_${Date.now()}`,
            date,
            description,
            category,
            amount: numAmount,
            type,
        };

        onAddTransaction(newTransaction);
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-4 relative">
            {isAnalyzing && (
                 <div className="absolute inset-0 bg-white/80 backdrop-blur-sm flex flex-col justify-center items-center z-20 rounded-lg">
                    <LoadingSpinner />
                    <p className="mt-4 text-cyan-600">Menganalisis Struk Cerdas...</p>
                </div>
            )}
             <div className="p-3 bg-gray-50 border border-dashed border-gray-300 rounded-lg text-center">
                <label htmlFor="receipt-upload" className="cursor-pointer group">
                    <div className="flex flex-col items-center justify-center">
                        <CameraIcon className="w-8 h-8 text-gray-400 group-hover:text-cyan-600 transition-colors" />
                        <p className="mt-1 text-sm text-gray-600"><span className="font-semibold text-cyan-600">Unggah Struk</span> untuk isi otomatis</p>
                        <p className="text-xs text-gray-500">PNG, JPG, WEBP</p>
                    </div>
                </label>
                <input id="receipt-upload" type="file" className="sr-only" accept="image/*" onChange={handleReceiptUpload} />
            </div>

            <div className="flex items-center my-4">
                <hr className="flex-grow border-t border-gray-300"/>
                <span className="px-3 text-xs text-gray-500 uppercase">Atau Isi Manual</span>
                <hr className="flex-grow border-t border-gray-300"/>
            </div>

            {analysisError && <div className="bg-yellow-50 border border-yellow-200 text-yellow-700 px-4 py-3 rounded-lg" role="alert">{analysisError}</div>}
            {error && <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg" role="alert">{error}</div>}
            <div>
                <label htmlFor="description" className="block text-sm font-medium text-gray-700">Deskripsi</label>
                <input
                    type="text"
                    id="description"
                    value={description}
                    onChange={(e) => setDescription(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm text-gray-900 focus:bg-white"
                    required
                />
            </div>
             <div>
                <label htmlFor="category" className="block text-sm font-medium text-gray-700">Kategori</label>
                <input
                    type="text"
                    id="category"
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm text-gray-900 focus:bg-white"
                    required
                />
            </div>
             <div>
                <label htmlFor="amount" className="block text-sm font-medium text-gray-700">Jumlah (IDR)</label>
                <input
                    type="text"
                    inputMode="decimal"
                    id="amount"
                    value={formatNumberInput(amount)}
                    onChange={handleAmountChange}
                    placeholder="Contoh: 50000"
                    className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm text-gray-900 focus:bg-white"
                    required
                />
            </div>
             <div>
                <label htmlFor="type" className="block text-sm font-medium text-gray-700">Tipe</label>
                <select
                    id="type"
                    value={type}
                    onChange={(e) => setType(e.target.value as 'income' | 'expense')}
                    className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm text-gray-900 focus:bg-white"
                >
                    <option value="expense">Pengeluaran</option>
                    <option value="income">Pemasukan</option>
                </select>
            </div>
            <div>
                <label htmlFor="date" className="block text-sm font-medium text-gray-700">Tanggal</label>
                <input
                    type="date"
                    id="date"
                    value={date}
                    onChange={(e) => setDate(e.target.value)}
                    className="mt-1 block w-full px-3 py-2 bg-gray-50 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-cyan-500 focus:border-cyan-500 sm:text-sm text-gray-900 focus:bg-white"
                    required
                />
            </div>
            <div className="flex justify-end gap-4 pt-4">
                <button type="button" onClick={onClose} className="px-4 py-2 text-sm font-medium text-gray-700 bg-gray-200 rounded-md hover:bg-gray-300">
                    Batal
                </button>
                <button type="submit" className="px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-md hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 focus:ring-offset-white">
                    Simpan Transaksi
                </button>
            </div>
        </form>
    );
};

// --- Komponen Kartu Proyeksi ---
const ForecastCard: React.FC<{ forecast: Forecast | null, status: AnalysisStatus }> = ({ forecast, status }) => {
    const formatCurrency = (amount: number) => new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR', minimumFractionDigits: 0 }).format(amount);
    
    return (
        <div className="lg:col-span-3 bg-white border border-gray-200 p-6 rounded-2xl shadow-lg">
            <div className="flex items-center gap-3 mb-4">
                <ChartBarSquareIcon className="w-7 h-7 text-cyan-600" />
                <h2 className="text-xl font-bold text-gray-900">Proyeksi Keuangan AI (Bulan Berikutnya)</h2>
            </div>
            {status === AnalysisStatus.Loading && (
                <div className="flex items-center gap-3 text-gray-600">
                    <LoadingSpinner />
                    <span>Menganalisis tren masa depan...</span>
                </div>
            )}
            {status === AnalysisStatus.Error && <p className="text-red-600">Gagal menghasilkan proyeksi. Mungkin butuh lebih banyak data historis.</p>}
            {status === AnalysisStatus.Idle && <p className="text-gray-500">Tambahkan lebih banyak transaksi untuk mendapatkan proyeksi keuangan.</p>}
            {status === AnalysisStatus.Success && forecast && (
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6 items-start">
                    <div className="md:col-span-1 space-y-4">
                        <div>
                            <p className="text-sm text-green-600 font-semibold">Proyeksi Pemasukan</p>
                            <p className="text-2xl font-bold text-gray-900">{formatCurrency(forecast.forecastedIncome)}</p>
                        </div>
                         <div>
                            <p className="text-sm text-red-600 font-semibold">Proyeksi Pengeluaran</p>
                            <p className="text-2xl font-bold text-gray-900">{formatCurrency(forecast.forecastedExpenses)}</p>
                        </div>
                    </div>
                    <div className="md:col-span-2">
                         <p className="text-sm text-gray-600 font-semibold mb-2">Wawasan AI:</p>
                         <p className="text-gray-700 leading-relaxed text-sm">{forecast.insights}</p>
                    </div>
                </div>
            )}
        </div>
    );
};


// --- Komponen Utama Aplikasi ---
const App: React.FC = () => {
    // Authentication state
    const [authState, setAuthState] = useState<AuthState>({
        user: null,
        isAuthenticated: false,
        isLoading: false
    });

    const [isLoading, setIsLoading] = useState(true);
    const [transactions, setTransactions] = useState<Transaction[]>(MOCK_TRANSACTIONS);
    const [anomalies, setAnomalies] = useState<Anomaly[]>([]);
    const [status, setStatus] = useState<AnalysisStatus>(AnalysisStatus.Idle);
    const [summaryStatus, setSummaryStatus] = useState<AnalysisStatus>(AnalysisStatus.Idle);
    const [forecast, setForecast] = useState<Forecast | null>(null);
    const [forecastStatus, setForecastStatus] = useState<AnalysisStatus>(AnalysisStatus.Idle);
    const [error, setError] = useState<string | null>(null);
    const [isModalOpen, setIsModalOpen] = useState(false);
    const [searchTerm, setSearchTerm] = useState('');
    const [activeTab, setActiveTab] = useState<'dashboard' | 'bukuBesar' | 'antiKorupsi' | 'controlCenter' | 'legalEducation' | 'financialAI' | 'legalAI'>('dashboard');
    const [executiveSummary, setExecutiveSummary] = useState<string>('');
    
    // State untuk Financial AI
    const [financialChatHistory, setFinancialChatHistory] = useState<ChatMessage[]>([
        { role: 'model', parts: 'Selamat datang di ruang diskusi Kraken AI. Saya adalah asisten keuangan cerdas Anda. Silakan ajukan pertanyaan apa pun mengenai data keuangan untuk mendapatkan analisis dan saran.' }
    ]);
    const [isFinancialChatLoading, setIsFinancialChatLoading] = useState(false);
    
    // State untuk Legal AI
    const [legalChatHistory, setLegalChatHistory] = useState<ChatMessage[]>([
        { role: 'model', parts: 'Selamat datang di konsultan hukum Kraken AI. Saya adalah spesialis hukum digital Anda. Tanyakan tentang UUD 1945, anti-korupsi, atau aspek hukum lainnya untuk mendapatkan pemahaman yang mendalam.' }
    ]);
    const [isLegalChatLoading, setIsLegalChatLoading] = useState(false);
    
    const [isFullscreen, setIsFullscreen] = useState(false);
    
    // API Keys purely from .env.local
    const [financialApiKey, setFinancialApiKey] = useState(() => {
        const key = import.meta.env.VITE_FINANCIAL_API_KEY || '';
        console.log('🔑 Financial API Key loaded:', key ? `${key.substring(0, 10)}...` : 'NOT FOUND');
        return key;
    });
    const [legalApiKey, setLegalApiKey] = useState(() => {
        const key = import.meta.env.VITE_LEGAL_API_KEY || '';
        console.log('⚖️ Legal API Key loaded:', key ? `${key.substring(0, 10)}...` : 'NOT FOUND');
        return key;
    });

    // Authentication handlers
    const handleLogin = (user: User) => {
        setAuthState({
            user,
            isAuthenticated: true,
            isLoading: false
        });
    };

    const handleLogout = () => {
        setAuthState({
            user: null,
            isAuthenticated: false,
            isLoading: false
        });
    };

    useEffect(() => {
        const timer = setTimeout(() => {
            setIsLoading(false);
        }, 500);
        return () => clearTimeout(timer);
    }, []);

    const { totalIncome, totalExpenses, balance } = useMemo(() => {
        return transactions.reduce(
            (acc, t) => {
                if (t.type === 'income') {
                    acc.totalIncome += t.amount;
                } else {
                    acc.totalExpenses += t.amount;
                }
                acc.balance = acc.totalIncome - acc.totalExpenses;
                return acc;
            },
            { totalIncome: 0, totalExpenses: 0, balance: 0 }
        );
    }, [transactions]);

    const analyzeData = useCallback(async () => {
        if (transactions.length < 5) { // Needs more data for better analysis & forecast
            setStatus(AnalysisStatus.Idle);
            setSummaryStatus(AnalysisStatus.Idle);
            setForecastStatus(AnalysisStatus.Idle);
            setAnomalies([]);
            setExecutiveSummary('');
            setForecast(null);
            return;
        }
        setStatus(AnalysisStatus.Loading);
        setSummaryStatus(AnalysisStatus.Loading);
        setForecastStatus(AnalysisStatus.Loading);
        setError(null);
        try {
            const anomalyResults = await analyzeTransactionsForAnomalies(transactions);
            setAnomalies(anomalyResults);
            setStatus(AnalysisStatus.Success);
            
            const summaryResult = await generateExecutiveSummary(transactions, anomalyResults, balance);
            setExecutiveSummary(summaryResult);
            setSummaryStatus(AnalysisStatus.Success);

            const forecastResult = await generateFinancialForecast(transactions);
            setForecast(forecastResult);
            setForecastStatus(AnalysisStatus.Success);


        } catch (err) {
            console.error("Error during analysis:", err);
            const errorObj = err as any;
            let errorMessage = "Gagal menganalisis data keuangan. Kraken AI mungkin tidak tersedia. Silakan coba lagi nanti.";
            
            // Better error messages for API key issues
            if (errorObj?.message?.includes('No API keys available') || errorObj?.message?.includes('API key')) {
                errorMessage = "⚠️ API Key Gemini diperlukan untuk analisis AI. Silakan tambahkan transaksi minimal 5 untuk memulai analisis atau periksa konfigurasi API key.";
            } else if (errorObj?.message?.includes('quota') || errorObj?.message?.includes('limit')) {
                errorMessage = "🚫 Kuota API Gemini habis. Silakan gunakan API key lain atau tunggu reset harian.";
            }
            
            setError(errorMessage);
            setStatus(AnalysisStatus.Error);
            setExecutiveSummary(errorMessage);
            setSummaryStatus(AnalysisStatus.Error);
            setForecastStatus(AnalysisStatus.Error);
        }
    }, [transactions, balance]);

    useEffect(() => {
        if (transactions.length > 0) {
            analyzeData();
        }
    }, [transactions, analyzeData]);

    const filteredTransactions = useMemo(() => {
        if (!searchTerm.trim()) {
            return transactions;
        }
        const lowercasedFilter = searchTerm.toLowerCase();
        return transactions.filter(transaction =>
            transaction.description.toLowerCase().includes(lowercasedFilter) ||
            transaction.category.toLowerCase().includes(lowercasedFilter)
        );
    }, [searchTerm, transactions]);

    const handleAddTransaction = (newTransaction: Transaction) => {
        setTransactions(prevTransactions => [...prevTransactions, newTransaction].sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime()));
        setIsModalOpen(false);
    };

    const handleSendFinancialChatMessage = async (message: string, fileContent?: string) => {
        if ((!message.trim() && !fileContent) || isFinancialChatLoading) return;
        
        // Extract filename from fileContent if it's a base64 image
        let fileName: string | undefined;
        let isImage = false;
        
        if (fileContent?.startsWith('data:image/')) {
            isImage = true;
            // Extract filename from message or use default
            const fileNameMatch = message.match(/(?:Analisis (?:gambar|file) terlampir: )(.+)/);
            fileName = fileNameMatch?.[1] || 'uploaded-image.jpg';
        }
        
        const userMessageText = fileContent 
            ? (isImage ? message : `${message}\n\nLampiran file: "${fileName || 'uploaded-file'}"`)
            : message;

        const newUserMessage: ChatMessage = { 
            role: 'user', 
            parts: userMessageText,
            imageData: isImage ? fileContent : undefined,
            fileName: fileName
        };
        setFinancialChatHistory(prev => [...prev, newUserMessage]);
        setIsFinancialChatLoading(true);

        try {
            console.log('🚀 Sending message to Financial AI...');
            console.log('🔑 Using API Key:', financialApiKey ? `${financialApiKey.substring(0, 10)}...` : 'NO API KEY');
            
            const financialContext = { transactions, anomalies, balance };
            const response = await getChatResponse(financialChatHistory, newUserMessage, financialContext, fileContent, financialApiKey);
            const modelResponse: ChatMessage = { role: 'model', parts: response };
            setFinancialChatHistory(prev => [...prev, modelResponse]);
        } catch (err) {
            console.error("💥 Financial AI error:", err);
            const errorResponse: ChatMessage = { role: 'model', parts: "Maaf, terjadi kesalahan saat menghubungi AI Keuangan Kraken. Silakan coba lagi." };
            setFinancialChatHistory(prev => [...prev, errorResponse]);
        } finally {
            setIsFinancialChatLoading(false);
        }
    };

    const handleSendLegalChatMessage = async (message: string, fileContent?: string) => {
        if ((!message.trim() && !fileContent) || isLegalChatLoading) return;
        
        // Extract filename from fileContent if it's a base64 image
        let fileName: string | undefined;
        let isImage = false;
        
        if (fileContent?.startsWith('data:image/')) {
            isImage = true;
            // Extract filename from message or use default
            const fileNameMatch = message.match(/(?:Analisis (?:gambar|file) terlampir: )(.+)/);
            fileName = fileNameMatch?.[1] || 'uploaded-image.jpg';
        }
        
        const userMessageText = fileContent 
            ? (isImage ? message : `${message}\n\nLampiran dokumen hukum: "${fileName || 'uploaded-file'}"`)
            : message;

        const newUserMessage: ChatMessage = { 
            role: 'user', 
            parts: userMessageText,
            imageData: isImage ? fileContent : undefined,
            fileName: fileName
        };
        setLegalChatHistory(prev => [...prev, newUserMessage]);
        setIsLegalChatLoading(true);

        try {
            // Use dedicated legal AI function
            const response = await getLegalChatResponse(legalChatHistory, newUserMessage, fileContent, legalApiKey);
            const modelResponse: ChatMessage = { role: 'model', parts: response };
            setLegalChatHistory(prev => [...prev, modelResponse]);
        } catch (err) {
            console.error("Legal AI error:", err);
            const errorMessage = (err as Error)?.message || '';
            
            let userFriendlyError = "Maaf, terjadi kesalahan saat menghubungi AI Hukum Kraken. Silakan coba lagi.";
            
            if (errorMessage.includes('API key') || errorMessage.includes('No valid API keys')) {
                userFriendlyError = "⚠️ **Konfigurasi API Key Diperlukan**\n\nUntuk menggunakan AI Hukum Kraken, silakan:\n\n1. Buka file `.env.local` di root project\n2. Ganti `your_gemini_api_key_here` dengan API Key Gemini yang valid\n3. Restart aplikasi (`npm run dev`)\n\n📝 **Cara mendapatkan API Key:**\n- Kunjungi [Google AI Studio](https://aistudio.google.com/)\n- Login dan buat API Key baru\n- Copy dan paste ke file `.env.local`";
            } else if (errorMessage.includes('quota') || errorMessage.includes('limit')) {
                userFriendlyError = "🚫 **Quota API Habis**\n\nAPI Key Gemini telah mencapai batas penggunaan. Silakan:\n\n1. Gunakan API Key yang berbeda di `.env.local`\n2. Atau tunggu reset quota harian\n3. Upgrade plan di Google AI Studio jika diperlukan";
            }
            
            const errorResponse: ChatMessage = { role: 'model', parts: userFriendlyError };
            setLegalChatHistory(prev => [...prev, errorResponse]);
        } finally {
            setIsLegalChatLoading(false);
        }
    };


    
    const handleToggleFullscreen = () => {
        setIsFullscreen(!isFullscreen);
        // When entering fullscreen, keep current AI tab active
        if (!isFullscreen && activeTab !== 'financialAI' && activeTab !== 'legalAI') {
            setActiveTab('financialAI'); // Default to financial AI
        }
    };
    
    const TAB_CLASSES = "flex items-center gap-2 px-4 py-2.5 text-sm font-semibold rounded-lg transition-colors duration-200";
    const ACTIVE_TAB_CLASSES = "bg-cyan-100 text-cyan-700 border border-cyan-200";
    const INACTIVE_TAB_CLASSES = "text-gray-600 hover:bg-gray-100 hover:text-gray-800";
    const LEGAL_ACTIVE_TAB_CLASSES = "bg-gradient-to-r from-amber-100 to-yellow-100 text-amber-700 border border-amber-300 shadow-lg";
    const LEGAL_INACTIVE_TAB_CLASSES = "text-amber-600 hover:bg-amber-50 hover:text-amber-700 border border-amber-200";

    const { donutChartData, barChartData } = useMemo(() => {
        const expenseByCategory = transactions
            .filter(t => t.type === 'expense')
            .reduce((acc, t) => {
                acc[t.category] = (acc[t.category] || 0) + t.amount;
                return acc;
            }, {} as Record<string, number>);

        const colors = ['#22d3ee', '#34d399', '#f87171', '#fbbf24', '#a78bfa', '#ec4899'];
        const dcd = Object.entries(expenseByCategory).map(([name, value], index) => ({
            name,
            value,
            color: colors[index % colors.length],
        }));

        const bcd = [
            { name: 'Pemasukan', value: totalIncome, color: '#34d399' },
            { name: 'Pengeluaran', value: totalExpenses, color: '#f87171' },
        ];
        return { donutChartData: dcd, barChartData: bcd };
    }, [transactions, totalIncome, totalExpenses]);

    if (isLoading) {
        return <LoadingScreen />;
    }

    // Show auth page if not authenticated
    if (!authState.isAuthenticated) {
        return <AuthPage onLogin={handleLogin} />;
    }

    return (
        <div className={`min-h-screen bg-white text-gray-900 font-sans flex flex-col ${isFullscreen && (activeTab === 'financialAI' || activeTab === 'legalAI') ? 'overflow-hidden' : ''}`}>
            {!isFullscreen && <Header user={authState.user!} onLogout={handleLogout} />}
            <main className={`${!isFullscreen ? 'p-4 sm:p-6 lg:p-8' : 'p-0'} w-full flex-grow flex flex-col ${(activeTab !== 'financialAI' && activeTab !== 'legalAI') || !isFullscreen ? 'max-w-7xl mx-auto' : ''}`}>
                {!isFullscreen && (
                    <div className="mb-6 flex items-center justify-between">
                         <div className="flex items-center gap-2 p-1 bg-gray-100 border border-gray-200 rounded-xl">
                            <button onClick={() => setActiveTab('dashboard')} className={`${TAB_CLASSES} ${activeTab === 'dashboard' ? ACTIVE_TAB_CLASSES : INACTIVE_TAB_CLASSES}`}>
                               <ChartPieIcon className="w-5 h-5" /> Dasbor Intelijen
                            </button>
                             <button onClick={() => setActiveTab('bukuBesar')} className={`${TAB_CLASSES} ${activeTab === 'bukuBesar' ? ACTIVE_TAB_CLASSES : INACTIVE_TAB_CLASSES}`}>
                               <BookOpenIcon className="w-5 h-5" /> Buku Besar
                            </button>
                             <button onClick={() => setActiveTab('antiKorupsi')} className={`${TAB_CLASSES} ${activeTab === 'antiKorupsi' ? ACTIVE_TAB_CLASSES : INACTIVE_TAB_CLASSES}`}>
                               <AuditIcon className="w-5 h-5" /> Anti-Korupsi
                            </button>
                             <button onClick={() => setActiveTab('controlCenter')} className={`${TAB_CLASSES} ${activeTab === 'controlCenter' ? ACTIVE_TAB_CLASSES : INACTIVE_TAB_CLASSES}`}>
                               <ChartBarSquareIcon className="w-5 h-5" /> Pusat Kontrol
                            </button>
                             <button onClick={() => setActiveTab('legalEducation')} className={`${TAB_CLASSES} ${activeTab === 'legalEducation' ? ACTIVE_TAB_CLASSES : INACTIVE_TAB_CLASSES}`}>
                               <BookOpenIcon className="w-5 h-5" /> Edukasi Hukum
                            </button>
                             <button onClick={() => setActiveTab('financialAI')} className={`${TAB_CLASSES} ${activeTab === 'financialAI' ? ACTIVE_TAB_CLASSES : INACTIVE_TAB_CLASSES}`}>
                               <KrakenLogo size={20} /> AI Keuangan
                            </button>
                             <button onClick={() => setActiveTab('legalAI')} className={`${TAB_CLASSES} ${activeTab === 'legalAI' ? LEGAL_ACTIVE_TAB_CLASSES : LEGAL_INACTIVE_TAB_CLASSES}`}>
                                <ScaleIcon className="w-5 h-5" /> AI Hukum
                             </button>
                        </div>
                         {activeTab !== 'financialAI' && activeTab !== 'legalAI' && activeTab !== 'antiKorupsi' && activeTab !== 'controlCenter' && activeTab !== 'legalEducation' && (
                             <button
                                onClick={() => setIsModalOpen(true)}
                                className="flex items-center gap-2 px-4 py-2 text-sm font-medium text-white bg-cyan-600 rounded-lg hover:bg-cyan-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-cyan-500 focus:ring-offset-white shadow-sm"
                            >
                                <PlusIcon className="w-5 h-5" />
                                <span>Tambah Transaksi</span>
                            </button>
                        )}
                    </div>
                )}

                {activeTab !== 'financialAI' && activeTab !== 'legalAI' && (
                    <div className="space-y-8">
                        {activeTab === 'dashboard' && (
                             <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                                <div className="lg:col-span-3">
                                    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
                                        <SummaryCard title="Total Pemasukan" value={totalIncome} icon={<ArrowTrendingUpIcon />} color="text-green-400" />
                                        <SummaryCard title="Total Pengeluaran" value={totalExpenses} icon={<ArrowTrendingDownIcon />} color="text-red-400" />
                                        <SummaryCard title="Saldo Saat Ini" value={balance} icon={<BanknotesIcon />} color="text-cyan-400" />
                                        <SummaryCard title="Anomali Terdeteksi" value={anomalies.length} icon={<ExclamationTriangleIcon />} color="text-yellow-400" />
                                    </div>
                                </div>
                                <div className="lg:col-span-3 bg-white border border-gray-200 p-6 rounded-2xl shadow-lg">
                                    <h2 className="text-xl font-bold text-gray-900 mb-3">Ringkasan Eksekutif AI</h2>
                                    {summaryStatus === AnalysisStatus.Loading && (
                                        <div className="flex items-center gap-3 text-gray-600">
                                            <LoadingSpinner />
                                            <span>Menghasilkan ringkasan cerdas...</span>
                                        </div>
                                    )}
                                    {summaryStatus === AnalysisStatus.Error && <p className="text-red-600">{executiveSummary}</p>}
                                    {summaryStatus === AnalysisStatus.Success && <p className="text-gray-700 leading-relaxed">{executiveSummary}</p>}
                                     {summaryStatus === AnalysisStatus.Idle && transactions.length > 0 && <p className="text-gray-500">Analisis membutuhkan lebih banyak data. Silakan tambahkan minimal 5 transaksi.</p>}
                                     {summaryStatus === AnalysisStatus.Idle && transactions.length === 0 && <p className="text-gray-500">Tambahkan transaksi untuk menghasilkan ringkasan.</p>}
                                </div>
        
                                 <ForecastCard forecast={forecast} status={forecastStatus} />

                                <div className="lg:col-span-1 bg-slate-800/40 border border-slate-700 p-6 rounded-2xl shadow-lg backdrop-blur-sm">
                                   <h2 className="text-xl font-bold text-white mb-4">Alokasi Dana</h2>
                                   {donutChartData.length > 0 ? <DonutChart data={donutChartData} /> : <p className="text-center text-gray-500 pt-16">Belum ada data pengeluaran.</p>}
                                </div>
                                <div className="lg:col-span-2 bg-slate-800/40 border border-slate-700 p-6 rounded-2xl shadow-lg backdrop-blur-sm">
                                   <h2 className="text-xl font-bold text-white mb-4">Arus Kas</h2>
                                   {barChartData.some(d => d.value > 0) ? <BarChart data={barChartData} /> : <p className="text-center text-gray-500 pt-16">Belum ada data pemasukan atau pengeluaran.</p>}
                                </div>
        
                                <div className="lg:col-span-3 bg-slate-800/40 border border-slate-700 p-6 rounded-2xl shadow-lg backdrop-blur-sm">
                                    <div className="flex items-center gap-3 mb-4">
                                        <AuditIcon className="w-8 h-8 text-cyan-400" />
                                        <h2 className="text-2xl font-bold text-white">Laporan Auditor Kraken AI</h2>
                                    </div>
                                    {status === AnalysisStatus.Loading && <div className="text-center py-8"><LoadingSpinner /><p className="mt-2 text-gray-400">Menganalisis anomali...</p></div>}
                                    {status === AnalysisStatus.Error && <div className="bg-red-900/50 border-l-4 border-red-500 text-red-300 p-4 rounded-md" role="alert"><p className="font-bold">Terjadi Kesalahan</p><p>{error}</p></div>}
                                    {status === AnalysisStatus.Success && (
                                        <div className="space-y-4">
                                            {anomalies.length === 0 ? (
                                                <div className="text-center py-8"><AuditIcon className="w-16 h-16 text-green-500 mx-auto mb-4" /><p className="text-xl font-semibold text-gray-200">Tidak Ditemukan Anomali</p><p className="text-gray-400 mt-2">Semua tampak aman.</p></div>
                                            ) : (
                                                anomalies.map(anomaly => <AnomalyAlert key={anomaly.transactionId} anomaly={anomaly} transaction={transactions.find(t => t.id === anomaly.transactionId)} />)
                                            )}
                                        </div>
                                    )}
                                    {status === AnalysisStatus.Idle && <p className="text-center text-gray-400 py-8">Analisis anomali akan dimulai setelah data yang cukup dimasukkan.</p>}
                                </div>
                             </div>
                        )}
                        
                        {activeTab === 'bukuBesar' && (
                             <div className="bg-white border border-gray-200 p-6 rounded-2xl shadow-lg">
                                <div className="relative mb-4">
                                    <input
                                        type="text"
                                        placeholder="Cari berdasarkan deskripsi atau kategori..."
                                        value={searchTerm}
                                        onChange={(e) => setSearchTerm(e.target.value)}
                                        className="w-full pl-10 pr-4 py-2 bg-gray-50 border border-gray-300 rounded-lg text-gray-900 focus:ring-cyan-500 focus:border-cyan-500 focus:bg-white"
                                    />
                                    <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                                        <SearchIcon className="w-5 h-5 text-gray-400" />
                                    </div>
                                </div>
                                <TransactionTable transactions={filteredTransactions} anomalies={anomalies} />
                            </div>
                        )}
                        
                        {activeTab === 'antiKorupsi' && (
                            <AntiCorruptionDashboard 
                                transactions={transactions} 
                                anomalies={anomalies} 
                            />
                        )}
                    </div>
                )}


                {activeTab === 'controlCenter' && <ProfessionalControlCenter transactions={transactions} anomalies={anomalies} balance={balance} />}
                
                {activeTab === 'legalEducation' && <LegalEducationCenter />}

                {activeTab === 'financialAI' && (
                    <div className={`flex flex-col ${isFullscreen ? 'h-screen' : 'h-full'}`}>
                        <ChatInterface
                            chatHistory={financialChatHistory}
                            isChatLoading={isFinancialChatLoading}
                            onSendMessage={handleSendFinancialChatMessage}
                            isFullscreen={isFullscreen}
                            onToggleFullscreen={handleToggleFullscreen}
                            showApiKeyWarning={!financialApiKey.trim()}
                        />
                    </div>
                )}

                {activeTab === 'legalAI' && (
                    <div className={`flex flex-col ${isFullscreen ? 'h-screen' : 'h-full'}`}>
                        <LegalAI
                            chatHistory={legalChatHistory}
                            isChatLoading={isLegalChatLoading}
                            onSendMessage={handleSendLegalChatMessage}
                            isFullscreen={isFullscreen}
                            onToggleFullscreen={handleToggleFullscreen}
                            showApiKeyWarning={!legalApiKey.trim()}
                        />
                    </div>
                )}
            </main>
            <Modal isOpen={isModalOpen} onClose={() => setIsModalOpen(false)} title="Tambah Transaksi Baru">
                <AddTransactionForm 
                    onAddTransaction={handleAddTransaction}
                    onClose={() => setIsModalOpen(false)}
                />
            </Modal>
        </div>
    );
};

export default App;