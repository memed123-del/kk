import React from 'react';
import { ChartDataItem } from '../types';

interface DonutChartProps {
    data: ChartDataItem[];
}

const DonutChart: React.FC<DonutChartProps> = ({ data }) => {
    const totalValue = data.reduce((acc, item) => acc + item.value, 0);
    const radius = 80;
    const strokeWidth = 25;
    const circumference = 2 * Math.PI * radius;

    let accumulatedPercentage = 0;

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
        }).format(amount);
    };

    return (
        <div className="flex flex-col items-center justify-center gap-6">
            <div className="relative w-52 h-52">
                <svg className="w-full h-full" viewBox="0 0 200 200">
                    <circle
                        cx="100"
                        cy="100"
                        r={radius}
                        fill="transparent"
                        stroke="#334155" // slate-700
                        strokeWidth={strokeWidth}
                    />
                    {data.map((item, index) => {
                        const percentage = (item.value / totalValue) * 100;
                        const strokeDashoffset = circumference - (accumulatedPercentage / 100) * circumference;
                        accumulatedPercentage += percentage;

                        return (
                            <circle
                                key={index}
                                cx="100"
                                cy="100"
                                r={radius}
                                fill="transparent"
                                stroke={item.color}
                                strokeWidth={strokeWidth}
                                strokeDasharray={circumference}
                                strokeDashoffset={strokeDashoffset}
                                transform="rotate(-90 100 100)"
                                className="transition-all duration-500"
                            />
                        );
                    })}
                </svg>
                 <div className="absolute inset-0 flex flex-col items-center justify-center text-center">
                    <span className="text-xs text-gray-400">Total</span>
                    <span className="text-xl font-bold text-white">{formatCurrency(totalValue)}</span>
                </div>
            </div>
            <div className="w-full max-w-xs space-y-2">
                {data.map((item) => (
                    <div key={item.name} className="flex items-center justify-between text-sm">
                        <div className="flex items-center gap-2">
                            <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></span>
                            <span className="text-gray-300">{item.name}</span>
                        </div>
                        <span className="font-semibold text-white">{formatCurrency(item.value)}</span>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default DonutChart;
