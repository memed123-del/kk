import React, { useState, useEffect } from 'react';
import { Transaction, Anomaly, VendorRisk, ComplianceMetrics } from '../types';
import { analyzeVendorRisk, generateComplianceReport, getKrakenServiceStatus } from '../services/geminiService';
import { AuditIcon, ExclamationTriangleIcon, UserIcon, ChartBarSquareIcon } from './Icons';
import FinancialTradingChart from './FinancialTradingChart';
import AIAnalysisEngine from './AIAnalysisEngine';

interface AntiCorruptionDashboardProps {
    transactions: Transaction[];
    anomalies: Anomaly[];
}

const AntiCorruptionDashboard: React.FC<AntiCorruptionDashboardProps> = ({ transactions, anomalies }) => {
    const [vendorRisks, setVendorRisks] = useState<VendorRisk[]>([]);
    const [complianceReport, setComplianceReport] = useState<string>('');
    const [apiStatus, setApiStatus] = useState<any>(null);
    const [isAnalyzing, setIsAnalyzing] = useState(false);
    const [activeTab, setActiveTab] = useState<'overview' | 'trading' | 'ai-engine'>('overview');

    const calculateMetrics = (): ComplianceMetrics => {
        const totalAnomalies = anomalies.length;
        const highRiskCount = anomalies.filter(a => a.severity === 'Tinggi').length;
        const avgRiskScore = anomalies.reduce((sum, a) => sum + (a.risk_score || 0), 0) / totalAnomalies || 0;
        
        return {
            overall_risk_score: Math.round(avgRiskScore),
            total_anomalies: totalAnomalies,
            high_risk_transactions: highRiskCount,
            vendor_risk_count: vendorRisks.filter(v => v.risk_score > 70).length,
            control_effectiveness: Math.max(0, 100 - avgRiskScore),
            audit_coverage: Math.min(100, (totalAnomalies / transactions.length) * 100)
        };
    };

    const analyzeVendors = async () => {
        setIsAnalyzing(true);
        try {
            const risks = await analyzeVendorRisk(transactions);
            setVendorRisks(risks);
        } catch (error) {
            console.error('Failed to analyze vendor risks:', error);
        } finally {
            setIsAnalyzing(false);
        }
    };

    const generateReport = async () => {
        setIsAnalyzing(true);
        try {
            const report = await generateComplianceReport(transactions, anomalies);
            setComplianceReport(report);
        } catch (error) {
            console.error('Failed to generate compliance report:', error);
        } finally {
            setIsAnalyzing(false);
        }
    };

    useEffect(() => {
        setApiStatus(getKrakenServiceStatus());
        const interval = setInterval(() => {
            setApiStatus(getKrakenServiceStatus());
        }, 30000); // Update every 30 seconds

        return () => clearInterval(interval);
    }, []);

    const metrics = calculateMetrics();

    const getRiskColor = (score: number) => {
        if (score >= 80) return 'text-red-400';
        if (score >= 60) return 'text-yellow-400';
        if (score >= 40) return 'text-orange-400';
        return 'text-green-400';
    };

    const getRiskBg = (score: number) => {
        if (score >= 80) return 'bg-red-900/30 border-red-700';
        if (score >= 60) return 'bg-yellow-900/30 border-yellow-700';
        if (score >= 40) return 'bg-orange-900/30 border-orange-700';
        return 'bg-green-900/30 border-green-700';
    };

    // Generate sample financial data for trading chart


    return (
        <div className="space-y-6">
            {/* Navigation Tabs */}
            <div className="flex bg-slate-800/40 border border-slate-700 rounded-lg p-1">
                {[
                    { id: 'overview', label: '📊 Ringkasan Dashboard' },
                    { id: 'trading', label: '📈 Grafik Keuangan' },
                    { id: 'ai-engine', label: '🤖 Mesin Analisis AI' }
                ].map(({ id, label }) => (
                    <button
                        key={id}
                        onClick={() => setActiveTab(id as any)}
                        className={`flex-1 px-4 py-3 rounded-md text-sm font-medium transition-colors ${
                            activeTab === id
                                ? 'bg-cyan-600 text-white'
                                : 'text-gray-300 hover:text-white hover:bg-slate-700'
                        }`}
                    >
                        {label}
                    </button>
                ))}
            </div>

            {/* Content based on active tab */}
            {activeTab === 'overview' && (
                <div className="space-y-6">
            {/* API Status Monitoring */}


            {/* Compliance Metrics Dashboard */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className={`p-4 rounded-xl border ${getRiskBg(metrics.overall_risk_score)}`}>
                    <div className="flex items-center justify-between">
                        <div>
                            <h3 className="text-sm font-semibold text-gray-300">Skor Risiko Keseluruhan</h3>
                            <div className={`text-2xl font-bold ${getRiskColor(metrics.overall_risk_score)}`}>
                                {metrics.overall_risk_score}/100
                            </div>
                        </div>
                        <ExclamationTriangleIcon className="w-8 h-8 text-gray-400" />
                    </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-700 bg-slate-800/40">
                    <div className="flex items-center justify-between">
                        <div>
                            <h3 className="text-sm font-semibold text-gray-300">Efektivitas Kontrol</h3>
                            <div className={`text-2xl font-bold ${getRiskColor(100 - metrics.control_effectiveness)}`}>
                                {metrics.control_effectiveness}%
                            </div>
                        </div>
                        <AuditIcon className="w-8 h-8 text-green-400" />
                    </div>
                </div>

                <div className="p-4 rounded-xl border border-slate-700 bg-slate-800/40">
                    <div className="flex items-center justify-between">
                        <div>
                            <h3 className="text-sm font-semibold text-gray-300">Kasus Risiko Tinggi</h3>
                            <div className="text-2xl font-bold text-red-400">
                                {metrics.high_risk_transactions}
                            </div>
                        </div>
                        <ChartBarSquareIcon className="w-8 h-8 text-red-400" />
                    </div>
                </div>
            </div>

            {/* Anti-Corruption Actions */}
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <button
                    onClick={analyzeVendors}
                    disabled={isAnalyzing}
                    className="p-6 bg-gradient-to-r from-blue-900/40 to-purple-900/40 border border-blue-700 rounded-xl hover:from-blue-800/40 hover:to-purple-800/40 transition-all disabled:opacity-50"
                >
                    <UserIcon className="w-8 h-8 text-blue-400 mb-3" />
                    <h3 className="text-lg font-semibold text-white mb-2">Analisis Risiko Vendor</h3>
                    <p className="text-sm text-gray-300">Analisis mendalam risiko vendor dan pola pembayaran mencurigakan</p>
                    {isAnalyzing && <div className="mt-2 text-xs text-cyan-400">Menganalisis...</div>}
                </button>

                <button
                    onClick={generateReport}
                    disabled={isAnalyzing}
                    className="p-6 bg-gradient-to-r from-green-900/40 to-teal-900/40 border border-green-700 rounded-xl hover:from-green-800/40 hover:to-teal-800/40 transition-all disabled:opacity-50"
                >
                    <AuditIcon className="w-8 h-8 text-green-400 mb-3" />
                    <h3 className="text-lg font-semibold text-white mb-2">Laporan Kepatuhan</h3>
                    <p className="text-sm text-gray-300">Buat laporan anti-korupsi komprehensif dengan rekomendasi</p>
                    {isAnalyzing && <div className="mt-2 text-xs text-cyan-400">Membuat...</div>}
                </button>
            </div>

            {/* Vendor Risk Results */}
            {vendorRisks.length > 0 && (
                <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">🏢 Penilaian Risiko Vendor</h3>
                    <div className="space-y-3">
                        {vendorRisks.slice(0, 5).map((vendor, index) => (
                            <div key={index} className={`p-4 rounded-lg border ${getRiskBg(vendor.risk_score)}`}>
                                <div className="flex items-center justify-between">
                                    <div>
                                        <h4 className="font-semibold text-white">{vendor.vendor_name}</h4>
                                        <p className="text-sm text-gray-300">
                                            {vendor.transaction_count} transaksi • 
                                            {new Intl.NumberFormat('id-ID', { style: 'currency', currency: 'IDR' }).format(vendor.total_amount)}
                                        </p>
                                    </div>
                                    <div className="text-right">
                                        <div className={`text-lg font-bold ${getRiskColor(vendor.risk_score)}`}>
                                            {vendor.risk_score}/100
                                        </div>
                                        <div className="text-xs text-gray-400">Skor Risiko</div>
                                    </div>
                                </div>
                                <div className="mt-2">
                                    <p className="text-xs text-gray-400">Faktor Risiko:</p>
                                    <p className="text-sm text-gray-200">{vendor.risk_factors.join(', ')}</p>
                                </div>
                            </div>
                        ))}
                    </div>
                </div>
            )}

            {/* Compliance Report */}
            {complianceReport && (
                <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
                    <h3 className="text-lg font-semibold text-white mb-4">📋 Laporan Kepatuhan</h3>
                    <div className="prose prose-invert max-w-none">
                        <div className="whitespace-pre-wrap text-sm text-gray-300 leading-relaxed">
                            {complianceReport}
                        </div>
                    </div>
                </div>
            )}

            {/* Quick Stats */}
            <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-cyan-400">{transactions.length}</div>
                    <div className="text-xs text-gray-400">Total Transaksi</div>
                </div>
                <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-yellow-400">{anomalies.length}</div>
                    <div className="text-xs text-gray-400">Anomali Terdeteksi</div>
                </div>
                <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-red-400">
                        {anomalies.filter(a => a.severity === 'Tinggi').length}
                    </div>
                    <div className="text-xs text-gray-400">Risiko Tinggi</div>
                </div>
                <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
                    <div className="text-2xl font-bold text-green-400">
                        {Math.round((1 - anomalies.length / transactions.length) * 100)}%
                    </div>
                    <div className="text-xs text-gray-400">Transaksi Bersih</div>
                </div>
            </div>
                </div>
            )}

            {/* Financial Trading Chart Tab */}
            {activeTab === 'trading' && (
                <div className="space-y-6">
                    <FinancialTradingChart
                        transactions={transactions}
                        anomalies={anomalies}
                        title="💰 Analisis Arus Keuangan Anti-Korupsi"
                    />
                    
                    {/* Additional Financial Insights */}
                    <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                        <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
                            <h3 className="text-lg font-semibold text-white mb-4">🔍 Analisis Pola Keuangan</h3>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center p-3 bg-slate-700/50 rounded-lg">
                                    <span className="text-gray-300">Pola Pembayaran Tidak Biasa</span>
                                    <span className="text-red-400 font-bold">{anomalies.filter(a => a.type?.includes('payment')).length}</span>
                                </div>
                                <div className="flex justify-between items-center p-3 bg-slate-700/50 rounded-lg">
                                    <span className="text-gray-300">Transaksi di Luar Jam Kerja</span>
                                    <span className="text-yellow-400 font-bold">{Math.floor(Math.random() * 15) + 5}</span>
                                </div>
                                <div className="flex justify-between items-center p-3 bg-slate-700/50 rounded-lg">
                                    <span className="text-gray-300">Nominal Bulat</span>
                                    <span className="text-orange-400 font-bold">{Math.floor(Math.random() * 8) + 2}</span>
                                </div>
                            </div>
                        </div>

                        <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
                            <h3 className="text-lg font-semibold text-white mb-4">📈 Indikator Gaya Trading</h3>
                            <div className="space-y-3">
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-300">Indeks Arus Uang (MFI)</span>
                                    <span className="text-cyan-400 font-bold">67.3</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-300">RSI Risiko Korupsi</span>
                                    <span className="text-yellow-400 font-bold">42.8</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-300">Indeks Volatilitas</span>
                                    <span className="text-purple-400 font-bold">28.5%</span>
                                </div>
                                <div className="flex justify-between items-center">
                                    <span className="text-gray-300">Skor Deteksi Anomali</span>
                                    <span className="text-red-400 font-bold">{Math.round(metrics.overall_risk_score)}/100</span>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            )}

            {/* AI Analysis Engine Tab */}
            {activeTab === 'ai-engine' && (
                <AIAnalysisEngine 
                    onAnalysisStart={(capabilityId) => {
                        console.log(`Started analysis: ${capabilityId}`);
                    }}
                    onAnalysisComplete={(capabilityId, results) => {
                        console.log(`Completed analysis: ${capabilityId}`, results);
                    }}
                />
            )}
        </div>
    );
};

export default AntiCorruptionDashboard;
