import React, { useState, useEffect, useRef } from 'react';
import { ChatMessage } from '../types';
import { UserIcon, PaperAirplaneIcon, PaperClipIcon, XMarkIcon, ArrowsPointingOutIcon, ArrowsPointingInIcon } from './Icons';
import KrakenLogo from './KrakenLogo';

interface ChatInterfaceProps {
    chatHistory: ChatMessage[];
    isChatLoading: boolean;
    onSendMessage: (message: string, fileContent?: string) => void;
    isFullscreen?: boolean;
    onToggleFullscreen?: () => void;
    showApiKeyWarning?: boolean;
}

const MarkdownContent: React.FC<{ text: string }> = ({ text }) => {
    const elements = text.split('\n\n').map((paragraph, pIndex) => {
        if (paragraph.startsWith('* ') || paragraph.startsWith('- ')) {
            const listItems = paragraph.split('\n').map((item, lIndex) => {
                const content = item.substring(2).replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>');
                return <li key={lIndex} dangerouslySetInnerHTML={{ __html: content }} />;
            });
            return <ul key={pIndex} className="list-disc list-inside space-y-1 my-2">{listItems}</ul>;
        }
        const content = paragraph.replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>').replace(/\n/g, '<br/>');
        return <p key={pIndex} dangerouslySetInnerHTML={{ __html: content }} className="mb-2" />;
    });

    return <div className="leading-relaxed">{elements}</div>;
};


const ChatInterface: React.FC<ChatInterfaceProps> = ({ 
    chatHistory, 
    isChatLoading, 
    onSendMessage, 
    isFullscreen = false, 
    onToggleFullscreen,
    showApiKeyWarning = false
}) => {
    const [chatInput, setChatInput] = useState('');
    const [attachedFile, setAttachedFile] = useState<File | null>(null);
    const chatContainerRef = useRef<HTMLDivElement>(null);
    const fileInputRef = useRef<HTMLInputElement>(null);

    useEffect(() => {
        if (chatContainerRef.current) {
            chatContainerRef.current.scrollTop = chatContainerRef.current.scrollHeight;
        }
    }, [chatHistory, isChatLoading]);

    const handleFileChange = (event: React.ChangeEvent<HTMLInputElement>) => {
        const file = event.target.files?.[0];
        if (file) {
            setAttachedFile(file);
        }
    };

    const renderAttachedFile = () => {
        if (!attachedFile) return null;
        
        if (attachedFile.type.startsWith('image/')) {
            const imageUrl = URL.createObjectURL(attachedFile);
            return (
                <div className="mb-3 p-2 bg-slate-700/50 border border-slate-600 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                        <span className="text-cyan-300 text-sm font-medium">📷 {attachedFile.name}</span>
                        <button onClick={() => setAttachedFile(null)} className="text-slate-400 hover:text-white">
                            <XMarkIcon className="w-4 h-4" />
                        </button>
                    </div>
                    <img 
                        src={imageUrl} 
                        alt={attachedFile.name}
                        className="max-w-full max-h-32 rounded border border-slate-600 object-contain"
                        onLoad={() => URL.revokeObjectURL(imageUrl)}
                    />
                </div>
            );
        }
        
        return (
            <div className="mb-3 flex items-center justify-between bg-slate-700/50 px-3 py-2 rounded-lg text-sm">
                <div className="flex items-center gap-2 text-cyan-300">
                    <PaperClipIcon className="w-4 h-4" />
                    <span className="font-medium truncate">{attachedFile.name}</span>
                </div>
                <button onClick={() => setAttachedFile(null)} className="text-slate-400 hover:text-white">
                    <XMarkIcon className="w-5 h-5" />
                </button>
            </div>
        );
    };

    const handleFormSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        if (attachedFile) {
            if (attachedFile.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = (readEvent) => {
                    const base64Content = readEvent.target?.result as string;
                    onSendMessage(
                        chatInput || `Analisis gambar terlampir: ${attachedFile.name}`, 
                        base64Content
                    );
                    setAttachedFile(null);
                    setChatInput('');
                };
                reader.readAsDataURL(attachedFile);
            } else {
                const reader = new FileReader();
                reader.onload = (readEvent) => {
                    const fileContent = readEvent.target?.result as string;
                    onSendMessage(
                        chatInput || `Analisis file terlampir: ${attachedFile.name}`, 
                        fileContent
                    );
                    setAttachedFile(null);
                    setChatInput('');
                };
                reader.readAsText(attachedFile);
            }
        } else {
            onSendMessage(chatInput);
            setChatInput('');
        }
    };
    
    if (chatHistory.length <= 1) {
        return (
            <div className="flex-grow flex flex-col items-center justify-center text-center p-8 w-full max-w-4xl mx-auto">
                {onToggleFullscreen && (
                    <button
                        onClick={onToggleFullscreen}
                        className="absolute top-4 right-4 p-2 bg-slate-700/50 hover:bg-slate-600/50 rounded-lg text-slate-300 hover:text-white transition-colors"
                        title={isFullscreen ? "Keluar dari fullscreen" : "Masuk fullscreen"}
                    >
                        {isFullscreen ? <ArrowsPointingInIcon className="w-5 h-5" /> : <ArrowsPointingOutIcon className="w-5 h-5" />}
                    </button>
                )}
                
                <div className="w-full">
                     <KrakenLogo size={56} className="text-cyan-400 mb-4 mx-auto" />
                     <h2 className="text-2xl font-bold text-white mb-2">Kraken AI - Keuangan</h2>
                     <p className="text-slate-400 text-sm mb-6 max-w-lg mx-auto">
                         Asisten AI untuk analisis keuangan, deteksi anomali, dan optimasi budget
                     </p>
                     <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 max-w-2xl mx-auto">
                         <button onClick={() => onSendMessage("Analisis tren pengeluaran bulan ini")} className="p-3 bg-slate-700/40 hover:bg-slate-600/50 rounded-xl text-left text-sm text-slate-200 transition-all border border-slate-600/30 hover:border-slate-500">
                            <p className="font-medium text-white">📊 Analisis Tren</p>
                            <p className="text-slate-400 text-xs mt-1">Ringkasan pengeluaran</p>
                         </button>
                          <button onClick={() => onSendMessage("Adakah anomali yang perlu saya waspadai?")} className="p-3 bg-slate-700/40 hover:bg-slate-600/50 rounded-xl text-left text-sm text-slate-200 transition-all border border-slate-600/30 hover:border-slate-500">
                            <p className="font-medium text-white">🔍 Deteksi Anomali</p>
                            <p className="text-slate-400 text-xs mt-1">Temukan pola mencurigakan</p>
                         </button>
                          <button onClick={() => onSendMessage("Bagaimana cara efisiensi pengeluaran?")} className="p-3 bg-slate-700/40 hover:bg-slate-600/50 rounded-xl text-left text-sm text-slate-200 transition-all border border-slate-600/30 hover:border-slate-500">
                            <p className="font-medium text-white">💡 Saran Efisiensi</p>
                            <p className="text-slate-400 text-xs mt-1">Strategi penghematan</p>
                         </button>
                          <button onClick={() => onSendMessage("Bandingkan data 3 bulan terakhir")} className="p-3 bg-slate-700/40 hover:bg-slate-600/50 rounded-xl text-left text-sm text-slate-200 transition-all border border-slate-600/30 hover:border-slate-500">
                            <p className="font-medium text-white">📈 Perbandingan Data</p>
                            <p className="text-slate-400 text-xs mt-1">Analisis historis</p>
                         </button>
                     </div>
                </div>
            </div>
        )
    }

    return (
        <div className={`flex flex-col h-full ${isFullscreen ? 'fixed inset-0 z-50 bg-slate-900' : 'relative'}`}>
            {onToggleFullscreen && (
                <button
                    onClick={onToggleFullscreen}
                    className="absolute top-4 right-4 z-10 p-2 bg-slate-700/50 hover:bg-slate-600/50 rounded-lg text-slate-300 hover:text-white transition-colors"
                    title={isFullscreen ? "Keluar dari fullscreen" : "Masuk fullscreen"}
                >
                    {isFullscreen ? <ArrowsPointingInIcon className="w-5 h-5" /> : <ArrowsPointingOutIcon className="w-5 h-5" />}
                </button>
            )}
            
            <div ref={chatContainerRef} className="flex-1 overflow-y-auto px-4 py-6 space-y-6 pb-40">
                <div className="max-w-3xl mx-auto space-y-6">
                    {chatHistory.map((msg, index) => (
                         msg.role === 'model' && index === 0 ? null :
                        <div key={index} className={`flex gap-3 ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}>
                            {msg.role === 'model' && (
                                <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                                    <KrakenLogo size={20} className="text-white" />
                                </div>
                            )}
                            <div className={`max-w-[85%] rounded-2xl px-4 py-3 ${msg.role === 'user' ? 'bg-cyan-600 text-white' : 'bg-slate-800 text-gray-100'}`}>
                                {msg.role === 'model' ? (
                                    <MarkdownContent text={msg.parts} />
                                ) : (
                                    <div className="text-sm leading-relaxed whitespace-pre-wrap">
                                        {msg.imageData && (
                                            <div className="mb-2">
                                                <img 
                                                    src={msg.imageData} 
                                                    alt={msg.fileName || 'Uploaded'}
                                                    className="max-w-full max-h-40 rounded border border-slate-600/30 object-contain"
                                                />
                                                {msg.fileName && <p className="text-xs text-slate-300 mt-1 opacity-75">{msg.fileName}</p>}
                                            </div>
                                        )}
                                        <p>{msg.parts}</p>
                                    </div>
                                )}
                            </div>
                            {msg.role === 'user' && (
                                <div className="w-8 h-8 rounded-full bg-slate-600 flex items-center justify-center flex-shrink-0">
                                    <UserIcon className="w-5 h-5 text-gray-300" />
                                </div>
                            )}
                        </div>
                    ))}
                    {isChatLoading && (
                        <div className="flex gap-3 justify-start">
                            <div className="w-8 h-8 rounded-full bg-gradient-to-br from-cyan-500 to-blue-600 flex items-center justify-center flex-shrink-0">
                                <KrakenLogo size={20} className="text-white" />
                            </div>
                            <div className="bg-slate-800 rounded-2xl px-4 py-3">
                                <div className="flex gap-1">
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '0ms'}}></div>
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '150ms'}}></div>
                                    <div className="w-2 h-2 bg-cyan-400 rounded-full animate-bounce" style={{animationDelay: '300ms'}}></div>
                                </div>
                            </div>
                        </div>
                    )}
                </div>
            </div>
            
            <div className="fixed bottom-0 left-0 right-0 bg-slate-900/95 border-t border-slate-700 backdrop-blur-sm p-4">
                <div className="max-w-3xl mx-auto">
                    {renderAttachedFile()}
                    <form onSubmit={handleFormSubmit} className="relative">
                        <input
                            type="file"
                            ref={fileInputRef}
                            onChange={handleFileChange}
                            className="sr-only"
                        />
                         <button 
                            type="button" 
                            onClick={() => fileInputRef.current?.click()}
                            className="absolute left-3 top-1/2 -translate-y-1/2 text-slate-400 hover:text-cyan-400 transition-colors"
                        >
                            <PaperClipIcon className="w-5 h-5" />
                        </button>
                        <input
                            type="text"
                            value={chatInput}
                            onChange={(e) => setChatInput(e.target.value)}
                            placeholder={attachedFile ? `Jelaskan tentang file...` : `Tanyakan pada Kraken AI...`}
                            className="w-full pl-12 pr-12 py-3 bg-slate-800 border border-slate-700 rounded-xl text-white placeholder-slate-500 focus:ring-2 focus:ring-cyan-500 focus:border-transparent transition-all"
                            disabled={isChatLoading}
                            onKeyDown={(e) => {
                              if (e.key === 'Enter' && !e.shiftKey) {
                                handleFormSubmit(e);
                              }
                            }}
                        />
                        <button 
                            type="submit" 
                            disabled={isChatLoading || (!chatInput.trim() && !attachedFile)} 
                            className="absolute right-3 top-1/2 -translate-y-1/2 text-cyan-400 hover:text-cyan-300 disabled:text-gray-600 disabled:cursor-not-allowed transition-colors"
                        >
                            <PaperAirplaneIcon className="w-5 h-5" />
                        </button>
                    </form>
                </div>
            </div>
        </div>
    );
};

export default ChatInterface;
