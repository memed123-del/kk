import React from 'react';

interface KrakenLogoProps {
  size?: number;
  className?: string;
}

const KrakenLogo: React.FC<KrakenLogoProps> = ({ size = 40, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Octopus head */}
      <circle cx="50" cy="40" r="22" fill="currentColor" fillOpacity="0.9" />
      
      {/* Eyes */}
      <circle cx="43" cy="38" r="4" fill="white" />
      <circle cx="57" cy="38" r="4" fill="white" />
      <circle cx="44" cy="38" r="2" fill="#0f172a" />
      <circle cx="58" cy="38" r="2" fill="#0f172a" />
      
      {/* Tentacle 1 - Top Left */}
      <path
        d="M 35 50 Q 20 55 18 70 Q 17 75 22 73 Q 27 71 28 65"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 2 - Left */}
      <path
        d="M 32 52 Q 15 60 10 75 Q 8 82 14 80 Q 19 78 22 72"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 3 - Bottom Left */}
      <path
        d="M 38 55 Q 25 70 25 85 Q 25 92 30 88 Q 35 84 36 78"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 4 - Bottom Center Left */}
      <path
        d="M 45 58 Q 40 75 42 90 Q 43 96 47 92 Q 51 88 50 82"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 5 - Bottom Center Right */}
      <path
        d="M 55 58 Q 60 75 58 90 Q 57 96 53 92 Q 49 88 50 82"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 6 - Bottom Right */}
      <path
        d="M 62 55 Q 75 70 75 85 Q 75 92 70 88 Q 65 84 64 78"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 7 - Right */}
      <path
        d="M 68 52 Q 85 60 90 75 Q 92 82 86 80 Q 81 78 78 72"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Tentacle 8 - Top Right */}
      <path
        d="M 65 50 Q 80 55 82 70 Q 83 75 78 73 Q 73 71 72 65"
        stroke="currentColor"
        strokeWidth="3.5"
        fill="none"
        strokeLinecap="round"
        opacity="0.85"
      />
      
      {/* Smile */}
      <path
        d="M 42 45 Q 50 48 58 45"
        stroke="white"
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
      />
    </svg>
  );
};

export default KrakenLogo;
