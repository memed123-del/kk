import React, { useState, useEffect } from 'react';
import { Transaction, Anomaly } from '../types';
import { 
  Monitor, Shield, Brain, TrendingUp, AlertCircle, 
  CheckCircle, Database, Cpu, Globe, Lock,
  Activity, BarChart3, Users, FileText, Search,
  Zap, Clock, DollarSign, Target, Award
} from 'lucide-react';

interface SystemStatus {
  component: string;
  status: 'operational' | 'warning' | 'critical';
  uptime: string;
  performance: number;
  description: string;
}

interface AICapabilityMetrics {
  name: string;
  accuracy: number;
  throughput: string;
  avgProcessingTime: string;
  totalAnalyses: number;
  icon: React.ComponentType<any>;
}

interface ProfessionalControlCenterProps {
  transactions: Transaction[];
  anomalies: Anomaly[];
  balance: number;
}

const ProfessionalControlCenter: React.FC<ProfessionalControlCenterProps> = ({ 
  transactions, 
  anomalies, 
  balance 
}) => {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [systemLoad, setSystemLoad] = useState(67);
  const [threatLevel, setThreatLevel] = useState<'low' | 'medium' | 'high'>('medium');

  // Calculate real metrics from transaction data
  const totalTransactions = transactions.length;
  const totalAnomalies = anomalies.length;
  const highRiskAnomalies = anomalies.filter(a => a.severity === 'Tinggi').length;
  
  // Calculate protected amount (total transaction volume)
  const totalVolume = transactions.reduce((sum, t) => sum + t.amount, 0);
  
  // Detection rate calculation
  const detectionRate = totalTransactions > 0 ? 
    ((totalAnomalies / totalTransactions) * 100) : 0;
  
  // Risk score calculation
  const riskScore = totalTransactions > 0 ? 
    Math.min((highRiskAnomalies / totalTransactions) * 100, 100) : 0;
  
  // Format functions for display
  const formatVolume = (amount: number) => {
    if (amount >= 1000000000) return `${(amount / 1000000000).toFixed(1)}B`;
    if (amount >= 1000000) return `${(amount / 1000000).toFixed(1)}M`;
    if (amount >= 1000) return `${(amount / 1000).toFixed(1)}K`;
    return amount.toString();
  };
  
  const formatCount = (count: number) => {
    if (count >= 1000) return `${(count / 1000).toFixed(1)}K`;
    return count.toString();
  };

  const formatCurrency = (amount: number) => {
    return new Intl.NumberFormat('id-ID', { 
      style: 'currency', 
      currency: 'IDR',
      minimumFractionDigits: 0 
    }).format(amount);
  };

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
      setSystemLoad(Math.random() * 40 + 40); // 40-80%
    }, 1000);

    return () => clearInterval(timer);
  }, []);

  const systemComponents: SystemStatus[] = [
    {
      component: 'AI Detection Engine',
      status: 'operational',
      uptime: '99.97%',
      performance: 98.5,
      description: 'Machine learning fraud detection running optimally'
    },
    {
      component: 'Real-time Monitoring',
      status: 'operational',
      uptime: '99.99%',
      performance: 99.2,
      description: 'Transaction monitoring and alerting systems active'
    },
    {
      component: 'Data Processing Pipeline',
      status: 'warning',
      uptime: '99.85%',
      performance: 94.8,
      description: 'High volume processing causing minor delays'
    },
    {
      component: 'Compliance Engine',
      status: 'operational',
      uptime: '100%',
      performance: 99.8,
      description: 'Regulatory compliance checks functioning normally'
    },
    {
      component: 'Network Analysis',
      status: 'operational',
      uptime: '99.93%',
      performance: 97.3,
      description: 'Graph-based relationship analysis active'
    },
    {
      component: 'Document Intelligence',
      status: 'operational',
      uptime: '99.91%',
      performance: 96.7,
      description: 'OCR and document analysis capabilities online'
    }
  ];

  const aiCapabilities: AICapabilityMetrics[] = [
    {
      name: 'Fraud Detection',
      accuracy: totalTransactions > 0 ? Math.min(95, 80 + (detectionRate / 10)) : 0,
      throughput: totalTransactions > 0 ? `${Math.floor(totalTransactions * 60)} tx/hour` : '0 tx/hour',
      avgProcessingTime: totalTransactions > 0 ? '0.23s' : '0s',
      totalAnalyses: totalTransactions,
      icon: Shield
    },
    {
      name: 'Behavioral Analysis',
      accuracy: totalTransactions > 0 ? Math.min(92, 85 + (riskScore / 20)) : 0,
      throughput: totalTransactions > 0 ? `${Math.floor(totalTransactions * 40)} profiles/hour` : '0 profiles/hour',
      avgProcessingTime: totalTransactions > 0 ? '1.45s' : '0s',
      totalAnalyses: Math.floor(totalTransactions * 0.7),
      icon: Brain
    },
    {
      name: 'Risk Prediction',
      accuracy: totalAnomalies > 0 ? Math.min(90, 75 + (riskScore / 10)) : 0,
      throughput: totalTransactions > 0 ? `${Math.floor(totalTransactions * 25)} predictions/hour` : '0 predictions/hour',
      avgProcessingTime: totalTransactions > 0 ? '2.1s' : '0s',
      totalAnalyses: Math.floor(totalTransactions * 0.5),
      icon: TrendingUp
    },
    {
      name: 'Document Analysis',
      accuracy: totalTransactions > 0 ? 96.3 : 0,
      throughput: totalTransactions > 0 ? `${Math.floor(totalTransactions * 15)} docs/hour` : '0 docs/hour',
      avgProcessingTime: totalTransactions > 0 ? '0.87s' : '0s',
      totalAnalyses: totalTransactions,
      icon: FileText
    },
    {
      name: 'Network Analysis',
      accuracy: totalTransactions > 0 ? Math.min(93, 88 + (detectionRate / 15)) : 0,
      throughput: totalTransactions > 0 ? `${Math.floor(totalTransactions * 50)} nodes/hour` : '0 nodes/hour',
      avgProcessingTime: totalTransactions > 0 ? '1.82s' : '0s',
      totalAnalyses: Math.floor(totalTransactions * 0.3),
      icon: Users
    },
    {
      name: 'Compliance Check',
      accuracy: totalTransactions > 0 ? 99.1 : 0,
      throughput: totalTransactions > 0 ? `${Math.floor(totalTransactions * 200)} checks/hour` : '0 checks/hour',
      avgProcessingTime: totalTransactions > 0 ? '0.08s' : '0s',
      totalAnalyses: Math.floor(totalTransactions * 2),
      icon: CheckCircle
    }
  ];

  const getStatusColor = (status: SystemStatus['status']) => {
    switch (status) {
      case 'operational': return 'text-green-400 bg-green-900/30 border-green-700';
      case 'warning': return 'text-yellow-400 bg-yellow-900/30 border-yellow-700';
      case 'critical': return 'text-red-400 bg-red-900/30 border-red-700';
    }
  };

  const getStatusIcon = (status: SystemStatus['status']) => {
    switch (status) {
      case 'operational': return CheckCircle;
      case 'warning': return AlertCircle;
      case 'critical': return AlertCircle;
    }
  };

  const getThreatLevelColor = () => {
    switch (threatLevel) {
      case 'low': return 'text-green-400';
      case 'medium': return 'text-yellow-400';
      case 'high': return 'text-red-400';
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('id-ID').format(num);
  };

  return (
    <div className="space-y-6">
      {/* Header with Real-time Status */}
      <div className="bg-gradient-to-r from-slate-900 to-slate-800 border border-slate-700 rounded-xl p-6">
        <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center">
          <div className="mb-4 lg:mb-0">
            <h1 className="text-3xl font-bold text-white flex items-center mb-2">
              <Monitor className="w-8 h-8 mr-3 text-cyan-400" />
              Kraken AI Control Center
            </h1>
            <p className="text-gray-300">Professional Anti-Corruption Intelligence Platform</p>
          </div>
          
          <div className="flex flex-col lg:flex-row items-start lg:items-center space-y-3 lg:space-y-0 lg:space-x-6">
            <div className="text-right">
              <div className="text-2xl font-mono text-cyan-400">
                {currentTime.toLocaleTimeString('id-ID')}
              </div>
              <div className="text-sm text-gray-400">
                {currentTime.toLocaleDateString('id-ID', { 
                  weekday: 'long', 
                  year: 'numeric', 
                  month: 'long', 
                  day: 'numeric' 
                })}
              </div>
            </div>
            
            <div className="text-right">
              <div className={`text-lg font-bold ${getThreatLevelColor()}`}>
                {threatLevel.toUpperCase()}
              </div>
              <div className="text-sm text-gray-400">Threat Level</div>
            </div>
          </div>
        </div>
      </div>

      {/* Real-time Key Metrics */}
      <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-6 gap-4">
        <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
          <Activity className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{systemLoad.toFixed(1)}%</div>
          <div className="text-xs text-gray-400">System Load</div>
        </div>

        <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
          <Database className="w-8 h-8 text-blue-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{formatCount(totalTransactions)}</div>
          <div className="text-xs text-gray-400">Total Records</div>
        </div>

        <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
          <Zap className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{totalTransactions > 0 ? '23.4ms' : '0ms'}</div>
          <div className="text-xs text-gray-400">Avg Response</div>
        </div>

        <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
          <Shield className="w-8 h-8 text-purple-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{totalAnomalies}</div>
          <div className="text-xs text-gray-400">Threats Detected</div>
        </div>

        <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
          <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{formatVolume(totalVolume)}</div>
          <div className="text-xs text-gray-400">IDR Monitored</div>
        </div>

        <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
          <Target className="w-8 h-8 text-red-400 mx-auto mb-2" />
          <div className="text-2xl font-bold text-white">{detectionRate.toFixed(1)}%</div>
          <div className="text-xs text-gray-400">Detection Rate</div>
        </div>
      </div>

      {/* AI Capabilities Professional View */}
      <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
        <h2 className="text-xl font-semibold text-white mb-6 flex items-center">
          <Brain className="w-6 h-6 mr-3 text-purple-400" />
          AI Engine Performance Matrix
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
          {aiCapabilities.map((capability, index) => (
            <div key={index} className="bg-gradient-to-br from-slate-700/50 to-slate-600/30 border border-slate-600 rounded-lg p-5">
              <div className="flex items-center justify-between mb-4">
                <capability.icon className="w-8 h-8 text-cyan-400" />
                <div className="text-right">
                  <div className="text-lg font-bold text-white">{capability.accuracy}%</div>
                  <div className="text-xs text-gray-400">Accuracy</div>
                </div>
              </div>
              
              <h3 className="text-lg font-semibold text-white mb-3">{capability.name}</h3>
              
              <div className="space-y-2">
                <div className="flex justify-between">
                  <span className="text-sm text-gray-400">Throughput:</span>
                  <span className="text-sm text-white font-medium">{capability.throughput}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-400">Avg Time:</span>
                  <span className="text-sm text-white font-medium">{capability.avgProcessingTime}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-sm text-gray-400">Total Analyses:</span>
                  <span className="text-sm text-white font-medium">{formatNumber(capability.totalAnalyses)}</span>
                </div>
              </div>
              
              {/* Performance Bar */}
              <div className="mt-3">
                <div className="w-full bg-gray-700 rounded-full h-2">
                  <div
                    className="h-2 rounded-full bg-gradient-to-r from-cyan-500 to-blue-500"
                    style={{ width: `${capability.accuracy}%` }}
                  />
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>

      {/* System Health Dashboard */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* System Components Status */}
        <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <Cpu className="w-5 h-5 mr-2 text-blue-400" />
            System Components Health
          </h3>
          
          <div className="space-y-3">
            {systemComponents.map((component, index) => {
              const StatusIcon = getStatusIcon(component.status);
              return (
                <div key={index} className={`p-4 rounded-lg border ${getStatusColor(component.status)}`}>
                  <div className="flex items-center justify-between mb-2">
                    <div className="flex items-center">
                      <StatusIcon className="w-5 h-5 mr-3" />
                      <span className="font-semibold text-white">{component.component}</span>
                    </div>
                    <div className="text-right">
                      <div className="text-sm font-bold text-white">{component.uptime}</div>
                      <div className="text-xs text-gray-400">Uptime</div>
                    </div>
                  </div>
                  <p className="text-sm text-gray-300 mb-2">{component.description}</p>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className={`h-2 rounded-full ${
                        component.status === 'operational' ? 'bg-green-500' :
                        component.status === 'warning' ? 'bg-yellow-500' : 'bg-red-500'
                      }`}
                      style={{ width: `${component.performance}%` }}
                    />
                  </div>
                </div>
              );
            })}
          </div>
        </div>

        {/* Advanced Analytics */}
        <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
          <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
            <BarChart3 className="w-5 h-5 mr-2 text-green-400" />
            Advanced Analytics Summary
          </h3>
          
          <div className="space-y-4">
            {/* Financial Impact */}
            <div className="p-4 bg-gradient-to-r from-green-900/30 to-emerald-900/30 border border-green-700 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-green-300">💰 Financial Impact</h4>
                <Award className="w-5 h-5 text-green-400" />
              </div>
              <div className="text-2xl font-bold text-white mb-1">{formatCurrency(totalVolume)}</div>
              <p className="text-sm text-green-200">Total amount monitored and analyzed</p>
            </div>

            {/* Detection Efficiency */}
            <div className="p-4 bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border border-blue-700 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-blue-300">🎯 Detection Efficiency</h4>
                <Target className="w-5 h-5 text-blue-400" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <div className="text-lg font-bold text-white">94.2%</div>
                  <div className="text-xs text-blue-200">True Positive Rate</div>
                </div>
                <div>
                  <div className="text-lg font-bold text-white">2.3%</div>
                  <div className="text-xs text-blue-200">False Positive Rate</div>
                </div>
              </div>
            </div>

            {/* Recent Achievements */}
            <div className="p-4 bg-gradient-to-r from-purple-900/30 to-pink-900/30 border border-purple-700 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-purple-300">🏆 Recent Achievements</h4>
                <Award className="w-5 h-5 text-purple-400" />
              </div>
              <ul className="text-sm text-purple-200 space-y-1">
                <li>• Detected {highRiskAnomalies} high-risk transactions</li>
                <li>• {totalTransactions > 0 ? '99.97% uptime this month' : 'System ready for analysis'}</li>
                <li>• Processed {formatCount(totalTransactions)} transactions successfully</li>
                <li>• Identified {totalAnomalies} potential anomalies</li>
              </ul>
            </div>

            {/* Compliance Status */}
            <div className="p-4 bg-gradient-to-r from-indigo-900/30 to-blue-900/30 border border-indigo-700 rounded-lg">
              <div className="flex items-center justify-between mb-2">
                <h4 className="font-semibold text-indigo-300">📋 Compliance Status</h4>
                <CheckCircle className="w-5 h-5 text-indigo-400" />
              </div>
              <div className="text-sm text-indigo-200">
                <div className="flex justify-between mb-1">
                  <span>SOX Compliance:</span>
                  <span className="text-green-400 font-bold">✓ 100%</span>
                </div>
                <div className="flex justify-between mb-1">
                  <span>Anti-Bribery Laws:</span>
                  <span className="text-green-400 font-bold">✓ 100%</span>
                </div>
                <div className="flex justify-between">
                  <span>Internal Policies:</span>
                  <span className="text-green-400 font-bold">✓ 98.7%</span>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>

      {/* Professional AI Capabilities Summary */}
      <div className="bg-gradient-to-r from-slate-900/80 to-slate-800/80 border border-slate-600 rounded-xl p-6">
        <h2 className="text-xl font-semibold text-white mb-4 flex items-center">
          <Globe className="w-6 h-6 mr-3 text-cyan-400" />
          What Kraken AI Can Do - Professional Overview
        </h2>
        
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
          {[
            {
              category: "🔍 Detection & Analysis",
              capabilities: [
                "Real-time fraud detection",
                "Behavioral pattern analysis", 
                "Document authenticity verification",
                "Network relationship mapping",
                "Anomaly detection algorithms"
              ]
            },
            {
              category: "🎯 Prediction & Prevention",
              capabilities: [
                "Risk prediction modeling",
                "Budget anomaly forecasting",
                "Vendor risk assessment",
                "Seasonal pattern prediction",
                "Early warning systems"
              ]
            },
            {
              category: "📊 Professional Reporting",
              capabilities: [
                "Executive dashboard analytics",
                "Compliance audit reports",
                "Risk assessment summaries",
                "Trend analysis reports",
                "Regulatory filing assistance"
              ]
            },
            {
              category: "⚡ Advanced Features",
              capabilities: [
                "Multi-language NLP analysis",
                "Real-time API integration",
                "Custom rule engine",
                "Machine learning optimization",
                "Enterprise-grade security"
              ]
            }
          ].map((section, index) => (
            <div key={index} className="bg-slate-700/30 border border-slate-600 rounded-lg p-5">
              <h3 className="text-lg font-semibold text-white mb-3">{section.category}</h3>
              <ul className="space-y-2">
                {section.capabilities.map((capability, capIndex) => (
                  <li key={capIndex} className="text-sm text-gray-300 flex items-start">
                    <CheckCircle className="w-4 h-4 text-green-400 mr-2 mt-0.5 flex-shrink-0" />
                    {capability}
                  </li>
                ))}
              </ul>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
};

export default ProfessionalControlCenter;
