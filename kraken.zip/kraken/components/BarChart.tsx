import React from 'react';
import { ChartDataItem } from '../types';

interface BarChartProps {
    data: ChartDataItem[];
}

const BarChart: React.FC<BarChartProps> = ({ data }) => {
    const maxValue = Math.max(...data.map(d => d.value), 1); // Avoid division by zero
    const chartHeight = 180;

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
            notation: 'compact'
        }).format(amount);
    };

    return (
        <div className="w-full h-full flex flex-col justify-end" style={{ height: `${chartHeight + 40}px` }}>
            <div className="flex justify-around items-end" style={{ height: `${chartHeight}px` }}>
                {data.map((item) => (
                    <div key={item.name} className="flex flex-col items-center w-1/3 group">
                        <div 
                            className="w-12 md:w-16 rounded-t-lg transition-all duration-300 hover:opacity-100 opacity-90" 
                            style={{ 
                                height: `${(item.value / maxValue) * chartHeight}px`, 
                                backgroundColor: item.color 
                            }}
                        >
                            <div className="relative opacity-0 group-hover:opacity-100 transition-opacity duration-300 -top-10 text-center">
                                <span className="text-xs font-bold p-1 bg-slate-900/70 text-white rounded-md">
                                    {formatCurrency(item.value)}
                                </span>
                            </div>
                        </div>
                    </div>
                ))}
            </div>
            <div className="flex justify-around items-center border-t-2 border-slate-700 pt-2 mt-1">
                 {data.map((item) => (
                    <div key={item.name} className="flex items-center gap-2 text-sm text-gray-300 w-1/3 justify-center">
                        <span className="w-3 h-3 rounded-full" style={{ backgroundColor: item.color }}></span>
                        <span>{item.name}</span>
                    </div>
                 ))}
            </div>
        </div>
    );
};

export default BarChart;
