import React, { useState } from 'react';
import { User } from '../types';
import DeepSeekStyleLogo from './DeepSeekStyleLogo';

interface HeaderProps {
    user: User;
    onLogout: () => void;
}

const Header: React.FC<HeaderProps> = ({ user, onLogout }) => {
    const [showDropdown, setShowDropdown] = useState(false);

    return (
        <header className="bg-white/95 backdrop-blur-md border-b border-gray-200 sticky top-0 z-10 shadow-lg">
            <div className="max-w-7xl mx-auto py-4 px-4 sm:px-6 lg:px-8 flex items-center justify-between">
                <div className="flex items-center gap-3">
                    <div className="cursor-pointer transition-transform duration-300 hover:scale-110 drop-shadow-md">
                        <DeepSeekStyleLogo size={42} className="text-blue-600" />
                    </div>
                    <h1 className="text-2xl sm:text-3xl font-bold text-gray-800 tracking-wide drop-shadow-sm">
                        Kraken AI
                    </h1>
                </div>
                
                <div className="flex items-center gap-4">
                    <span className="hidden sm:block text-sm text-gray-700 font-medium">
                        © 2025 <span className="text-blue-600 font-semibold">Azkiah</span> - SMK 9 Malang
                    </span>
                    
                    {/* User Menu */}
                    <div className="relative">
                        <button
                            onClick={() => setShowDropdown(!showDropdown)}
                            className="flex items-center gap-3 px-3 py-2 rounded-lg bg-gray-50 hover:bg-gray-100 transition-colors border border-gray-200 shadow-sm"
                        >
                            <div className="w-8 h-8 bg-gradient-to-r from-blue-500 to-blue-600 rounded-full flex items-center justify-center text-white font-medium text-sm shadow-sm">
                                {user.name.charAt(0).toUpperCase()}
                            </div>
                            <span className="hidden sm:block text-sm font-medium text-gray-800">
                                {user.name}
                            </span>
                        </button>
                        
                        {showDropdown && (
                            <div className="absolute right-0 mt-2 w-48 bg-white rounded-lg shadow-xl border border-gray-200 py-1 z-50">
                                <div className="px-4 py-2 border-b border-gray-100">
                                    <p className="text-sm font-medium text-gray-900">{user.name}</p>
                                    <p className="text-xs text-gray-600">{user.email}</p>
                                </div>
                                <button
                                    onClick={() => {
                                        setShowDropdown(false);
                                        onLogout();
                                    }}
                                    className="w-full text-left px-4 py-2 text-sm text-red-600 hover:bg-red-50 transition-colors font-medium"
                                >
                                    Keluar
                                </button>
                            </div>
                        )}
                    </div>
                </div>
            </div>
        </header>
    );
};

export default Header;