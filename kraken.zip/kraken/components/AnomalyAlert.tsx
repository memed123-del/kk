import React from 'react';
import { Anomaly, Transaction } from '../types';
import { ExclamationTriangleIcon } from './Icons';

interface AnomalyAlertProps {
    anomaly: Anomaly;
    transaction?: Transaction;
}

const AnomalyAlert: React.FC<AnomalyAlertProps> = ({ anomaly, transaction }) => {
    const severityStyles = {
        Tinggi: 'border-red-500 bg-red-900/30 text-red-200',
        Sedang: 'border-yellow-500 bg-yellow-900/30 text-yellow-200',
        Rendah: 'border-cyan-500 bg-cyan-900/30 text-cyan-200',
    };

    const severityClass = severityStyles[anomaly.severity] || severityStyles.Rendah;

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
        }).format(amount);
    };

    const getFraudTypeIcon = (fraudType?: string) => {
        switch (fraudType?.toLowerCase()) {
            case 'markup': return '💰';
            case 'kickback': return '🤝';
            case 'ghost_employee': return '👻';
            case 'duplicate_payment': return '📋';
            case 'shell_company': return '🏭';
            case 'timing_anomaly': return '⏰';
            default: return '🚨';
        }
    };

    const getPriorityColor = (priority?: string) => {
        switch (priority) {
            case 'urgent': return 'text-red-400 font-bold';
            case 'high': return 'text-orange-400 font-semibold';
            case 'medium': return 'text-yellow-400';
            default: return 'text-blue-400';
        }
    };

    return (
        <div className={`p-5 rounded-xl border-l-4 ${severityClass} backdrop-blur-sm hover:bg-opacity-50 transition-all duration-200`}>
            <div className="flex items-start gap-4">
                <div className="flex-shrink-0 pt-1">
                    <div className="flex items-center gap-2">
                        <span className="text-xl">{getFraudTypeIcon(anomaly.fraud_type)}</span>
                        <ExclamationTriangleIcon className="w-5 h-5"/>
                    </div>
                </div>
                <div className="flex-1">
                    <div className="flex items-center justify-between mb-2">
                        <div className="flex items-center gap-3">
                            <span className="font-bold text-sm bg-gray-800 px-2 py-1 rounded">
                                {anomaly.severity}
                            </span>
                            {anomaly.fraud_type && (
                                <span className="text-xs bg-slate-700 px-2 py-1 rounded uppercase font-mono">
                                    {anomaly.fraud_type.replace('_', ' ')}
                                </span>
                            )}
                        </div>
                        {anomaly.risk_score && (
                            <div className="text-right">
                                <div className="text-xs text-gray-400">Risk Score</div>
                                <div className={`text-lg font-bold ${anomaly.risk_score > 80 ? 'text-red-400' : anomaly.risk_score > 60 ? 'text-yellow-400' : 'text-green-400'}`}>
                                    {anomaly.risk_score}/100
                                </div>
                            </div>
                        )}
                    </div>
                    
                    {transaction && (
                        <div className="bg-slate-800/50 rounded-lg p-3 mb-3">
                            <div className="grid grid-cols-2 gap-2 text-xs">
                                <div>
                                    <span className="text-gray-400">Transaksi:</span>
                                    <p className="font-mono text-gray-200">{transaction.description}</p>
                                </div>
                                <div>
                                    <span className="text-gray-400">Jumlah:</span>
                                    <p className="font-bold text-white">{formatCurrency(transaction.amount)}</p>
                                </div>
                                <div>
                                    <span className="text-gray-400">Kategori:</span>
                                    <p className="text-gray-200">{transaction.category}</p>
                                </div>
                                <div>
                                    <span className="text-gray-400">Tanggal:</span>
                                    <p className="text-gray-200">{new Date(transaction.date).toLocaleDateString('id-ID')}</p>
                                </div>
                            </div>
                        </div>
                    )}
                    
                    <p className="text-sm leading-relaxed mb-3">{anomaly.reason}</p>
                    
                    {anomaly.recommended_action && (
                        <div className="bg-blue-900/20 border border-blue-700/30 rounded-lg p-3 mb-3">
                            <h4 className="text-xs font-semibold text-blue-300 mb-1">🎯 TINDAKAN REKOMENDASI:</h4>
                            <p className="text-sm text-blue-200">{anomaly.recommended_action}</p>
                        </div>
                    )}
                    
                    <div className="flex items-center justify-between text-xs">
                        <div className="flex items-center gap-3">
                            {anomaly.investigation_priority && (
                                <span className={`px-2 py-1 rounded text-xs font-medium ${getPriorityColor(anomaly.investigation_priority)}`}>
                                    Priority: {anomaly.investigation_priority.toUpperCase()}
                                </span>
                            )}
                            {anomaly.detection_method && (
                                <span className="text-gray-400">
                                    Detected by: {anomaly.detection_method}
                                </span>
                            )}
                        </div>
                        <button className="px-3 py-1 bg-cyan-600 hover:bg-cyan-700 rounded text-xs font-medium transition-colors">
                            Investigate
                        </button>
                    </div>
                </div>
            </div>
        </div>
    );
};

export default AnomalyAlert;