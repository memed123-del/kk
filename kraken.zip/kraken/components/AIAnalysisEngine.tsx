import React, { useState, useEffect } from 'react';
import { 
  Brain, Zap, Shield, TrendingUp, AlertTriangle, 
  Search, FileText, BarChart3, Users, DollarSign,
  Clock, CheckCircle, XCircle, PlayCircle, StopCircle
} from 'lucide-react';

interface AICapability {
  id: string;
  title: string;
  description: string;
  icon: React.ComponentType<any>;
  category: 'detection' | 'analysis' | 'prediction' | 'reporting';
  complexity: 'basic' | 'advanced' | 'expert';
  status: 'active' | 'processing' | 'completed' | 'error';
  accuracy: number;
  processingTime: string;
  examples: string[];
}

interface AIAnalysisEngineProps {
  onAnalysisStart?: (capabilityId: string) => void;
  onAnalysisComplete?: (capabilityId: string, results: any) => void;
}

const AIAnalysisEngine: React.FC<AIAnalysisEngineProps> = ({ 
  onAnalysisStart, 
  onAnalysisComplete 
}) => {
  const [activeTab, setActiveTab] = useState<'capabilities' | 'realtime' | 'insights'>('capabilities');
  const [runningAnalyses, setRunningAnalyses] = useState<Set<string>>(new Set());
  const [analysisResults, setAnalysisResults] = useState<Record<string, any>>({});

  const aiCapabilities: AICapability[] = [
    {
      id: 'fraud-detection',
      title: 'Deteksi Pola Penipuan',
      description: 'Algoritma ML canggih untuk mendeteksi pola penipuan dan transaksi mencurigakan secara real-time',
      icon: Shield,
      category: 'detection',
      complexity: 'expert',
      status: 'active',
      accuracy: 94.7,
      processingTime: '0.3s',
      examples: [
        'Deteksi duplicate payments dengan vendor sama',
        'Analisis splitting transactions untuk menghindari approval limits',
        'Identifikasi round dollar amounts yang mencurigakan',
        'Pattern matching untuk ghost vendors'
      ]
    },
    {
      id: 'behavioral-analysis',
      title: 'Analisis Pola Perilaku',
      description: 'Analisis mendalam pola perilaku keuangan dan anomali dalam kebiasaan transaksi',
      icon: Brain,
      category: 'analysis',
      complexity: 'expert',
      status: 'active',
      accuracy: 91.2,
      processingTime: '1.2s',
      examples: [
        'Deteksi perubahan pola spending yang drastis',
        'Analisis timing transaksi yang tidak normal',
        'Identifikasi vendor favoritism patterns',
        'Weekend/holiday transaction anomalies'
      ]
    },
    {
      id: 'risk-prediction',
      title: 'Pemodelan Risiko Prediktif',
      description: 'Machine learning untuk prediksi risiko korupsi berdasarkan data historis dan tren',
      icon: TrendingUp,
      category: 'prediction',
      complexity: 'expert',
      status: 'active',
      accuracy: 88.9,
      processingTime: '2.1s',
      examples: [
        'Prediksi vendor yang berpotensi berisiko tinggi',
        'Forecasting budget anomalies 3 bulan ke depan',
        'Early warning untuk procurement risks',
        'Seasonal corruption pattern prediction'
      ]
    },
    {
      id: 'document-analysis',
      title: 'Intelijen Dokumen',
      description: 'AI untuk analisis dokumen, kontrak, dan faktur untuk mendeteksi ketidaksesuaian',
      icon: FileText,
      category: 'analysis',
      complexity: 'advanced',
      status: 'active',
      accuracy: 96.3,
      processingTime: '0.8s',
      examples: [
        'OCR dan analisis invoice authenticity',
        'Contract clause anomaly detection',
        'Duplicate document identification',
        'Signature and stamp verification'
      ]
    },
    {
      id: 'network-analysis',
      title: 'Analisis Jaringan Transaksi',
      description: 'Analisis grafik untuk mengidentifikasi hubungan mencurigakan antar entitas',
      icon: Users,
      category: 'analysis',
      complexity: 'expert',
      status: 'active',
      accuracy: 92.5,
      processingTime: '1.8s',
      examples: [
        'Mapping vendor-employee relationships',
        'Shell company detection networks',
        'Money flow circular patterns',
        'Hidden beneficial ownership analysis'
      ]
    },
    {
      id: 'compliance-monitoring',
      title: 'Pemantauan Kepatuhan Real-time',
      description: 'Pemantauan kepatuhan secara real-time dengan persyaratan regulasi',
      icon: CheckCircle,
      category: 'detection',
      complexity: 'advanced',
      status: 'active',
      accuracy: 99.1,
      processingTime: '0.1s',
      examples: [
        'SOX compliance real-time checking',
        'Anti-bribery law compliance monitoring',
        'Procurement regulation adherence',
        'Internal policy violation detection'
      ]
    },
    {
      id: 'sentiment-analysis',
      title: 'Communication Sentiment Analysis',
      description: 'NLP analysis untuk email, chat, dan komunikasi yang mencurigakan',
      icon: Search,
      category: 'analysis',
      complexity: 'advanced',
      status: 'active',
      accuracy: 87.4,
      processingTime: '0.5s',
      examples: [
        'Email sentiment untuk detecting bribery',
        'Chat pattern analysis untuk collusion',
        'Language pattern untuk insider trading',
        'Communication urgency anomaly detection'
      ]
    },
    {
      id: 'financial-modeling',
      title: 'Advanced Financial Modeling',
      description: 'Complex financial modeling untuk benchmarking dan outlier detection',
      icon: BarChart3,
      category: 'analysis',
      complexity: 'expert',
      status: 'active',
      accuracy: 93.8,
      processingTime: '3.2s',
      examples: [
        'Cost benchmarking vs market rates',
        'ROI anomaly detection per project',
        'Budget variance unexplained analysis',
        'Expense category drift detection'
      ]
    }
  ];

  const realtimeMetrics = {
    transactionsProcessed: 45782,
    anomaliesDetected: 23,
    riskScoreAvg: 23.7,
    processingSpeed: '847 tx/s',
    uptime: '99.97%',
    lastUpdate: new Date().toISOString()
  };

  const runAnalysis = async (capabilityId: string) => {
    setRunningAnalyses(prev => new Set([...prev, capabilityId]));
    onAnalysisStart?.(capabilityId);

    // Simulate AI processing
    setTimeout(() => {
      const results = {
        id: capabilityId,
        status: 'completed',
        confidence: Math.random() * 40 + 60, // 60-100%
        findings: Math.floor(Math.random() * 15) + 1,
        recommendations: Math.floor(Math.random() * 8) + 3,
        timestamp: new Date().toISOString()
      };

      setAnalysisResults(prev => ({ ...prev, [capabilityId]: results }));
      setRunningAnalyses(prev => {
        const newSet = new Set(prev);
        newSet.delete(capabilityId);
        return newSet;
      });
      onAnalysisComplete?.(capabilityId, results);
    }, Math.random() * 3000 + 1000);
  };

  const getCategoryColor = (category: AICapability['category']) => {
    switch (category) {
      case 'detection': return 'from-red-900/50 to-red-800/50 border-red-700';
      case 'analysis': return 'from-blue-900/50 to-blue-800/50 border-blue-700';
      case 'prediction': return 'from-purple-900/50 to-purple-800/50 border-purple-700';
      case 'reporting': return 'from-green-900/50 to-green-800/50 border-green-700';
      default: return 'from-gray-900/50 to-gray-800/50 border-gray-700';
    }
  };

  const getComplexityColor = (complexity: AICapability['complexity']) => {
    switch (complexity) {
      case 'basic': return 'text-green-400';
      case 'advanced': return 'text-yellow-400';
      case 'expert': return 'text-red-400';
      default: return 'text-gray-400';
    }
  };

  const formatNumber = (num: number) => {
    return new Intl.NumberFormat('id-ID').format(num);
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="bg-gradient-to-r from-cyan-900/40 to-blue-900/40 border border-cyan-700 rounded-xl p-6">
        <div className="flex items-center justify-between">
          <div>
            <h2 className="text-2xl font-bold text-white flex items-center mb-2">
              <Brain className="w-8 h-8 mr-3 text-cyan-400" />
              Mesin Analisis Kraken AI
            </h2>
            <p className="text-gray-300">
              Sistem deteksi dan analisis anti-korupsi bertenaga AI canggih
            </p>
          </div>
          <div className="text-right">
            <div className="text-3xl font-bold text-cyan-400">{realtimeMetrics.uptime}</div>
            <div className="text-sm text-gray-400">Waktu Aktif Sistem</div>
          </div>
        </div>
      </div>

      {/* Navigation Tabs */}
      <div className="flex bg-slate-800/40 border border-slate-700 rounded-lg p-1">
        {[
          { id: 'capabilities', label: 'Kemampuan AI', icon: Zap },
          { id: 'realtime', label: 'Metrik Real-time', icon: Clock },
          { id: 'insights', label: 'Wawasan AI', icon: TrendingUp }
        ].map(({ id, label, icon: Icon }) => (
          <button
            key={id}
            onClick={() => setActiveTab(id as any)}
            className={`flex-1 flex items-center justify-center px-4 py-3 rounded-md text-sm font-medium transition-colors ${
              activeTab === id
                ? 'bg-cyan-600 text-white'
                : 'text-gray-300 hover:text-white hover:bg-slate-700'
            }`}
          >
            <Icon className="w-4 h-4 mr-2" />
            {label}
          </button>
        ))}
      </div>

      {/* AI Capabilities Tab */}
      {activeTab === 'capabilities' && (
        <div className="space-y-4">
          <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-4">
            {aiCapabilities.map((capability) => (
              <div
                key={capability.id}
                className={`bg-gradient-to-br ${getCategoryColor(capability.category)} border rounded-xl p-6 hover:shadow-lg transition-all`}
              >
                <div className="flex items-start justify-between mb-4">
                  <capability.icon className="w-8 h-8 text-white" />
                  <div className="text-right">
                    <div className={`text-xs font-medium ${getComplexityColor(capability.complexity)}`}>
                      {capability.complexity.toUpperCase()}
                    </div>
                    <div className="text-xs text-gray-400">{capability.processingTime}</div>
                  </div>
                </div>

                <h3 className="text-lg font-semibold text-white mb-2">{capability.title}</h3>
                <p className="text-sm text-gray-300 mb-4 leading-relaxed">
                  {capability.description}
                </p>

                {/* Accuracy Bar */}
                <div className="mb-4">
                  <div className="flex justify-between text-xs text-gray-400 mb-1">
                    <span>Akurasi</span>
                    <span>{capability.accuracy}%</span>
                  </div>
                  <div className="w-full bg-gray-700 rounded-full h-2">
                    <div
                      className="h-2 rounded-full bg-gradient-to-r from-green-500 to-cyan-500"
                      style={{ width: `${capability.accuracy}%` }}
                    />
                  </div>
                </div>

                {/* Examples */}
                <div className="mb-4">
                  <div className="text-xs text-gray-400 mb-2">Fitur Utama:</div>
                  <ul className="text-xs text-gray-300 space-y-1">
                    {capability.examples.slice(0, 2).map((example, index) => (
                      <li key={index} className="flex items-start">
                        <span className="text-cyan-400 mr-1">•</span>
                        {example}
                      </li>
                    ))}
                  </ul>
                </div>

                {/* Action Button */}
                <button
                  onClick={() => runAnalysis(capability.id)}
                  disabled={runningAnalyses.has(capability.id)}
                  className="w-full bg-white/10 hover:bg-white/20 border border-white/20 rounded-lg py-2 px-4 text-sm font-medium text-white transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center"
                >
                  {runningAnalyses.has(capability.id) ? (
                    <>
                      <StopCircle className="w-4 h-4 mr-2 animate-spin" />
                      Memproses...
                    </>
                  ) : (
                    <>
                      <PlayCircle className="w-4 h-4 mr-2" />
                      Jalankan Analisis
                    </>
                  )}
                </button>

                {/* Results */}
                {analysisResults[capability.id] && (
                  <div className="mt-3 p-3 bg-black/20 rounded-lg">
                    <div className="text-xs text-green-400 mb-1">✓ Analisis Selesai</div>
                    <div className="text-xs text-gray-300">
                      Keyakinan: {analysisResults[capability.id].confidence.toFixed(1)}% | 
                      Temuan: {analysisResults[capability.id].findings} | 
                      Rekomendasi: {analysisResults[capability.id].recommendations}
                    </div>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      )}

      {/* Real-time Metrics Tab */}
      {activeTab === 'realtime' && (
        <div className="space-y-6">
          {/* Live Metrics Grid */}
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
              <DollarSign className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{formatNumber(realtimeMetrics.transactionsProcessed)}</div>
              <div className="text-xs text-gray-400">Transaksi Diproses</div>
            </div>

            <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
              <AlertTriangle className="w-8 h-8 text-red-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{realtimeMetrics.anomaliesDetected}</div>
              <div className="text-xs text-gray-400">Anomali Terdeteksi</div>
            </div>

            <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
              <BarChart3 className="w-8 h-8 text-yellow-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{realtimeMetrics.riskScoreAvg}</div>
              <div className="text-xs text-gray-400">Skor Risiko Rata-rata</div>
            </div>

            <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
              <Zap className="w-8 h-8 text-cyan-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{realtimeMetrics.processingSpeed}</div>
              <div className="text-xs text-gray-400">Kecepatan Proses</div>
            </div>

            <div className="bg-slate-800/40 border border-slate-700 rounded-lg p-4 text-center">
              <CheckCircle className="w-8 h-8 text-green-400 mx-auto mb-2" />
              <div className="text-2xl font-bold text-white">{realtimeMetrics.uptime}</div>
              <div className="text-xs text-gray-400">Waktu Aktif Sistem</div>
            </div>
          </div>

          {/* Processing Status */}
          <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
            <h3 className="text-lg font-semibold text-white mb-4">🔄 Proses Aktif</h3>
            <div className="space-y-3">
              {Array.from(runningAnalyses).map((analysisId) => {
                const capability = aiCapabilities.find(c => c.id === analysisId);
                return capability ? (
                  <div key={analysisId} className="flex items-center justify-between p-3 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center">
                      <capability.icon className="w-5 h-5 text-cyan-400 mr-3" />
                      <span className="text-white font-medium">{capability.title}</span>
                    </div>
                    <div className="flex items-center text-cyan-400">
                      <Clock className="w-4 h-4 mr-2 animate-spin" />
                      <span className="text-sm">Memproses...</span>
                    </div>
                  </div>
                ) : null;
              })}
              {runningAnalyses.size === 0 && (
                <div className="text-center text-gray-400 py-4">
                  Tidak ada tugas pemrosesan aktif
                </div>
              )}
            </div>
          </div>
        </div>
      )}

      {/* AI Insights Tab */}
      {activeTab === 'insights' && (
        <div className="space-y-6">
          <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
            {/* Key Insights */}
            <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                <Brain className="w-5 h-5 mr-2 text-purple-400" />
                Wawasan yang Dihasilkan AI
              </h3>
              <div className="space-y-4">
                <div className="p-4 bg-gradient-to-r from-purple-900/30 to-pink-900/30 border border-purple-700 rounded-lg">
                  <div className="text-sm text-purple-300 font-medium mb-1">Deteksi Pola</div>
                  <p className="text-sm text-gray-300">
                    AI mendeteksi pengelompokan transaksi bernilai tinggi yang tidak biasa pada Jumat sore, 
                    menunjukkan potensi persetujuan terburu-buru di akhir pekan yang memerlukan peninjauan.
                  </p>
                </div>
                <div className="p-4 bg-gradient-to-r from-blue-900/30 to-cyan-900/30 border border-blue-700 rounded-lg">
                  <div className="text-sm text-blue-300 font-medium mb-1">Prediksi Risiko</div>
                  <p className="text-sm text-gray-300">
                    Model prediktif menunjukkan risiko korupsi 23% lebih tinggi di Q4 berdasarkan 
                    pola tekanan anggaran historis dan analisis perilaku vendor.
                  </p>
                </div>
                <div className="p-4 bg-gradient-to-r from-green-900/30 to-teal-900/30 border border-green-700 rounded-lg">
                  <div className="text-sm text-green-300 font-medium mb-1">Peningkatan Kepatuhan</div>
                  <p className="text-sm text-gray-300">
                    Menerapkan kontrol yang direkomendasikan dapat mengurangi positif palsu sebesar 34% 
                    sambil mempertahankan akurasi deteksi 99,2% untuk kasus fraud aktual.
                  </p>
                </div>
              </div>
            </div>

            {/* Recommendations */}
            <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
              <h3 className="text-lg font-semibold text-white mb-4 flex items-center">
                <TrendingUp className="w-5 h-5 mr-2 text-green-400" />
                Rekomendasi Cerdas
              </h3>
              <div className="space-y-3">
                {[
                  {
                    priority: 'Tinggi',
                    action: 'Tinjau pola pembayaran vendor untuk 10 pemasok teratas',
                    impact: 'Mencegah potensi Rp2,3M dalam transaksi mencurigakan',
                    color: 'red'
                  },
                  {
                    priority: 'Sedang',
                    action: 'Terapkan alur persetujuan otomatis untuk jumlah >Rp50 juta',
                    impact: 'Mengurangi beban pengawasan manual sebesar 45%',
                    color: 'yellow'
                  },
                  {
                    priority: 'Rendah',
                    action: 'Perbarui aturan deteksi fraud berdasarkan pola terbaru',
                    impact: 'Meningkatkan akurasi deteksi sebesar 12%',
                    color: 'green'
                  }
                ].map((rec, index) => (
                  <div key={index} className="p-3 bg-slate-700/50 rounded-lg">
                    <div className="flex items-center justify-between mb-2">
                      <span className={`text-xs font-medium px-2 py-1 rounded ${
                        rec.color === 'red' ? 'bg-red-900/50 text-red-300' :
                        rec.color === 'yellow' ? 'bg-yellow-900/50 text-yellow-300' :
                        'bg-green-900/50 text-green-300'
                      }`}>
                        Prioritas {rec.priority}
                      </span>
                    </div>
                    <p className="text-sm text-white font-medium mb-1">{rec.action}</p>
                    <p className="text-xs text-gray-400">{rec.impact}</p>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AIAnalysisEngine;
