import React, { useState } from 'react';
import { EyeIcon, EyeSlashIcon, KeyIcon, CheckCircleIcon, ExclamationTriangleIcon } from './Icons';

interface ApiKeyInputProps {
    label: string;
    placeholder: string;
    value: string;
    onChange: (value: string) => void;
    onTest?: () => Promise<boolean>;
    aiType: 'financial' | 'legal';
    className?: string;
}

const ApiKeyInput: React.FC<ApiKeyInputProps> = ({
    label,
    placeholder,
    value,
    onChange,
    onTest,
    aiType,
    className = ''
}) => {
    const [showKey, setShowKey] = useState(false);
    const [testing, setTesting] = useState(false);
    const [testResult, setTestResult] = useState<'success' | 'error' | null>(null);

    const handleTest = async () => {
        if (!onTest || !value.trim()) return;
        
        setTesting(true);
        setTestResult(null);
        
        try {
            const success = await onTest();
            setTestResult(success ? 'success' : 'error');
        } catch {
            setTestResult('error');
        } finally {
            setTesting(false);
        }
    };

    const getThemeClasses = () => {
        if (aiType === 'legal') {
            return {
                border: 'border-amber-700/30 focus:border-amber-500',
                background: 'bg-amber-900/20',
                text: 'text-amber-100 placeholder-amber-300/60',
                button: 'bg-amber-600 hover:bg-amber-700',
                icon: 'text-amber-400'
            };
        } else {
            return {
                border: 'border-cyan-700/30 focus:border-cyan-500',
                background: 'bg-cyan-900/20',
                text: 'text-cyan-100 placeholder-cyan-300/60',
                button: 'bg-cyan-600 hover:bg-cyan-700',
                icon: 'text-cyan-400'
            };
        }
    };

    const theme = getThemeClasses();

    return (
        <div className={`space-y-3 ${className}`}>
            <label className="block text-sm font-medium text-gray-300">
                <KeyIcon className={`inline w-4 h-4 mr-2 ${theme.icon}`} />
                {label}
            </label>
            
            <div className="relative">
                <input
                    type={showKey ? 'text' : 'password'}
                    value={value}
                    onChange={(e) => onChange(e.target.value)}
                    placeholder={placeholder}
                    className={`w-full px-4 py-3 pr-24 ${theme.background} ${theme.border} ${theme.text} rounded-lg focus:ring-2 focus:ring-opacity-50 transition-colors`}
                />
                
                <div className="absolute inset-y-0 right-0 flex items-center pr-3 space-x-1">
                    <button
                        type="button"
                        onClick={() => setShowKey(!showKey)}
                        className="p-1 text-gray-400 hover:text-gray-200 transition-colors"
                        title={showKey ? 'Sembunyikan API Key' : 'Tampilkan API Key'}
                    >
                        {showKey ? (
                            <EyeSlashIcon className="w-4 h-4" />
                        ) : (
                            <EyeIcon className="w-4 h-4" />
                        )}
                    </button>
                    
                    {testResult === 'success' && (
                        <CheckCircleIcon className="w-4 h-4 text-green-400" />
                    )}
                    
                    {testResult === 'error' && (
                        <ExclamationTriangleIcon className="w-4 h-4 text-red-400" />
                    )}
                </div>
            </div>
            
            <div className="flex items-center justify-between">
                <div className="text-xs text-gray-400">
                    {value.trim() ? (
                        <span className="text-green-400">✓ API Key terkonfigurasi</span>
                    ) : (
                        <span className="text-yellow-400">⚠ API Key belum diatur</span>
                    )}
                </div>
                
                {onTest && value.trim() && (
                    <button
                        onClick={handleTest}
                        disabled={testing}
                        className={`px-3 py-1 text-xs font-medium text-white ${theme.button} rounded transition-colors disabled:opacity-50`}
                    >
                        {testing ? 'Testing...' : 'Test API'}
                    </button>
                )}
            </div>
            
            {testResult === 'success' && (
                <div className="text-xs text-green-400 bg-green-900/20 border border-green-700/30 rounded p-2">
                    ✅ API Key valid dan berfungsi dengan baik
                </div>
            )}
            
            {testResult === 'error' && (
                <div className="text-xs text-red-400 bg-red-900/20 border border-red-700/30 rounded p-2">
                    ❌ API Key tidak valid atau bermasalah. Periksa kembali atau coba API Key lain.
                </div>
            )}
        </div>
    );
};

export default ApiKeyInput;
