import React, { useState, useEffect } from 'react';
import { QuizQuestion, LearningProgress } from '../types';
import { PlayCircleIcon, CheckCircleIcon, XMarkIcon, LightBulbIcon, TrophyIcon, FireIcon, ArrowLeftIcon, ArrowRightIcon } from './Icons';

interface InteractiveQuizProps {
    onUpdateProgress: (progress: LearningProgress) => void;
    userProgress: LearningProgress;
}

// Data kuis interaktif tentang hukum anti-korupsi
const QUIZ_QUESTIONS: QuizQuestion[] = [
    {
        id: 'quiz-001',
        question: 'Menurut UU No. 20 Tahun 2001, apa definisi tindak pidana korupsi?',
        options: [
            'Mengambil uang negara untuk kepentingan pribadi',
            'Perbuatan melawan hukum yang memperkaya diri sendiri atau orang lain yang merugikan keuangan negara',
            'Memberikan suap kepada pejabat pemerintah',
            'Semua perbuatan curang dalam pemerintahan'
        ],
        correctAnswer: 1,
        explanation: 'Tindak pidana korupsi adalah perbuatan melawan hukum yang dilakukan untuk memperkaya diri sendiri atau orang lain yang dapat merugikan keuangan negara atau perekonomian negara.',
        category: 'anti-corruption',
        difficulty: 'medium',
        points: 15,
        relatedArticleId: 'uu-20-2001'
    },
    {
        id: 'quiz-002',
        question: 'Apa yang dimaksud dengan gratifikasi dalam konteks anti-korupsi?',
        options: [
            'Bonus gaji dari perusahaan',
            'Pemberian dalam arti luas kepada pegawai negeri yang berhubungan dengan jabatannya',
            'Hadiah ulang tahun dari keluarga',
            'Tunjangan resmi dari pemerintah'
        ],
        correctAnswer: 1,
        explanation: 'Gratifikasi adalah pemberian dalam arti luas kepada pegawai negeri atau penyelenggara negara yang berhubungan dengan jabatannya dan berlawanan dengan kewajiban atau tugasnya.',
        category: 'anti-corruption',
        difficulty: 'easy',
        points: 10,
        relatedArticleId: 'uu-8-2010'
    },
    {
        id: 'quiz-003',
        question: 'Berdasarkan UUD 1945 Pasal 23 ayat (1), bagaimana prinsip pengelolaan keuangan negara?',
        options: [
            'Tertutup dan terbatas untuk pejabat tertentu',
            'Terbuka dan bertanggung jawab untuk kemakmuran rakyat',
            'Fleksibel sesuai kebutuhan pemerintah',
            'Diserahkan sepenuhnya kepada menteri keuangan'
        ],
        correctAnswer: 1,
        explanation: 'APBN harus dilaksanakan secara terbuka dan bertanggung jawab untuk sebesar-besarnya kemakmuran rakyat, memastikan transparansi dan akuntabilitas.',
        category: 'financial',
        difficulty: 'medium',
        points: 15,
        relatedArticleId: 'uud-23'
    },
    {
        id: 'quiz-004',
        question: 'Sebagai Gen Z yang aktif di media sosial, bagaimana cara terbaik melaporkan dugaan korupsi?',
        options: [
            'Posting di semua platform media sosial dengan detail lengkap',
            'Melaporkan melalui kanal resmi seperti KPK dan hindari penyebaran hoaks',
            'Menunggu sampai ada bukti 100% baru melaporkan',
            'Menyebarkan informasi secara viral tanpa verifikasi'
        ],
        correctAnswer: 1,
        explanation: 'Gen Z harus menggunakan media sosial secara bijak dengan melaporkan melalui kanal resmi dan menghindari penyebaran informasi yang belum terverifikasi.',
        category: 'ethics',
        difficulty: 'easy',
        points: 10,
        relatedArticleId: 'ethics-social-media'
    },
    {
        id: 'quiz-005',
        question: 'Apa hukuman maksimal untuk tindak pidana korupsi menurut UU Tipikor?',
        options: [
            'Penjara 10 tahun dan denda Rp 500 juta',
            'Penjara seumur hidup atau 20 tahun dan denda sesuai kerugian negara',
            'Penjara 5 tahun dan pencabutan hak politik',
            'Denda maksimal Rp 1 miliar tanpa penjara'
        ],
        correctAnswer: 1,
        explanation: 'Hukuman untuk korupsi bisa berupa penjara seumur hidup atau paling lama 20 tahun, plus denda yang disesuaikan dengan kerugian negara yang ditimbulkan.',
        category: 'anti-corruption',
        difficulty: 'hard',
        points: 20,
        relatedArticleId: 'uu-20-2001'
    },
    {
        id: 'quiz-006',
        question: 'Menurut UU Keterbukaan Informasi Publik, siapa yang berhak meminta informasi publik?',
        options: [
            'Hanya jurnalis dan aktivis LSM',
            'Setiap warga negara Indonesia',
            'Hanya mereka yang memiliki kepentingan hukum',
            'Hanya pejabat pemerintah dan DPR'
        ],
        correctAnswer: 1,
        explanation: 'Setiap warga negara berhak meminta informasi publik sebagai bentuk transparansi dan akuntabilitas pemerintah. Ini adalah hak fundamental dalam demokrasi.',
        category: 'governance',
        difficulty: 'easy',
        points: 10,
        relatedArticleId: 'uu-14-2008'
    }
];

const InteractiveQuiz: React.FC<InteractiveQuizProps> = ({ onUpdateProgress, userProgress }) => {
    const [currentQuestionIndex, setCurrentQuestionIndex] = useState(0);
    const [selectedAnswer, setSelectedAnswer] = useState<number | null>(null);
    const [showExplanation, setShowExplanation] = useState(false);
    const [quizCompleted, setQuizCompleted] = useState(false);
    const [score, setScore] = useState(0);
    const [answeredQuestions, setAnsweredQuestions] = useState<{ [key: number]: boolean }>({});
    const [timeLeft, setTimeLeft] = useState(30); // 30 detik per soal
    const [quizStarted, setQuizStarted] = useState(false);

    const currentQuestion = QUIZ_QUESTIONS[currentQuestionIndex];

    // Timer countdown
    useEffect(() => {
        if (quizStarted && !showExplanation && timeLeft > 0) {
            const timer = setTimeout(() => setTimeLeft(timeLeft - 1), 1000);
            return () => clearTimeout(timer);
        } else if (timeLeft === 0 && !showExplanation) {
            handleAnswerSubmit();
        }
    }, [timeLeft, showExplanation, quizStarted]);

    // Reset timer saat pindah soal
    useEffect(() => {
        setTimeLeft(30);
    }, [currentQuestionIndex]);

    const handleAnswerSelect = (answerIndex: number) => {
        if (!showExplanation) {
            setSelectedAnswer(answerIndex);
        }
    };

    const handleAnswerSubmit = () => {
        if (selectedAnswer === null && timeLeft > 0) return;
        
        const isCorrect = selectedAnswer === currentQuestion.correctAnswer;
        if (isCorrect) {
            setScore(score + currentQuestion.points);
        }
        
        setAnsweredQuestions({ ...answeredQuestions, [currentQuestionIndex]: isCorrect });
        setShowExplanation(true);
    };

    const handleNextQuestion = () => {
        if (currentQuestionIndex < QUIZ_QUESTIONS.length - 1) {
            setCurrentQuestionIndex(currentQuestionIndex + 1);
            setSelectedAnswer(null);
            setShowExplanation(false);
        } else {
            completeQuiz();
        }
    };

    const handlePreviousQuestion = () => {
        if (currentQuestionIndex > 0) {
            setCurrentQuestionIndex(currentQuestionIndex - 1);
            setSelectedAnswer(null);
            setShowExplanation(false);
        }
    };

    const completeQuiz = () => {
        setQuizCompleted(true);
        
        // Update progress
        const correctAnswers = Object.values(answeredQuestions).filter(Boolean).length;
        const newBadges = [...userProgress.badges];
        
        // Award badges based on performance
        if (correctAnswers === QUIZ_QUESTIONS.length && !newBadges.includes('Quiz Master')) {
            newBadges.push('Quiz Master');
        }
        if (correctAnswers >= QUIZ_QUESTIONS.length * 0.8 && !newBadges.includes('Hukum Expert')) {
            newBadges.push('Hukum Expert');
        }
        if (correctAnswers >= QUIZ_QUESTIONS.length * 0.6 && !newBadges.includes('Pemula Anti-Korupsi')) {
            newBadges.push('Pemula Anti-Korupsi');
        }

        const updatedProgress = {
            ...userProgress,
            quizzesCompleted: [...userProgress.quizzesCompleted, 'interactive-quiz-1'],
            totalPoints: userProgress.totalPoints + score,
            badges: newBadges,
            streak: userProgress.streak + 1,
            lastActivityDate: new Date()
        };

        onUpdateProgress(updatedProgress);
    };

    const startQuiz = () => {
        setQuizStarted(true);
        setCurrentQuestionIndex(0);
        setSelectedAnswer(null);
        setShowExplanation(false);
        setQuizCompleted(false);
        setScore(0);
        setAnsweredQuestions({});
        setTimeLeft(30);
    };

    const resetQuiz = () => {
        setQuizStarted(false);
        setCurrentQuestionIndex(0);
        setSelectedAnswer(null);
        setShowExplanation(false);
        setQuizCompleted(false);
        setScore(0);
        setAnsweredQuestions({});
        setTimeLeft(30);
    };

    if (!quizStarted) {
        return (
            <div className="max-w-4xl mx-auto">
                <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-8 border border-slate-700/50 text-center">
                    <div className="w-20 h-20 bg-gradient-to-r from-blue-500 to-cyan-500 rounded-full flex items-center justify-center mx-auto mb-6">
                        <PlayCircleIcon className="w-10 h-10 text-white" />
                    </div>
                    <h2 className="text-3xl font-bold text-white mb-4">🎮 Kuis Interaktif Hukum Anti-Korupsi</h2>
                    <p className="text-slate-300 mb-6 text-lg">
                        Uji pemahaman kamu tentang hukum anti-korupsi dengan {QUIZ_QUESTIONS.length} soal yang menantang!
                    </p>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-8">
                        <div className="bg-slate-700/30 rounded-lg p-4">
                            <div className="text-blue-400 text-2xl font-bold">{QUIZ_QUESTIONS.length}</div>
                            <div className="text-slate-300 text-sm">Total Soal</div>
                        </div>
                        <div className="bg-slate-700/30 rounded-lg p-4">
                            <div className="text-green-400 text-2xl font-bold">30</div>
                            <div className="text-slate-300 text-sm">Detik per Soal</div>
                        </div>
                        <div className="bg-slate-700/30 rounded-lg p-4">
                            <div className="text-yellow-400 text-2xl font-bold">{QUIZ_QUESTIONS.reduce((sum, q) => sum + q.points, 0)}</div>
                            <div className="text-slate-300 text-sm">Total Poin</div>
                        </div>
                    </div>

                    <button 
                        onClick={startQuiz}
                        className="bg-gradient-to-r from-blue-600 to-cyan-600 hover:from-blue-700 hover:to-cyan-700 text-white px-8 py-4 rounded-lg font-bold text-lg transition-all transform hover:scale-105 shadow-lg"
                    >
                        🚀 Mulai Kuis Sekarang!
                    </button>
                </div>
            </div>
        );
    }

    if (quizCompleted) {
        const correctAnswers = Object.values(answeredQuestions).filter(Boolean).length;
        const percentage = Math.round((correctAnswers / QUIZ_QUESTIONS.length) * 100);
        
        return (
            <div className="max-w-4xl mx-auto">
                <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-8 border border-slate-700/50 text-center">
                    <div className="w-24 h-24 bg-gradient-to-r from-green-500 to-emerald-500 rounded-full flex items-center justify-center mx-auto mb-6">
                        <TrophyIcon className="w-12 h-12 text-white" />
                    </div>
                    
                    <h2 className="text-3xl font-bold text-white mb-6">🎉 Kuis Selesai!</h2>
                    
                    <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                        <div className="bg-slate-700/30 rounded-lg p-6">
                            <div className="text-3xl font-bold text-green-400">{correctAnswers}/{QUIZ_QUESTIONS.length}</div>
                            <div className="text-slate-300">Jawaban Benar</div>
                        </div>
                        <div className="bg-slate-700/30 rounded-lg p-6">
                            <div className="text-3xl font-bold text-blue-400">{percentage}%</div>
                            <div className="text-slate-300">Skor Akhir</div>
                        </div>
                        <div className="bg-slate-700/30 rounded-lg p-6">
                            <div className="text-3xl font-bold text-yellow-400">{score}</div>
                            <div className="text-slate-300">Total Poin</div>
                        </div>
                    </div>

                    <div className="mb-6">
                        {percentage >= 80 && (
                            <div className="bg-green-500/20 border border-green-400/30 rounded-lg p-4 mb-4">
                                <p className="text-green-300 font-medium">🌟 Luar biasa! Kamu sudah memahami hukum anti-korupsi dengan sangat baik!</p>
                            </div>
                        )}
                        {percentage >= 60 && percentage < 80 && (
                            <div className="bg-yellow-500/20 border border-yellow-400/30 rounded-lg p-4 mb-4">
                                <p className="text-yellow-300 font-medium">👍 Bagus! Terus belajar untuk meningkatkan pemahaman hukum.</p>
                            </div>
                        )}
                        {percentage < 60 && (
                            <div className="bg-red-500/20 border border-red-400/30 rounded-lg p-4 mb-4">
                                <p className="text-red-300 font-medium">💪 Jangan menyerah! Baca lebih banyak artikel dan coba lagi.</p>
                            </div>
                        )}
                    </div>

                    <div className="flex gap-4 justify-center">
                        <button 
                            onClick={resetQuiz}
                            className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-3 rounded-lg font-medium transition-all"
                        >
                            🔄 Ulangi Kuis
                        </button>
                        <button 
                            onClick={() => window.location.reload()}
                            className="bg-slate-600 hover:bg-slate-700 text-white px-6 py-3 rounded-lg font-medium transition-all"
                        >
                            📚 Kembali ke Pembelajaran
                        </button>
                    </div>
                </div>
            </div>
        );
    }

    return (
        <div className="max-w-4xl mx-auto">
            {/* Progress Bar */}
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50 mb-6">
                <div className="flex justify-between items-center mb-2">
                    <span className="text-slate-300 text-sm">Soal {currentQuestionIndex + 1} dari {QUIZ_QUESTIONS.length}</span>
                    <div className="flex items-center gap-2">
                        <FireIcon className="w-4 h-4 text-orange-400" />
                        <span className="text-white font-bold">{timeLeft}s</span>
                    </div>
                </div>
                <div className="bg-slate-700/50 rounded-full h-3">
                    <div 
                        className="bg-gradient-to-r from-blue-500 to-cyan-500 h-3 rounded-full transition-all duration-300"
                        style={{ width: `${((currentQuestionIndex + 1) / QUIZ_QUESTIONS.length) * 100}%` }}
                    ></div>
                </div>
            </div>

            {/* Question Card */}
            <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-8 border border-slate-700/50">
                <div className="mb-6">
                    <div className="flex items-center gap-2 mb-4">
                        <span className={`px-3 py-1 rounded-full text-xs font-medium ${
                            currentQuestion.difficulty === 'easy' ? 'bg-green-500/20 text-green-400' :
                            currentQuestion.difficulty === 'medium' ? 'bg-yellow-500/20 text-yellow-400' :
                            'bg-red-500/20 text-red-400'
                        }`}>
                            {currentQuestion.difficulty.toUpperCase()}
                        </span>
                        <span className="text-blue-400 text-sm">+{currentQuestion.points} poin</span>
                    </div>
                    <h3 className="text-xl font-bold text-white mb-4">{currentQuestion.question}</h3>
                </div>

                {/* Answer Options */}
                <div className="space-y-3 mb-6">
                    {currentQuestion.options.map((option, index) => (
                        <button
                            key={index}
                            onClick={() => handleAnswerSelect(index)}
                            disabled={showExplanation}
                            className={`w-full p-4 rounded-lg text-left transition-all border-2 ${
                                showExplanation
                                    ? index === currentQuestion.correctAnswer
                                        ? 'bg-green-500/20 border-green-400 text-green-300'
                                        : selectedAnswer === index
                                        ? 'bg-red-500/20 border-red-400 text-red-300'
                                        : 'bg-slate-700/30 border-slate-600 text-slate-300'
                                    : selectedAnswer === index
                                    ? 'bg-blue-500/20 border-blue-400 text-blue-300'
                                    : 'bg-slate-700/30 border-slate-600 text-slate-300 hover:bg-slate-600/40'
                            }`}
                        >
                            <span className="font-medium">
                                {String.fromCharCode(65 + index)}. {option}
                            </span>
                        </button>
                    ))}
                </div>

                {/* Explanation */}
                {showExplanation && (
                    <div className="bg-slate-700/30 rounded-lg p-4 mb-6">
                        <div className="flex items-start gap-2">
                            <LightBulbIcon className="w-5 h-5 text-yellow-400 mt-0.5" />
                            <div>
                                <h4 className="text-yellow-300 font-medium mb-2">Penjelasan:</h4>
                                <p className="text-slate-300">{currentQuestion.explanation}</p>
                            </div>
                        </div>
                    </div>
                )}

                {/* Action Buttons */}
                <div className="flex justify-between">
                    <button
                        onClick={handlePreviousQuestion}
                        disabled={currentQuestionIndex === 0}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-600 hover:bg-slate-700 disabled:bg-slate-800 disabled:text-slate-500 text-white rounded-lg font-medium transition-all"
                    >
                        <ArrowLeftIcon className="w-4 h-4" />
                        Sebelumnya
                    </button>

                    {!showExplanation ? (
                        <button
                            onClick={handleAnswerSubmit}
                            disabled={selectedAnswer === null}
                            className="px-6 py-2 bg-blue-600 hover:bg-blue-700 disabled:bg-slate-600 disabled:text-slate-400 text-white rounded-lg font-medium transition-all"
                        >
                            Jawab
                        </button>
                    ) : (
                        <button
                            onClick={handleNextQuestion}
                            className="flex items-center gap-2 px-6 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg font-medium transition-all"
                        >
                            {currentQuestionIndex === QUIZ_QUESTIONS.length - 1 ? 'Selesai' : 'Lanjut'}
                            <ArrowRightIcon className="w-4 h-4" />
                        </button>
                    )}
                </div>
            </div>
        </div>
    );
};

export default InteractiveQuiz;