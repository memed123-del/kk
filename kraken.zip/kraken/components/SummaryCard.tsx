import React from 'react';

interface SummaryCardProps {
    title: string;
    value: number;
    icon: React.ReactNode;
    color: string;
}

const SummaryCard: React.FC<SummaryCardProps> = ({ title, value, icon, color }) => {
    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
        }).format(amount);
    };

    return (
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-lg flex items-center justify-between transition-all duration-300 hover:border-cyan-400/50 hover:bg-gray-50 group">
            <div>
                <p className="text-sm font-medium text-gray-600">{title}</p>
                <p className="text-2xl font-bold text-gray-900">
                    {title.toLowerCase().includes('anomali') ? value : formatCurrency(value)}
                </p>
            </div>
            <div className={`p-3 rounded-full bg-gray-100 ${color} transition-colors duration-300 group-hover:bg-gray-200`}>
                {icon}
            </div>
        </div>
    );
};

export default SummaryCard;