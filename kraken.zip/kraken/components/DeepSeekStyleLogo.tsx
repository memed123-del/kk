import React from 'react';

interface DeepSeekStyleLogoProps {
  size?: number;
  className?: string;
}

const DeepSeekStyleLogo: React.FC<DeepSeekStyleLogoProps> = ({ size = 40, className = '' }) => {
  return (
    <svg
      width={size}
      height={size}
      viewBox="0 0 100 100"
      fill="none"
      xmlns="http://www.w3.org/2000/svg"
      className={className}
    >
      {/* Main whale body with gradient */}
      <defs>
        <linearGradient id="whaleGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{stopColor: '#0284c7', stopOpacity: 1}} />
          <stop offset="50%" style={{stopColor: '#0ea5e9', stopOpacity: 1}} />
          <stop offset="100%" style={{stopColor: '#38bdf8', stopOpacity: 1}} />
        </linearGradient>
        <linearGradient id="eyeGradient" x1="0%" y1="0%" x2="100%" y2="100%">
          <stop offset="0%" style={{stopColor: '#ffffff', stopOpacity: 1}} />
          <stop offset="100%" style={{stopColor: '#f1f5f9', stopOpacity: 1}} />
        </linearGradient>
      </defs>
      
      {/* Whale body - main rounded shape */}
      <ellipse cx="50" cy="45" rx="32" ry="20" fill="url(#whaleGradient)" />
      
      {/* Whale head - smaller rounded part */}
      <ellipse cx="70" cy="40" rx="18" ry="15" fill="url(#whaleGradient)" />
      
      {/* Tail fin */}
      <path
        d="M 20 45 Q 10 35 5 30 Q 8 40 15 50 Q 10 55 5 60 Q 10 65 20 55"
        fill="url(#whaleGradient)"
        opacity="0.9"
      />
      
      {/* Top fin */}
      <ellipse cx="45" cy="25" rx="8" ry="12" fill="url(#whaleGradient)" opacity="0.8" />
      
      {/* Bottom fin */}
      <ellipse cx="55" cy="62" rx="6" ry="10" fill="url(#whaleGradient)" opacity="0.8" />
      
      {/* Eye */}
      <circle cx="75" cy="37" r="6" fill="url(#eyeGradient)" />
      <circle cx="77" cy="35" r="3" fill="#1e293b" />
      <circle cx="78" cy="34" r="1" fill="white" />
      
      {/* Smile */}
      <path
        d="M 70 48 Q 75 52 80 48"
        stroke="white"
        strokeWidth="2"
        fill="none"
        strokeLinecap="round"
        opacity="0.8"
      />
      
      {/* Water bubbles effect */}
      <circle cx="25" cy="20" r="2" fill="#38bdf8" opacity="0.6">
        <animate attributeName="opacity" values="0.6;1;0.6" dur="2s" repeatCount="indefinite" />
      </circle>
      <circle cx="30" cy="15" r="1.5" fill="#0ea5e9" opacity="0.5">
        <animate attributeName="opacity" values="0.5;0.9;0.5" dur="1.5s" repeatCount="indefinite" />
      </circle>
      <circle cx="35" cy="12" r="1" fill="#0284c7" opacity="0.4">
        <animate attributeName="opacity" values="0.4;0.8;0.4" dur="1.8s" repeatCount="indefinite" />
      </circle>
    </svg>
  );
};

export default DeepSeekStyleLogo;