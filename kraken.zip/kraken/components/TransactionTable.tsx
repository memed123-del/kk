import React from 'react';
import { Transaction, Anomaly } from '../types';
import { ExclamationTriangleIcon } from './Icons';

interface TransactionTableProps {
    transactions: Transaction[];
    anomalies: Anomaly[];
}

const TransactionTable: React.FC<TransactionTableProps> = ({ transactions, anomalies }) => {

    const formatCurrency = (amount: number) => {
        return new Intl.NumberFormat('id-ID', {
            style: 'currency',
            currency: 'IDR',
            minimumFractionDigits: 0,
        }).format(amount);
    };

    const formatDate = (dateString: string) => {
        const options: Intl.DateTimeFormatOptions = { year: 'numeric', month: 'long', day: 'numeric' };
        return new Date(dateString).toLocaleDateString('id-ID', options);
    };

    const anomalyIds = new Set(anomalies.map(a => a.transactionId));
    
    if (transactions.length === 0) {
        return (
            <div className="text-center py-16 px-6 bg-slate-800/20 rounded-lg">
                <h3 className="text-lg font-semibold text-gray-300">Tidak Ada Transaksi untuk Ditampilkan</h3>
                <p className="text-sm text-gray-500 mt-2">Coba ubah kata kunci pencarian Anda atau tambahkan transaksi baru.</p>
            </div>
        );
    }


    return (
        <div className="overflow-x-auto">
            <table className="w-full text-sm text-left text-gray-400">
                <thead className="text-xs text-gray-400 uppercase bg-slate-700/50">
                    <tr>
                        <th scope="col" className="px-6 py-3">Tanggal</th>
                        <th scope="col" className="px-6 py-3">Deskripsi</th>
                        <th scope="col" className="px-6 py-3">Kategori</th>
                        <th scope="col" className="px-6 py-3 text-right">Jumlah</th>
                    </tr>
                </thead>
                <tbody>
                    {transactions.map(transaction => {
                        const isAnomaly = anomalyIds.has(transaction.id);
                        return (
                            <tr key={transaction.id} className={`border-b border-slate-700 ${isAnomaly ? 'bg-yellow-500/10' : 'hover:bg-slate-700/30'}`}>
                                <td className="px-6 py-4 font-medium text-white whitespace-nowrap">{formatDate(transaction.date)}</td>
                                <td className="px-6 py-4">
                                    <div className="flex items-center gap-2">
                                        {isAnomaly && <ExclamationTriangleIcon className="text-yellow-400 flex-shrink-0" />}
                                        <span className={isAnomaly ? 'text-yellow-300' : 'text-gray-300'}>{transaction.description}</span>
                                    </div>
                                </td>
                                <td className="px-6 py-4">{transaction.category}</td>
                                <td className={`px-6 py-4 text-right font-semibold ${transaction.type === 'income' ? 'text-green-400' : 'text-red-400'}`}>
                                    {transaction.type === 'income' ? '+' : '-'} {formatCurrency(transaction.amount)}
                                </td>
                            </tr>
                        );
                    })}
                </tbody>
            </table>
        </div>
    );
};

export default TransactionTable;