import React, { useState, useEffect } from 'react';
import {
  LineChart, Line, AreaChart, Area, BarChart, Bar,
  XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  PieChart, Pie, Cell, ScatterChart, Scatter
} from 'recharts';
import { TrendingUp, TrendingDown, BarChart3, PieChart as PieChartIcon, Activity } from 'lucide-react';
import { FinancialData, Transaction, Anomaly } from '../types';

interface FinancialTradingChartProps {
  transactions: Transaction[];
  anomalies: Anomaly[];
  title?: string;
}

const FinancialTradingChart: React.FC<FinancialTradingChartProps> = ({ 
  transactions, 
  anomalies,
  title = "Analisis Arus Keuangan" 
}) => {
  const [activeChart, setActiveChart] = useState<'line' | 'area' | 'bar' | 'pie' | 'scatter'>('line');
  const [timeRange, setTimeRange] = useState<'7d' | '30d' | '90d' | 'all'>('30d');
  const [selectedMetric, setSelectedMetric] = useState<'flow' | 'risk' | 'volume' | 'balance'>('flow');

  // Convert transactions to FinancialData format
  const convertToFinancialData = (): FinancialData[] => {
    if (!transactions.length) return [];

    // Group transactions by date
    const groupedByDate: Record<string, FinancialData> = {};
    
    transactions.forEach(transaction => {
      const date = transaction.date.split('T')[0]; // Get date part only
      if (!groupedByDate[date]) {
        groupedByDate[date] = {
          date,
          inflow: 0,
          outflow: 0,
          balance: 0,
          volume: 0,
          suspiciousActivity: 0,
          riskScore: 0,
          anomalyCount: 0
        };
      }

      // Calculate inflow/outflow
      if (transaction.type === 'income') {
        groupedByDate[date].inflow += transaction.amount;
      } else {
        groupedByDate[date].outflow += transaction.amount;
      }

      groupedByDate[date].volume += transaction.amount;
    });

    // Convert to array and sort by date
    const financialData = Object.values(groupedByDate).sort((a, b) => 
      new Date(a.date).getTime() - new Date(b.date).getTime()
    );

    // Calculate running balance and anomaly data
    let runningBalance = 0;
    return financialData.map((item) => {
      runningBalance += (item.inflow - item.outflow);
      
      // Count anomalies for this date
      const dayAnomalies = anomalies.filter(anomaly => {
        const anomalyDate = transactions.find(t => t.id === anomaly.transactionId)?.date.split('T')[0];
        return anomalyDate === item.date;
      });

      return {
        ...item,
        outflowNegative: -item.outflow, // Negative untuk visualisasi yang jelas
        balance: runningBalance,
        anomalyCount: dayAnomalies.length,
        suspiciousActivity: dayAnomalies.filter(a => a.severity === 'Tinggi').length,
        riskScore: dayAnomalies.length > 0 ? (dayAnomalies.filter(a => a.severity === 'Tinggi').length / dayAnomalies.length) * 100 : 0
      };
    });
  };

  const data = convertToFinancialData();

  // Filter data based on time range
  const getFilteredData = () => {
    if (!data || data.length === 0) return [];
    
    const now = new Date();
    const cutoffDate = new Date();
    
    switch (timeRange) {
      case '7d':
        cutoffDate.setDate(now.getDate() - 7);
        break;
      case '30d':
        cutoffDate.setDate(now.getDate() - 30);
        break;
      case '90d':
        cutoffDate.setDate(now.getDate() - 90);
        break;
      default:
        return data;
    }
    
    return data.filter(item => new Date(item.date) >= cutoffDate);
  };

  const filteredData = getFilteredData();

  // Calculate metrics
  const totalInflow = filteredData.reduce((sum, item) => sum + item.inflow, 0);
  const totalOutflow = filteredData.reduce((sum, item) => sum + item.outflow, 0);
  const netFlow = totalInflow - totalOutflow;
  const avgRiskScore = filteredData.reduce((sum, item) => sum + item.riskScore, 0) / filteredData.length || 0;
  const totalAnomalies = filteredData.reduce((sum, item) => sum + item.anomalyCount, 0);

  // Prepare pie chart data
  const pieData = [
    { name: 'Transaksi Bersih', value: totalInflow - (totalInflow * avgRiskScore / 100), fill: '#10B981' },
    { name: 'Pemasukan Mencurigakan', value: totalInflow * avgRiskScore / 100, fill: '#EF4444' },
    { name: 'Pengeluaran Normal', value: totalOutflow - (totalOutflow * avgRiskScore / 100), fill: '#3B82F6' },
    { name: 'Pengeluaran Berisiko', value: totalOutflow * avgRiskScore / 100, fill: '#F59E0B' }
  ];

  // Risk distribution data
  const riskDistribution = filteredData.map(item => ({
    date: item.date,
    lowRisk: item.volume * (100 - item.riskScore) / 100,
    mediumRisk: item.volume * Math.min(item.riskScore, 50) / 100,
    highRisk: item.volume * Math.max(0, item.riskScore - 50) / 100,
    riskScore: item.riskScore
  }));

  const formatCurrency = (value: number) => {
    return new Intl.NumberFormat('id-ID', {
      style: 'currency',
      currency: 'IDR',
      minimumFractionDigits: 0,
      maximumFractionDigits: 0
    }).format(value);
  };

  const formatCompactCurrency = (value: number) => {
    if (value >= 1e9) return `Rp${(value / 1e9).toFixed(1)}B`;
    if (value >= 1e6) return `Rp${(value / 1e6).toFixed(1)}M`;
    if (value >= 1e3) return `Rp${(value / 1e3).toFixed(1)}K`;
    return `Rp${value}`;
  };

  const CustomTooltip = ({ active, payload, label }: any) => {
    if (active && payload && payload.length) {
      return (
        <div className="bg-slate-800 border border-slate-600 rounded-lg p-3 shadow-lg">
          <p className="text-gray-300 text-sm mb-2">{`Tanggal: ${label}`}</p>
          {payload.map((entry: any, index: number) => (
            <p key={index} className="text-sm" style={{ color: entry.color }}>
              {`${entry.dataKey}: ${formatCompactCurrency(entry.value)}`}
            </p>
          ))}
        </div>
      );
    }
    return null;
  };

  const renderChart = () => {
    switch (activeChart) {
      case 'area':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <AreaChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} tickFormatter={formatCompactCurrency} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Area
                type="monotone"
                dataKey="inflow"
                stackId="1"
                stroke="#10B981"
                fill="#10B981"
                fillOpacity={0.6}
                name="Pemasukan"
              />
              <Area
                type="monotone"
                dataKey="outflowNegative"
                stackId="2"
                stroke="#EF4444"
                fill="#EF4444"
                fillOpacity={0.6}
                name="Pengeluaran"
              />
            </AreaChart>
          </ResponsiveContainer>
        );

      case 'bar':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <BarChart data={riskDistribution}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} tickFormatter={formatCompactCurrency} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Bar dataKey="lowRisk" stackId="a" fill="#10B981" name="Risiko Rendah" />
              <Bar dataKey="mediumRisk" stackId="a" fill="#F59E0B" name="Risiko Sedang" />
              <Bar dataKey="highRisk" stackId="a" fill="#EF4444" name="Risiko Tinggi" />
            </BarChart>
          </ResponsiveContainer>
        );

      case 'pie':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <PieChart>
              <Pie
                data={pieData}
                cx="50%"
                cy="50%"
                outerRadius={120}
                fill="#8884d8"
                dataKey="value"
                label={({ name, percent }) => `${name} ${(percent * 100).toFixed(1)}%`}
              >
                {pieData.map((entry, index) => (
                  <Cell key={`cell-${index}`} fill={entry.fill} />
                ))}
              </Pie>
              <Tooltip formatter={(value) => formatCompactCurrency(Number(value))} />
            </PieChart>
          </ResponsiveContainer>
        );

      case 'scatter':
        return (
          <ResponsiveContainer width="100%" height={400}>
            <ScatterChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="volume" stroke="#9CA3AF" fontSize={12} name="Volume" />
              <YAxis dataKey="riskScore" stroke="#9CA3AF" fontSize={12} name="Risk Score" />
              <Tooltip 
                formatter={(value, name) => [
                  name === 'riskScore' ? `${value}/100` : formatCompactCurrency(Number(value)),
                  name === 'riskScore' ? 'Skor Risiko' : 'Volume'
                ]}
              />
              <Scatter name="Risiko vs Volume" data={filteredData} fill="#8884d8" />
            </ScatterChart>
          </ResponsiveContainer>
        );

      default: // line chart
        return (
          <ResponsiveContainer width="100%" height={400}>
            <LineChart data={filteredData}>
              <CartesianGrid strokeDasharray="3 3" stroke="#374151" />
              <XAxis dataKey="date" stroke="#9CA3AF" fontSize={12} />
              <YAxis stroke="#9CA3AF" fontSize={12} tickFormatter={formatCompactCurrency} />
              <Tooltip content={<CustomTooltip />} />
              <Legend />
              <Line
                type="monotone"
                dataKey="inflow"
                stroke="#10B981"
                strokeWidth={2}
                dot={{ fill: '#10B981', strokeWidth: 2, r: 4 }}
                name="Pemasukan"
              />
              <Line
                type="monotone"
                dataKey="outflowNegative"
                stroke="#EF4444"
                strokeWidth={2}
                dot={{ fill: '#EF4444', strokeWidth: 2, r: 4 }}
                name="Pengeluaran"
              />
              <Line
                type="monotone"
                dataKey="balance"
                stroke="#3B82F6"
                strokeWidth={2}
                dot={{ fill: '#3B82F6', strokeWidth: 2, r: 4 }}
                name="Saldo"
              />
            </LineChart>
          </ResponsiveContainer>
        );
    }
  };

  return (
    <div className="bg-slate-800/40 border border-slate-700 rounded-xl p-6">
      {/* Header */}
      <div className="flex flex-col lg:flex-row justify-between items-start lg:items-center mb-6 space-y-4 lg:space-y-0">
        <h3 className="text-xl font-bold text-white flex items-center">
          <Activity className="w-6 h-6 mr-2 text-cyan-400" />
          {title}
        </h3>
        
        {/* Controls */}
        <div className="flex flex-wrap gap-2">
          {/* Chart Type */}
          <div className="flex bg-slate-700 rounded-lg p-1">
            {[
              { type: 'line', icon: TrendingUp, label: 'Line' },
              { type: 'area', icon: BarChart3, label: 'Area' },
              { type: 'bar', icon: BarChart3, label: 'Bar' },
              { type: 'pie', icon: PieChartIcon, label: 'Pie' },
              { type: 'scatter', icon: Activity, label: 'Scatter' }
            ].map(({ type, icon: Icon, label }) => (
              <button
                key={type}
                onClick={() => setActiveChart(type as any)}
                className={`px-3 py-2 rounded text-xs font-medium transition-colors ${
                  activeChart === type
                    ? 'bg-cyan-600 text-white'
                    : 'text-gray-300 hover:text-white hover:bg-slate-600'
                }`}
              >
                <Icon className="w-4 h-4" />
              </button>
            ))}
          </div>

          {/* Time Range */}
          <div className="flex bg-slate-700 rounded-lg p-1">
            {['7d', '30d', '90d', 'all'].map((range) => (
              <button
                key={range}
                onClick={() => setTimeRange(range as any)}
                className={`px-3 py-2 rounded text-xs font-medium transition-colors ${
                  timeRange === range
                    ? 'bg-cyan-600 text-white'
                    : 'text-gray-300 hover:text-white hover:bg-slate-600'
                }`}
              >
                {range === 'all' ? 'Semua Waktu' : range.toUpperCase()}
              </button>
            ))}
          </div>
        </div>
      </div>

      {/* Key Metrics */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-6">
        <div className="bg-gradient-to-r from-green-900/50 to-green-800/50 border border-green-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-green-300 text-sm font-medium">Total Pemasukan</p>
              <p className="text-white text-lg font-bold">{formatCompactCurrency(totalInflow)}</p>
            </div>
            <TrendingUp className="w-8 h-8 text-green-400" />
          </div>
        </div>

        <div className="bg-gradient-to-r from-red-900/50 to-red-800/50 border border-red-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-red-300 text-sm font-medium">Total Pengeluaran</p>
              <p className="text-white text-lg font-bold">{formatCompactCurrency(totalOutflow)}</p>
            </div>
            <TrendingDown className="w-8 h-8 text-red-400" />
          </div>
        </div>

        <div className={`bg-gradient-to-r ${netFlow >= 0 ? 'from-blue-900/50 to-blue-800/50 border-blue-700' : 'from-orange-900/50 to-orange-800/50 border-orange-700'} border rounded-lg p-4`}>
          <div className="flex items-center justify-between">
            <div>
              <p className={`${netFlow >= 0 ? 'text-blue-300' : 'text-orange-300'} text-sm font-medium`}>Arus Bersih</p>
              <p className="text-white text-lg font-bold">{formatCompactCurrency(netFlow)}</p>
            </div>
            <Activity className={`w-8 h-8 ${netFlow >= 0 ? 'text-blue-400' : 'text-orange-400'}`} />
          </div>
        </div>

        <div className="bg-gradient-to-r from-yellow-900/50 to-yellow-800/50 border border-yellow-700 rounded-lg p-4">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-yellow-300 text-sm font-medium">Skor Risiko Rata-rata</p>
              <p className="text-white text-lg font-bold">{avgRiskScore.toFixed(1)}/100</p>
            </div>
            <BarChart3 className="w-8 h-8 text-yellow-400" />
          </div>
        </div>
      </div>

      {/* Chart */}
      <div className="bg-slate-900/50 rounded-lg p-4">
        {renderChart()}
      </div>

      {/* Additional Insights */}
      <div className="mt-6 grid grid-cols-1 lg:grid-cols-3 gap-4">
        <div className="bg-slate-700/50 rounded-lg p-4">
          <h4 className="text-white font-semibold mb-2">🚨 Analisis Risiko</h4>
          <p className="text-sm text-gray-300">
            Total anomali terdeteksi: <span className="text-red-400 font-bold">{totalAnomalies}</span>
          </p>
          <p className="text-sm text-gray-300">
            Tingkat risiko rata-rata: <span className={`font-bold ${avgRiskScore > 70 ? 'text-red-400' : avgRiskScore > 40 ? 'text-yellow-400' : 'text-green-400'}`}>
              {avgRiskScore > 70 ? 'Tinggi' : avgRiskScore > 40 ? 'Sedang' : 'Rendah'}
            </span>
          </p>
        </div>

        <div className="bg-slate-700/50 rounded-lg p-4">
          <h4 className="text-white font-semibold mb-2">📊 Rasio Arus</h4>
          <p className="text-sm text-gray-300">
            Rasio Pemasukan/Pengeluaran: <span className="text-cyan-400 font-bold">
              {totalOutflow > 0 ? (totalInflow / totalOutflow).toFixed(2) : '∞'}
            </span>
          </p>
          <p className="text-sm text-gray-300">
            Efisiensi arus: <span className={`font-bold ${netFlow >= 0 ? 'text-green-400' : 'text-red-400'}`}>
              {netFlow >= 0 ? 'Positif' : 'Negatif'}
            </span>
          </p>
        </div>

        <div className="bg-slate-700/50 rounded-lg p-4">
          <h4 className="text-white font-semibold mb-2">🎯 Rekomendasi</h4>
          <p className="text-xs text-gray-300">
            {avgRiskScore > 70 
              ? '🔴 Diperlukan peninjauan segera untuk transaksi berisiko tinggi'
              : avgRiskScore > 40 
              ? '🟡 Pantau transaksi dengan cermat untuk pola yang mencurigakan'
              : '🟢 Arus keuangan terlihat normal'}
          </p>
        </div>
      </div>
    </div>
  );
};

export default FinancialTradingChart;
