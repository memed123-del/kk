import React, { useState, useEffect } from 'react';
import { LegalArticle, LearningProgress, QuizQuestion } from '../types';
import { BookOpenIcon, AcademicCapIcon, TrophyIcon, FireIcon, CheckCircleIcon, PlayCircleIcon, DocumentTextIcon, ScaleIcon, UserGroupIcon, ClockIcon } from './Icons';
import InteractiveQuiz from './InteractiveQuiz';

interface LegalEducationCenterProps {
    // Props dapat ditambahkan sesuai kebutuhan
}

// Data contoh UUD 1945 dan undang-undang terkait anti-korupsi
const LEGAL_ARTICLES: LegalArticle[] = [
    {
        id: 'uud-28d',
        chapter: 'BAB XA - HAK ASASI MANUSIA',
        article: 'Pasal 28D ayat (1)',
        title: 'Hak atas Pengakuan, Jaminan, Perlindungan, dan Kepastian Hukum',
        content: 'Setiap orang berhak atas pengakuan, jaminan, perlindungan, dan kepastian hukum yang adil serta perlakuan yang sama di hadapan hukum.',
        explanation: 'Pasal ini menjamin bahwa setiap warga negara memiliki hak untuk mendapatkan keadilan hukum tanpa diskriminasi. Dalam konteks anti-korupsi, pasal ini memastikan bahwa setiap orang berhak untuk melaporkan tindak korupsi dan mendapatkan perlindungan hukum.',
        category: 'civil-rights',
        importance: 'critical',
        relatedCases: ['Kasus whistleblower korupsi e-KTP', 'Perlindungan saksi kasus korupsi Hambalang'],
        penalties: 'Pelanggaran dapat berupa diskriminasi dalam proses hukum',
        examples: [
            'Melaporkan dugaan korupsi tanpa takut diskriminasi',
            'Mendapatkan perlindungan hukum saat menjadi saksi',
            'Proses peradilan yang transparan dan adil'
        ]
    },
    {
        id: 'uud-23',
        chapter: 'BAB X - WARGA NEGARA DAN PENDUDUK',
        article: 'Pasal 23 ayat (1)',
        title: 'Anggaran Pendapatan dan Belanja Negara',
        content: 'Anggaran pendapatan dan belanja negara sebagai wujud dari pengelolaan keuangan negara ditetapkan setiap tahun dengan undang-undang dan dilaksanakan secara terbuka dan bertanggung jawab untuk sebesar-besarnya kemakmuran rakyat.',
        explanation: 'Pasal ini mengatur prinsip transparansi dan akuntabilitas dalam pengelolaan keuangan negara. Setiap rupiah uang negara harus dikelola secara terbuka dan dapat dipertanggungjawabkan kepada rakyat.',
        category: 'financial',
        importance: 'critical',
        relatedCases: ['Kasus korupsi anggaran daerah', 'Pengadaan barang dan jasa fiktif'],
        penalties: 'Penyalahgunaan anggaran negara dapat dipidana sesuai UU Tipikor',
        examples: [
            'Laporan penggunaan APBN harus transparan',
            'Audit anggaran secara berkala',
            'Partisipasi publik dalam pengawasan anggaran'
        ]
    },
    {
        id: 'uu-20-2001',
        chapter: 'UU No. 20 Tahun 2001',
        article: 'Pasal 2',
        title: 'Tindak Pidana Korupsi',
        content: 'Setiap orang yang secara melawan hukum melakukan perbuatan memperkaya diri sendiri atau orang lain atau suatu korporasi yang dapat merugikan keuangan negara atau perekonomian negara.',
        explanation: 'Ini adalah definisi dasar tindak pidana korupsi yang sangat penting dipahami. Korupsi tidak hanya soal mengambil uang, tetapi semua perbuatan yang merugikan keuangan negara.',
        category: 'anti-corruption',
        importance: 'critical',
        penalties: 'Pidana penjara seumur hidup atau pidana penjara paling singkat 4 tahun dan paling lama 20 tahun',
        examples: [
            'Markup harga dalam tender pemerintah',
            'Menggunakan anggaran negara untuk kepentingan pribadi',
            'Menerima gratifikasi yang mempengaruhi kebijakan'
        ]
    },
    {
        id: 'uu-8-2010',
        chapter: 'UU No. 8 Tahun 2010',
        article: 'Pasal 12B',
        title: 'Gratifikasi',
        content: 'Setiap gratifikasi kepada pegawai negeri atau penyelenggara negara dianggap pemberian suap, apabila berhubungan dengan jabatannya dan yang berlawanan dengan kewajiban atau tugasnya.',
        explanation: 'Gratifikasi adalah pemberian dalam arti luas. Gen Z harus paham bahwa menerima hadiah, voucher, atau fasilitas dari pihak yang ada kepentingan dengan jabatan adalah tindak pidana korupsi.',
        category: 'anti-corruption',
        importance: 'high',
        penalties: 'Pidana penjara seumur hidup atau pidana penjara paling singkat 1 tahun dan paling lama 20 tahun',
        examples: [
            'Menerima tiket liburan dari vendor',
            'Hadiah gadget dari perusahaan rekanan',
            'Voucher belanja atau cash dari pengusaha'
        ]
    },
    {
        id: 'uu-14-2008',
        chapter: 'UU No. 14 Tahun 2008',
        article: 'Pasal 5',
        title: 'Keterbukaan Informasi Publik',
        content: 'Badan publik wajib menyediakan, memberikan dan/atau menerbitkan informasi publik yang berada di bawah kewenangannya kepada pemohon informasi publik.',
        explanation: 'Hak akses informasi adalah senjata ampuh untuk mencegah korupsi. Gen Z bisa menggunakan hak ini untuk mengawasi pemerintah dan meminta transparansi.',
        category: 'governance',
        importance: 'high',
        penalties: 'Sanksi administratif bagi pejabat yang tidak memberikan informasi publik',
        examples: [
            'Meminta data anggaran pembangunan sekolah',
            'Mengakses laporan keuangan BUMN',
            'Informasi tender pengadaan barang'
        ]
    },
    {
        id: 'ethics-social-media',
        chapter: 'Etika Digital & Media Sosial',
        article: 'Prinsip Dasar',
        title: 'Bermedia Sosial yang Bertanggung Jawab untuk Anti-Korupsi',
        content: 'Gunakan media sosial untuk menyebarkan informasi yang benar tentang anti-korupsi, laporkan dugaan korupsi melalui kanal yang tepat, dan hindari penyebaran hoaks terkait kasus korupsi.',
        explanation: 'Gen Z sebagai digital native memiliki kekuatan besar di media sosial. Dengan menggunakan platform digital secara bijak, kalian bisa menjadi agen perubahan dalam gerakan anti-korupsi.',
        category: 'ethics',
        importance: 'medium',
        examples: [
            'Share konten edukatif anti-korupsi',
            'Laporkan dugaan korupsi ke KPK melalui media resmi',
            'Fact-check berita korupsi sebelum share',
            'Buat konten kreatif untuk kampanye anti-korupsi'
        ]
    }
];

const QUIZ_QUESTIONS: QuizQuestion[] = [
    {
        id: 'quiz-1',
        articleId: 'uud-28d',
        question: 'Apa yang dijamin oleh Pasal 28D ayat (1) UUD 1945 dalam konteks anti-korupsi?',
        options: [
            'Hak untuk melakukan korupsi',
            'Hak untuk mendapatkan perlindungan hukum saat melaporkan korupsi',
            'Hak untuk menyembunyikan kasus korupsi',
            'Hak untuk tidak diadili jika terbukti korup'
        ],
        correctAnswer: 1,
        explanation: 'Pasal 28D ayat (1) menjamin hak atas perlindungan hukum yang adil, termasuk bagi whistleblower yang melaporkan korupsi.',
        difficulty: 'easy'
    },
    {
        id: 'quiz-2',
        articleId: 'uu-20-2001',
        question: 'Menurut UU No. 20 Tahun 2001, apa yang dimaksud dengan tindak pidana korupsi?',
        options: [
            'Hanya mengambil uang kas negara',
            'Perbuatan yang memperkaya diri sendiri dan merugikan keuangan negara',
            'Hanya menerima suap',
            'Hanya nepotisme dalam jabatan'
        ],
        correctAnswer: 1,
        explanation: 'Korupsi adalah perbuatan melawan hukum yang memperkaya diri sendiri atau orang lain yang merugikan keuangan negara.',
        difficulty: 'medium'
    }
];

const LegalEducationCenter: React.FC<LegalEducationCenterProps> = () => {
    const [activeTab, setActiveTab] = useState<'learning' | 'quiz' | 'progress'>('learning');
    const [selectedArticle, setSelectedArticle] = useState<LegalArticle | null>(null);
    const [currentQuiz, setCurrentQuiz] = useState<QuizQuestion | null>(null);
    const [selectedCategory, setSelectedCategory] = useState<string>('all');
    const [searchTerm, setSearchTerm] = useState('');
    const [userProgress, setUserProgress] = useState<LearningProgress>({
        articlesRead: ['uud-28d'],
        quizzesCompleted: [],
        totalPoints: 20,
        currentLevel: 'beginner',
        badges: ['Pemula Anti-Korupsi'],
        weeklyGoal: 5,
        weeklyProgress: 1,
        streak: 1,
        lastActivityDate: new Date()
    });

    const handleProgressUpdate = (newProgress: LearningProgress) => {
        setUserProgress(newProgress);
        // In real app, this would save to backend
        console.log('Progress updated:', newProgress);
    };

    const filteredArticles = LEGAL_ARTICLES.filter(article => {
        const matchesCategory = selectedCategory === 'all' || article.category === selectedCategory;
        const matchesSearch = article.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            article.content.toLowerCase().includes(searchTerm.toLowerCase()) ||
                            article.chapter.toLowerCase().includes(searchTerm.toLowerCase());
        return matchesCategory && matchesSearch;
    });

    const markArticleAsRead = (articleId: string) => {
        if (!userProgress.articlesRead.includes(articleId)) {
            setUserProgress(prev => ({
                ...prev,
                articlesRead: [...prev.articlesRead, articleId],
                totalPoints: prev.totalPoints + 10,
                weeklyProgress: prev.weeklyProgress + 1
            }));
        }
    };

    const getCategoryIcon = (category: string) => {
        switch (category) {
            case 'anti-corruption': return <ScaleIcon className="w-5 h-5" />;
            case 'financial': return <DocumentTextIcon className="w-5 h-5" />;
            case 'governance': return <UserGroupIcon className="w-5 h-5" />;
            case 'ethics': return <FireIcon className="w-5 h-5" />;
            case 'civil-rights': return <CheckCircleIcon className="w-5 h-5" />;
            default: return <BookOpenIcon className="w-5 h-5" />;
        }
    };

    const getImportanceColor = (importance: string) => {
        switch (importance) {
            case 'critical': return 'text-red-400 border-red-400/30 bg-red-400/10';
            case 'high': return 'text-orange-400 border-orange-400/30 bg-orange-400/10';
            case 'medium': return 'text-yellow-400 border-yellow-400/30 bg-yellow-400/10';
            case 'low': return 'text-green-400 border-green-400/30 bg-green-400/10';
            default: return 'text-slate-400 border-slate-400/30 bg-slate-400/10';
        }
    };

    return (
        <div className="min-h-screen bg-gradient-to-br from-slate-900 via-slate-800 to-slate-900 text-white p-6">
            <div className="max-w-7xl mx-auto">
                {/* Header */}
                <div className="text-center mb-8">
                    <div className="flex items-center justify-center gap-4 mb-4">
                        <AcademicCapIcon className="w-12 h-12 text-blue-400" />
                        <h1 className="text-4xl font-bold bg-gradient-to-r from-blue-400 to-cyan-400 bg-clip-text text-transparent drop-shadow-lg">
                            Pusat Edukasi Hukum
                        </h1>
                    </div>
                    <p className="text-slate-100 text-lg max-w-3xl mx-auto font-medium drop-shadow-sm">
                        Tingkatkan literasi hukum Gen Z! Pelajari UUD 1945, undang-undang anti-korupsi, 
                        dan jadilah agen perubahan untuk Indonesia yang lebih bersih dan berintegritas.
                    </p>
                </div>

                {/* Stats Cards */}
                <div className="grid grid-cols-1 md:grid-cols-4 gap-4 mb-8">
                    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50">
                        <div className="flex items-center gap-3">
                            <BookOpenIcon className="w-8 h-8 text-cyan-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{userProgress.articlesRead.length}</p>
                                <p className="text-slate-400 text-sm">Artikel Dibaca</p>
                            </div>
                        </div>
                    </div>
                    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50">
                        <div className="flex items-center gap-3">
                            <TrophyIcon className="w-8 h-8 text-yellow-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{userProgress.totalPoints}</p>
                                <p className="text-slate-400 text-sm">Total Poin</p>
                            </div>
                        </div>
                    </div>
                    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50">
                        <div className="flex items-center gap-3">
                            <FireIcon className="w-8 h-8 text-orange-400" />
                            <div>
                                <p className="text-2xl font-bold text-white">{userProgress.weeklyProgress}/{userProgress.weeklyGoal}</p>
                                <p className="text-slate-400 text-sm">Target Mingguan</p>
                            </div>
                        </div>
                    </div>
                    <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50">
                        <div className="flex items-center gap-3">
                            <ClockIcon className="w-8 h-8 text-blue-400" />
                            <div>
                                <p className="text-sm font-semibold text-white capitalize">{userProgress.currentLevel}</p>
                                <p className="text-slate-400 text-sm">Level Saat Ini</p>
                            </div>
                        </div>
                    </div>
                </div>

                {/* Navigation Tabs */}
                <div className="flex gap-2 mb-6 bg-slate-800/30 p-2 rounded-xl">
                    <button
                        onClick={() => setActiveTab('learning')}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                            activeTab === 'learning'
                                ? 'bg-cyan-600 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                        }`}
                    >
                        <BookOpenIcon className="w-5 h-5" />
                        Belajar Pasal
                    </button>
                    <button
                        onClick={() => setActiveTab('quiz')}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                            activeTab === 'quiz'
                                ? 'bg-cyan-600 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                        }`}
                    >
                        <PlayCircleIcon className="w-5 h-5" />
                        Kuis Interaktif
                    </button>
                    <button
                        onClick={() => setActiveTab('progress')}
                        className={`flex items-center gap-2 px-4 py-2 rounded-lg transition-all ${
                            activeTab === 'progress'
                                ? 'bg-cyan-600 text-white'
                                : 'text-slate-400 hover:text-white hover:bg-slate-700/50'
                        }`}
                    >
                        <TrophyIcon className="w-5 h-5" />
                        Progress
                    </button>
                </div>

                {/* Content */}
                {activeTab === 'learning' && (
                    <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
                        {/* Sidebar Filters */}
                        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50 h-fit">
                            <h3 className="text-lg font-semibold mb-4">Filter & Cari</h3>
                            
                            {/* Search */}
                            <div className="mb-4">
                                <input
                                    type="text"
                                    placeholder="Cari pasal atau topik..."
                                    value={searchTerm}
                                    onChange={(e) => setSearchTerm(e.target.value)}
                                    className="w-full px-3 py-2 bg-slate-700/50 border border-slate-600 rounded-lg text-white placeholder-slate-400 focus:border-cyan-400 focus:outline-none"
                                />
                            </div>

                            {/* Category Filter */}
                            <div>
                                <p className="text-sm font-medium text-slate-300 mb-2">Kategori</p>
                                <div className="space-y-2">
                                    {[
                                        { id: 'all', label: 'Semua Kategori', icon: '📚' },
                                        { id: 'anti-corruption', label: 'Anti-Korupsi', icon: '⚖️' },
                                        { id: 'financial', label: 'Keuangan Negara', icon: '💰' },
                                        { id: 'governance', label: 'Tata Kelola', icon: '🏛️' },
                                        { id: 'ethics', label: 'Etika Digital', icon: '🔥' },
                                        { id: 'civil-rights', label: 'Hak Sipil', icon: '✅' }
                                    ].map(category => (
                                        <button
                                            key={category.id}
                                            onClick={() => setSelectedCategory(category.id)}
                                            className={`w-full text-left flex items-center gap-2 px-3 py-2 rounded-lg transition-all ${
                                                selectedCategory === category.id
                                                    ? 'bg-cyan-600/20 border border-cyan-400/30 text-cyan-300'
                                                    : 'hover:bg-slate-700/50 text-slate-300'
                                            }`}
                                        >
                                            <span>{category.icon}</span>
                                            <span className="text-sm">{category.label}</span>
                                        </button>
                                    ))}
                                </div>
                            </div>
                        </div>

                        {/* Articles List or Detail */}
                        <div className="lg:col-span-2">
                            {selectedArticle ? (
                                /* Article Detail */
                                <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
                                    <button
                                        onClick={() => setSelectedArticle(null)}
                                        className="mb-4 text-cyan-400 hover:text-cyan-300 flex items-center gap-2"
                                    >
                                        ← Kembali ke Daftar
                                    </button>
                                    
                                    <div className="mb-4">
                                        <div className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-xs font-medium border ${getImportanceColor(selectedArticle.importance)}`}>
                                            {getCategoryIcon(selectedArticle.category)}
                                            {selectedArticle.importance.toUpperCase()}
                                        </div>
                                    </div>
                                    
                                    <div className="mb-4">
                                        <h2 className="text-2xl font-bold text-white mb-2">{selectedArticle.title}</h2>
                                        <p className="text-cyan-400 font-medium">{selectedArticle.chapter} - {selectedArticle.article}</p>
                                    </div>

                                    <div className="space-y-6">
                                        <div>
                                            <h3 className="text-lg font-semibold text-white mb-2">📖 Isi Pasal</h3>
                                            <div className="bg-slate-700/30 p-4 rounded-lg border-l-4 border-cyan-400">
                                                <p className="text-slate-200 leading-relaxed italic">"{selectedArticle.content}"</p>
                                            </div>
                                        </div>

                                        <div>
                                            <h3 className="text-lg font-semibold text-white mb-2">💡 Penjelasan untuk Gen Z</h3>
                                            <p className="text-slate-300 leading-relaxed">{selectedArticle.explanation}</p>
                                        </div>

                                        {selectedArticle.examples && (
                                            <div>
                                                <h3 className="text-lg font-semibold text-white mb-2">🎯 Contoh Implementasi</h3>
                                                <ul className="list-disc list-inside space-y-1 text-slate-300">
                                                    {selectedArticle.examples.map((example, index) => (
                                                        <li key={index}>{example}</li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}

                                        {selectedArticle.penalties && (
                                            <div>
                                                <h3 className="text-lg font-semibold text-white mb-2">⚠️ Sanksi/Hukuman</h3>
                                                <div className="bg-red-900/20 border border-red-400/30 p-4 rounded-lg">
                                                    <p className="text-red-300">{selectedArticle.penalties}</p>
                                                </div>
                                            </div>
                                        )}

                                        {selectedArticle.relatedCases && (
                                            <div>
                                                <h3 className="text-lg font-semibold text-white mb-2">📰 Kasus Terkait</h3>
                                                <ul className="list-disc list-inside space-y-1 text-slate-300">
                                                    {selectedArticle.relatedCases.map((case_, index) => (
                                                        <li key={index}>{case_}</li>
                                                    ))}
                                                </ul>
                                            </div>
                                        )}
                                    </div>

                                    <div className="mt-6 pt-6 border-t border-slate-700/50">
                                        <button
                                            onClick={() => markArticleAsRead(selectedArticle.id)}
                                            disabled={userProgress.articlesRead.includes(selectedArticle.id)}
                                            className={`px-6 py-3 rounded-lg font-medium transition-all ${
                                                userProgress.articlesRead.includes(selectedArticle.id)
                                                    ? 'bg-green-600/20 text-green-400 border border-green-400/30 cursor-not-allowed'
                                                    : 'bg-cyan-600 hover:bg-cyan-700 text-white'
                                            }`}
                                        >
                                            {userProgress.articlesRead.includes(selectedArticle.id) 
                                                ? '✅ Sudah Dibaca (+10 poin)' 
                                                : '📚 Tandai Selesai Dibaca'
                                            }
                                        </button>
                                    </div>
                                </div>
                            ) : (
                                /* Articles List */
                                <div className="space-y-4">
                                    <h2 className="text-xl font-semibold text-white">Daftar Pasal & Undang-Undang ({filteredArticles.length})</h2>
                                    
                                    {filteredArticles.map(article => (
                                        <div key={article.id} className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-4 border border-slate-700/50 hover:border-cyan-400/30 transition-all group cursor-pointer">
                                            <div className="flex items-start justify-between gap-4">
                                                <div className="flex-1" onClick={() => setSelectedArticle(article)}>
                                                    <div className="flex items-center gap-2 mb-2">
                                                        <div className={`inline-flex items-center gap-1 px-2 py-1 rounded text-xs font-medium ${getImportanceColor(article.importance)}`}>
                                                            {getCategoryIcon(article.category)}
                                                            <span className="ml-1">{article.importance.toUpperCase()}</span>
                                                        </div>
                                                        {userProgress.articlesRead.includes(article.id) && (
                                                            <CheckCircleIcon className="w-4 h-4 text-green-400" />
                                                        )}
                                                    </div>
                                                    
                                                    <h3 className="text-lg font-semibold text-white group-hover:text-cyan-300 transition-colors">
                                                        {article.title}
                                                    </h3>
                                                    <p className="text-cyan-400 text-sm font-medium mb-2">{article.chapter} - {article.article}</p>
                                                    <p className="text-slate-300 text-sm line-clamp-2">{article.content}</p>
                                                </div>
                                                
                                                <div className="text-right">
                                                    <button 
                                                        onClick={() => setSelectedArticle(article)}
                                                        className="text-cyan-400 hover:text-cyan-300 transition-colors"
                                                    >
                                                        <BookOpenIcon className="w-5 h-5" />
                                                    </button>
                                                </div>
                                            </div>
                                        </div>
                                    ))}

                                    {filteredArticles.length === 0 && (
                                        <div className="text-center py-12">
                                            <BookOpenIcon className="w-16 h-16 text-slate-600 mx-auto mb-4" />
                                            <p className="text-slate-400">Tidak ada artikel yang sesuai dengan filter yang dipilih.</p>
                                        </div>
                                    )}
                                </div>
                            )}
                        </div>
                    </div>
                )}

                {activeTab === 'quiz' && (
                    <InteractiveQuiz 
                        onUpdateProgress={handleProgressUpdate}
                        userProgress={userProgress}
                    />
                )}

                {activeTab === 'progress' && (
                    <div className="max-w-4xl mx-auto space-y-6">
                        {/* Learning Stats */}
                        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
                            <h2 className="text-xl font-semibold text-white mb-4">📊 Statistik Pembelajaran</h2>
                            
                            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Progress Mingguan</p>
                                    <div className="bg-slate-700/50 rounded-full h-4 mb-2">
                                        <div 
                                            className="bg-gradient-to-r from-cyan-500 to-blue-500 h-4 rounded-full transition-all duration-500"
                                            style={{ width: `${Math.min((userProgress.weeklyProgress / userProgress.weeklyGoal) * 100, 100)}%` }}
                                        ></div>
                                    </div>
                                    <p className="text-white text-sm">{userProgress.weeklyProgress} / {userProgress.weeklyGoal} artikel</p>
                                </div>
                                
                                <div>
                                    <p className="text-slate-400 text-sm mb-2">Level Pembelajaran</p>
                                    <div className="flex items-center gap-2">
                                        <AcademicCapIcon className="w-5 h-5 text-yellow-400" />
                                        <span className="text-white font-medium capitalize">{userProgress.currentLevel}</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        {/* Badges */}
                        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
                            <h3 className="text-lg font-semibold text-white mb-4">🏆 Badge yang Diraih</h3>
                            <div className="flex flex-wrap gap-3">
                                {userProgress.badges.map((badge, index) => (
                                    <div key={index} className="bg-gradient-to-r from-yellow-600/20 to-orange-600/20 border border-yellow-400/30 px-4 py-2 rounded-full">
                                        <span className="text-yellow-300 font-medium">🏅 {badge}</span>
                                    </div>
                                ))}
                            </div>
                        </div>

                        {/* Reading History */}
                        <div className="bg-slate-800/50 backdrop-blur-sm rounded-xl p-6 border border-slate-700/50">
                            <h3 className="text-lg font-semibold text-white mb-4">📚 Riwayat Bacaan</h3>
                            {userProgress.articlesRead.length > 0 ? (
                                <div className="space-y-2">
                                    {userProgress.articlesRead.map(articleId => {
                                        const article = LEGAL_ARTICLES.find(a => a.id === articleId);
                                        return article ? (
                                            <div key={articleId} className="flex items-center gap-3 p-3 bg-slate-700/30 rounded-lg">
                                                <CheckCircleIcon className="w-5 h-5 text-green-400" />
                                                <div>
                                                    <p className="text-white font-medium">{article.title}</p>
                                                    <p className="text-slate-400 text-sm">{article.chapter}</p>
                                                </div>
                                            </div>
                                        ) : null;
                                    })}
                                </div>
                            ) : (
                                <p className="text-slate-400">Belum ada artikel yang dibaca. Mulai belajar sekarang!</p>
                            )}
                        </div>
                    </div>
                )}
            </div>
        </div>
    );
};

export default LegalEducationCenter;
