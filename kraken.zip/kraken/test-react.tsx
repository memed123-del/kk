import React from 'react';
import ReactDOM from 'react-dom/client';

// Simple test component
const TestApp = () => {
  return (
    <div style={{ padding: '20px' }}>
      <h1 style={{ color: 'blue' }}>🎉 React is Working!</h1>
      <p>If you see this, React is properly loaded and running.</p>
      <button onClick={() => alert('React events work!')}>
        Test Button
      </button>
    </div>
  );
};

// Mount the test app
const rootElement = document.getElementById('root');
if (rootElement) {
  const root = ReactDOM.createRoot(rootElement);
  root.render(<TestApp />);
  console.log('✅ React test app mounted successfully');
} else {
  console.error('❌ Root element not found');
}