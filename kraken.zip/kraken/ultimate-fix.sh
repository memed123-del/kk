#!/bin/bash

# 🐋 Kraken AI - Ultimate Fix Script
# Script komprehensif untuk memperbaiki semua masalah

echo "🐋 Kraken AI - Ultimate Fix Script"
echo "===================================="

echo "✅ Step 1: Cleaning old installations..."
rm -rf node_modules package-lock.json .npm-cache .npm-packages 2>/dev/null || true

echo "✅ Step 2: Creating npm config for local installation..."
cat > .npmrc << 'EOF'
registry=https://registry.npmjs.org/
cache=/tmp/npm-cache
prefix=/tmp/npm-prefix
EOF

echo "✅ Step 3: Installing dependencies with fallback methods..."

# Method 1: Try normal install
echo "Trying method 1: Normal install..."
npm install --legacy-peer-deps --no-audit --no-fund 2>/dev/null

if [ $? -ne 0 ]; then
    echo "❌ Method 1 failed. Trying method 2: Force install..."
    npm install --force --legacy-peer-deps --no-audit --no-fund 2>/dev/null
fi

if [ $? -ne 0 ]; then
    echo "❌ Method 2 failed. Trying method 3: Using npx..."
    echo "🎯 Running directly with npx (no local install)"
    echo "📱 Server akan tersedia di: http://localhost:5000"
    npx vite --host 0.0.0.0 --port 5000
else
    echo "✅ Installation successful!"
    echo "🚀 Starting development server..."
    echo "📱 Server akan tersedia di: http://localhost:5000"
    npm run dev
fi
