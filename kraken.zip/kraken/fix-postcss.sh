#!/bin/bash

echo "🔧 Fixing PostCSS Config Error..."

# Fix postcss.config.js to use ES module syntax
cat > postcss.config.js << 'EOF'
export default {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
EOF

echo "✅ PostCSS config fixed!"
echo "🚀 Now run: npm run dev"