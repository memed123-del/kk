# 🐛 Legal AI Debug Guide

## 🔍 Kemungkinan Penyebab Error

### 1. **API Key Configuration**
- Periksa file `.env.local` di root project
- Pastikan ada minimal satu API key yang valid
- Ganti `your_gemini_api_key_here` dengan API key asli

### 2. **Permission Issues**
```bash
# Jika ada permission denied
chmod +x node_modules/.bin/vite
npm run dev
```

### 3. **Network/Quota Issues**
- API key sudah mencapai quota limit
- Network connection issues
- Firewall blocking API requests

### 4. **JavaScript Runtime Error**
- Syntax error di `getLegalChatResponse`
- Missing dependencies
- Import/export mismatch

## 🛠️ Debug Steps

### Step 1: Check Console Errors
Buka Developer Tools (F12) dan lihat:
- Console tab untuk JavaScript errors
- Network tab untuk API call failures

### Step 2: Test API Key
```javascript
// Di console browser, test:
console.log(process.env);
```

### Step 3: Restart Clean
```bash
rm -rf node_modules
rm package-lock.json
npm install
npm run dev
```

### Step 4: Manual Test
Try minimal API call di console:
```javascript
import { getLegalChatResponse } from './services/geminiService';
```

## 📋 Error Messages to Look For

- `No API keys available`
- `Quota limit reached`
- `Permission denied`
- `Network error`
- `Failed to fetch`
- `Syntax error`

## 💡 Quick Fixes

1. **For API Key Issues**: Set valid Gemini API key in `.env.local`
2. **For Permission Issues**: Run `npm run dev` as administrator
3. **For Quota Issues**: Use different API key or wait for reset
4. **For Syntax Issues**: Check latest changes in `geminiService.ts`

---
*Debug Guide by MiniMax Agent*
