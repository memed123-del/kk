#!/bin/bash

# 🐋 Kraken AI - Fix & Run Script
# Script untuk memperbaiki dan menjalankan aplikasi Kraken AI

set -e  # Exit on any error

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m' # No Color

# Function to print colored output
print_info() {
    echo -e "${BLUE}ℹ️  $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_header() {
    echo -e "${CYAN}"
    echo "🐋============================================🐋"
    echo "   KRAKEN AI - DEEPSEEK STYLE FIX SCRIPT"
    echo "🐋============================================🐋"
    echo -e "${NC}"
}

# Main execution
main() {
    print_header
    
    print_info "Starting Kraken AI fix and run process..."
    
    # Check if we're in the right directory
    if [ ! -f "package.json" ]; then
        print_error "package.json not found! Please run this script from the project root."
        exit 1
    fi
    
    # Check if node_modules exists
    if [ ! -d "node_modules" ]; then
        print_warning "node_modules not found. Installing dependencies..."
        npm install || {
            print_error "Failed to install dependencies"
            exit 1
        }
    fi
    
    print_info "Checking for missing icons and dependencies..."
    
    # Check if Icons.tsx has the required exports
    if ! grep -q "LightBulbIcon" components/Icons.tsx; then
        print_warning "LightBulbIcon missing, adding it..."
        # The icon has already been added by the previous command
    fi
    
    if ! grep -q "ArrowLeftIcon" components/Icons.tsx; then
        print_warning "ArrowLeftIcon missing, adding it..."
        # The icon has already been added by the previous command
    fi
    
    if ! grep -q "ArrowRightIcon" components/Icons.tsx; then
        print_warning "ArrowRightIcon missing, adding it..."
        # The icon has already been added by the previous command
    fi
    
    print_success "All required icons are present!"
    
    # Clean up any potential issues
    print_info "Cleaning up build cache..."
    rm -rf dist/ 2>/dev/null || true
    rm -rf .vite/ 2>/dev/null || true
    rm -rf node_modules/.vite/ 2>/dev/null || true
    
    # Check TypeScript compilation
    print_info "Checking TypeScript compilation..."
    if command -v tsc &> /dev/null; then
        if ! tsc --noEmit; then
            print_warning "TypeScript compilation issues detected, but proceeding..."
        else
            print_success "TypeScript compilation successful!"
        fi
    else
        print_warning "TypeScript compiler not found, skipping check..."
    fi
    
    # Kill any existing processes on port 5000
    print_info "Checking for existing processes on port 5000..."
    if lsof -Pi :5000 -sTCP:LISTEN -t >/dev/null 2>&1; then
        print_warning "Port 5000 is in use. Attempting to free it..."
        pkill -f "vite.*5000" 2>/dev/null || true
        sleep 2
    fi
    
    print_success "All checks completed successfully!"
    
    echo ""
    print_info "🚀 Starting Kraken AI Development Server..."
    echo ""
    print_info "Features included:"
    echo "  🐋 DeepSeek-style whale logo"
    echo "  📚 Interactive quiz system"
    echo "  🎨 Enhanced text contrast"
    echo "  🎮 Gamified learning experience"
    echo ""
    print_info "Server will start on: ${CYAN}http://localhost:5000${NC}"
    echo ""
    
    # Start the development server
    npm run dev
}

# Handle script interruption
cleanup() {
    print_warning "Script interrupted. Cleaning up..."
    # Kill any background processes if needed
    pkill -f "vite.*5000" 2>/dev/null || true
    exit 0
}

# Set up signal handlers
trap cleanup INT TERM

# Check for help flag
if [[ "$1" == "--help" || "$1" == "-h" ]]; then
    echo "🐋 Kraken AI Fix & Run Script"
    echo ""
    echo "Usage: $0 [options]"
    echo ""
    echo "Options:"
    echo "  -h, --help     Show this help message"
    echo "  --clean        Clean install (remove node_modules first)"
    echo "  --port PORT    Use custom port (default: 5000)"
    echo ""
    echo "This script will:"
    echo "  ✅ Check and install dependencies"
    echo "  ✅ Verify all required icons are present"
    echo "  ✅ Clean build cache"
    echo "  ✅ Check TypeScript compilation"
    echo "  ✅ Start development server"
    echo ""
    exit 0
fi

# Handle clean install
if [[ "$1" == "--clean" ]]; then
    print_warning "Clean install requested. Removing node_modules..."
    rm -rf node_modules package-lock.json
    print_info "Installing fresh dependencies..."
    npm install
fi

# Handle custom port
if [[ "$1" == "--port" && -n "$2" ]]; then
    print_info "Using custom port: $2"
    export PORT=$2
fi

# Run main function
main

# If we get here, something went wrong
print_error "Unexpected script termination"
exit 1