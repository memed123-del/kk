#!/bin/bash

# 🐋 Kraken AI - Problem Diagnostic & Fix Script
# Script untuk mendiagnosis dan memperbaiki masalah

echo "🐋============================================🐋"
echo "   KRAKEN AI - DIAGNOSTIC & FIX SCRIPT"
echo "🐋============================================🐋"
echo ""

# Colors
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m'

print_status() {
    echo -e "${BLUE}📋 $1${NC}"
}

print_success() {
    echo -e "${GREEN}✅ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠️  $1${NC}"
}

print_error() {
    echo -e "${RED}❌ $1${NC}"
}

print_fix() {
    echo -e "${GREEN}🔧 $1${NC}"
}

echo "🔍 DIAGNOSING ISSUES..."
echo ""

# Check Node.js version
print_status "Checking Node.js version..."
NODE_VERSION=$(node -v 2>/dev/null || echo "not found")
if [[ "$NODE_VERSION" == "not found" ]]; then
    print_error "Node.js not found!"
    ISSUES+=("node_missing")
else
    echo "   Current: $NODE_VERSION"
    # Extract version number
    NODE_MAJOR=$(echo $NODE_VERSION | sed 's/v//' | cut -d. -f1)
    if [[ $NODE_MAJOR -lt 18 ]]; then
        print_warning "Node.js version is too old (need >=18)"
        ISSUES+=("node_old")
    elif [[ $NODE_MAJOR -lt 20 ]]; then
        print_warning "Node.js 18 detected - some packages prefer Node 20+"
        ISSUES+=("node_18")
    else
        print_success "Node.js version is compatible"
    fi
fi

# Check if package.json exists
print_status "Checking project structure..."
if [[ ! -f "package.json" ]]; then
    print_error "package.json not found! Not in project root?"
    ISSUES+=("no_package_json")
else
    print_success "package.json found"
fi

# Check if node_modules exists
print_status "Checking dependencies..."
if [[ ! -d "node_modules" ]]; then
    print_warning "node_modules not found"
    ISSUES+=("no_node_modules")
else
    print_success "node_modules directory exists"
fi

# Check if Icons.tsx has required exports
print_status "Checking required icons..."
MISSING_ICONS=()
if [[ -f "components/Icons.tsx" ]]; then
    if ! grep -q "LightBulbIcon" components/Icons.tsx; then
        MISSING_ICONS+=("LightBulbIcon")
    fi
    if ! grep -q "ArrowLeftIcon" components/Icons.tsx; then
        MISSING_ICONS+=("ArrowLeftIcon") 
    fi
    if ! grep -q "ArrowRightIcon" components/Icons.tsx; then
        MISSING_ICONS+=("ArrowRightIcon")
    fi
    
    if [[ ${#MISSING_ICONS[@]} -eq 0 ]]; then
        print_success "All required icons are present"
    else
        print_warning "Missing icons: ${MISSING_ICONS[*]}"
        ISSUES+=("missing_icons")
    fi
else
    print_error "components/Icons.tsx not found"
    ISSUES+=("no_icons_file")
fi

echo ""
echo "📊 DIAGNOSIS COMPLETE"
echo "===================="

if [[ ${#ISSUES[@]} -eq 0 ]]; then
    print_success "No issues detected! Project should work."
    echo ""
    echo "🚀 To start the development server:"
    echo "   npm run dev"
    echo ""
    echo "🌐 Once started, visit: http://localhost:5000"
    echo ""
    echo "🎮 New Features Available:"
    echo "   🐋 DeepSeek-style whale logo"
    echo "   📚 Interactive quiz system with gamification"
    echo "   🎨 Enhanced text contrast for better readability"
    echo "   🏆 Badge system and learning progress tracking"
    
else
    echo ""
    print_error "Issues detected. Here are the fixes:"
    echo ""
    
    for issue in "${ISSUES[@]}"; do
        case $issue in
            "node_missing")
                print_fix "Install Node.js from https://nodejs.org/ (version 18 or higher)"
                ;;
            "node_old")
                print_fix "Update Node.js to version 18 or higher"
                ;;
            "node_18")
                print_fix "Consider updating to Node.js 20+ for better compatibility"
                ;;
            "no_package_json")
                print_fix "Navigate to the project root directory where package.json is located"
                ;;
            "no_node_modules")
                print_fix "Run: npm install (you may need to use sudo or run as administrator)"
                ;;
            "missing_icons")
                print_fix "Icons should already be fixed by previous script runs"
                ;;
            "no_icons_file")
                print_fix "Make sure you're in the correct project directory"
                ;;
        esac
    done
    
    echo ""
    echo "📝 MANUAL FIX INSTRUCTIONS:"
    echo "=========================="
    echo ""
    echo "1. 🔧 If npm install fails with permissions:"
    echo "   sudo npm install"
    echo "   OR"
    echo "   npm install --prefix ./local && export PATH=./local/node_modules/.bin:\$PATH"
    echo ""
    echo "2. 🔧 If Vite has permission issues:"
    echo "   sudo npm run dev"
    echo "   OR"
    echo "   npx vite --host 0.0.0.0 --port 5000"
    echo ""
    echo "3. 🔧 Alternative start methods:"
    echo "   node ./node_modules/vite/bin/vite.js"
    echo "   OR"
    echo "   npm start (if available)"
    echo ""
    echo "4. 🔧 If all else fails, try Docker (if available):"
    echo "   docker run -it --rm -v \$(pwd):/app -w /app -p 5000:5000 node:20 bash"
    echo "   # Then inside container: npm install && npm run dev"
fi

echo ""
echo "🐋 Kraken AI is ready with these new features:"
echo "  🎯 DeepSeek-inspired logo design"
echo "  🎮 Interactive legal education quiz"
echo "  🎨 Improved text readability"
echo "  🏆 Gamified learning system"
echo ""
echo "📁 All changes have been saved to your project files."