# 🔧 Panduan Lengkap Memperbaiki Semua Error Kraken AI

## 📝 Ringkasan Masalah
1. **Script "dev" tidak ditemukan** - package.json tidak dikonfigurasi dengan benar
2. **Permission errors** - masalah instalasi npm
3. **Versi incompatible** - dependencies tidak sesuai dengan Node.js version

## 🛠️ Solusi Lengkap

### Step 1: Backup dan Clean Project
```bash
# Backup proyek Anda (jika diperlukan)
cp -r gg gg_backup

# Masuk ke direktori proyek
cd gg

# Hapus node_modules dan lock file lama
rm -rf node_modules
rm -f package-lock.json
```

### Step 2: Buat package.json yang Benar
Buat file `package.json` dengan konfigurasi berikut:

```json
{
  "name": "kraken-ai",
  "private": true,
  "version": "0.0.0",
  "type": "module",
  "scripts": {
    "dev": "vite --host 0.0.0.0 --port 5000",
    "build": "tsc && vite build",
    "lint": "eslint . --ext ts,tsx --report-unused-disable-directives --max-warnings 0",
    "preview": "vite preview"
  },
  "dependencies": {
    "react": "^18.2.0",
    "react-dom": "^18.2.0",
    "@google/genai": "^0.15.0",
    "recharts": "^2.8.0",
    "chart.js": "^4.4.0",
    "react-chartjs-2": "^5.2.0",
    "date-fns": "^2.30.0",
    "lucide-react": "^0.263.1",
    "clsx": "^2.1.0"
  },
  "devDependencies": {
    "@types/node": "^18.0.0",
    "@types/react": "^18.2.56",
    "@types/react-dom": "^18.2.19",
    "@vitejs/plugin-react": "^3.1.0",
    "typescript": "~4.9.5",
    "vite": "^3.2.0",
    "autoprefixer": "^10.4.17",
    "postcss": "^8.4.35",
    "tailwindcss": "^3.4.1"
  }
}
```

### Step 3: Buat vite.config.ts yang Benar
```typescript
import path from 'path';
import { defineConfig, loadEnv } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig(({ mode }) => {
  const env = loadEnv(mode, '.', 'VITE_');
  return {
    server: {
      port: 5000,
      host: '0.0.0.0',
      allowedHosts: ['*']
    },
    plugins: [react()],
    define: {
      'process.env.API_KEY': JSON.stringify(env.GEMINI_API_KEY),
      'process.env.GEMINI_API_KEY': JSON.stringify(env.GEMINI_API_KEY)
    },
    resolve: {
      alias: {
        '@': path.resolve(__dirname, '.'),
      }
    }
  };
});
```

### Step 4: Buat tsconfig.json yang Benar
```json
{
  "compilerOptions": {
    "target": "ES2020",
    "useDefineForClassFields": true,
    "lib": ["ES2020", "DOM", "DOM.Iterable"],
    "module": "ESNext",
    "skipLibCheck": true,
    "types": ["node"],
    "moduleResolution": "bundler",
    "allowImportingTsExtensions": true,
    "resolveJsonModule": true,
    "isolatedModules": true,
    "noEmit": true,
    "jsx": "react-jsx",
    "strict": true,
    "noUnusedLocals": true,
    "noUnusedParameters": true,
    "noFallthroughCasesInSwitch": true,
    "baseUrl": ".",
    "paths": {
      "@/*": ["./*"]
    }
  },
  "include": ["*.ts", "*.tsx", "components/**/*"],
  "references": [{ "path": "./tsconfig.node.json" }]
}
```

### Step 5: Buat tsconfig.node.json
```json
{
  "compilerOptions": {
    "composite": true,
    "skipLibCheck": true,
    "module": "ESNext",
    "moduleResolution": "bundler",
    "allowSyntheticDefaultImports": true
  },
  "include": ["vite.config.ts"]
}
```

### Step 6: Buat tailwind.config.js (jika menggunakan Tailwind)
```javascript
/** @type {import('tailwindcss').Config} */
export default {
  content: [
    "./index.html",
    "./**/*.{js,ts,jsx,tsx}"
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
```

### Step 7: Install Dependencies
```bash
# Install dengan npm
npm install

# Atau jika ada error permission, gunakan:
npm install --no-optional

# Atau jika masih bermasalah:
sudo npm install
```

### Step 8: Jalankan Development Server
```bash
# Jalankan server development
npm run dev

# Atau jika script tidak bekerja:
npx vite --host 0.0.0.0 --port 5000

# Atau jika masih error:
./node_modules/.bin/vite --host 0.0.0.0 --port 5000
```

## 🔍 Troubleshooting Umum

### Error: "Missing script: dev"
**Solusi:** Pastikan package.json memiliki scripts section dengan "dev" command.

### Error: "Cannot use import statement outside a module"
**Solusi:** Pastikan package.json memiliki `"type": "module"` dan gunakan versi Vite yang kompatibel.

### Error: Permission denied (EACCES)
**Solusi:**
```bash
# Gunakan npm dengan flag khusus
npm install --unsafe-perm=true --allow-root

# Atau setup npm prefix
npm config set prefix ~/.npm-global
export PATH=~/.npm-global/bin:$PATH

# Atau install dengan sudo (hati-hati)
sudo npm install
```

### Error: "Unsupported engine" untuk @google/genai
**Solusi:** Gunakan versi yang kompatibel dengan Node.js Anda:
- Node 18: `"@google/genai": "^0.15.0"`
- Node 20+: `"@google/genai": "^1.24.0"`

### Error: Vite tidak bisa start
**Solusi:**
```bash
# Cek versi Node.js
node --version

# Jika Node.js < 18, upgrade atau gunakan Vite 2.x:
npm install vite@^2.9.0 --save-dev

# Atau gunakan alternative:
npx create-vite@latest . --template react-ts
```

## 🚀 Menjalankan Proyek

Setelah semua konfigurasi benar:

```bash
# Install dependencies
npm install

# Jalankan development server
npm run dev

# Build untuk production
npm run build

# Preview build
npm run preview
```

Aplikasi akan berjalan di: `http://localhost:5000`

## 📋 Checklist Verifikasi

- [ ] File package.json ada dan konfigurasi benar
- [ ] File vite.config.ts ada dan konfigurasi benar  
- [ ] File tsconfig.json ada dan konfigurasi benar
- [ ] Dependencies terinstall (ada folder node_modules)
- [ ] Script "dev" bisa dijalankan tanpa error
- [ ] Server dapat diakses di browser

## 🆘 Jika Masih Error

Jika masih ada masalah, coba langkah-langkah berikut:

1. **Reset Total:**
```bash
rm -rf node_modules package-lock.json
npm cache clean --force
npm install
```

2. **Gunakan Yarn sebagai alternative:**
```bash
npm install -g yarn
yarn install
yarn dev
```

3. **Buat proyek baru dan copy files:**
```bash
npx create-vite@latest kraken-ai-new --template react-ts
cd kraken-ai-new
# Copy semua file komponen dan assets dari proyek lama
npm run dev
```

Semoga panduan ini membantu memperbaiki semua error pada proyek Kraken AI Anda! 🎉
